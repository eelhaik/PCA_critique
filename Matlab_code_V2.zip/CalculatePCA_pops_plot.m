% CalculatePCA_pops_plot
% function CalculatePCA_pops_plot(SCORE, Labels_nick)
function CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes, use_index_on_score, hAxis, hAxis_num)

    if nargin==5
        disp('CalculatePCA_pops_plot: No hAxis were provided.');
        hAxis = [];
        hAxis_num = [];
    end;

    %if specific PCs were requested
    if use_index_on_score
        %Recall, if this option is in used, send SCORE as is.
        disp(['Plotting PCs #' num2str(use_index_on_score)])
        SCORE = [SCORE(:, use_index_on_score(1)) SCORE(:, use_index_on_score(2))];
        PC1_label = ['PC' num2str(use_index_on_score(1)) ' '];
        PC2_label = ['PC' num2str(use_index_on_score(2)) ' '];
        temp = pcvars;
        pcvars(1) = temp(use_index_on_score(1));
        pcvars(2) = temp(use_index_on_score(2));
    else
        PC1_label = 'PC1 ';
        PC2_label = 'PC2 ';
    end;
    
    
    Labels_nick = Labels.Nick(Pop_indexes(:));
    Labels_color = Labels.Color(Pop_indexes(:),:);
    Labels_marker = Labels.marker(Pop_indexes(:));
    Labels_pops = Labels.Pop_name(Pop_indexes(:));
    Labels_ID = Labels.User_id(Pop_indexes(:));

    %Plot all points
    [~, pop_index] = unique(Labels_pops, 'stable');
    gscatter(SCORE(:,1), SCORE(:,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)));

    %Diffuse the labels for clarity
%     SCORE_label = SCORE(:,1:2) + (randi([0,1], size(SCORE,1), 2)*2 - 1).*mean(abs(SCORE(:,1)))/10; %the last number controls the diffusion
    SCORE_label = SCORE(:,1:2);
    
    %population labels - masked in some runs
%      text(SCORE_label(:,1), SCORE_label(:,2), Labels_nick, 'FontName','Ariel','FontSize', 7);

    %Plot user ID, for debugging problematic samples
%     text(SCORE_label(:,1), SCORE_label(:,2), Labels_ID, 'FontName','Ariel','FontSize', 7);

    %Correct the axis
    axis_factor_x = (max(SCORE(:,1)) - min(SCORE(:,1)))/15;
    axis_factor_y = (max(SCORE(:,2)) - min(SCORE(:,2)))/15;

%     get_axis = axis; %[min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
%     axis_ratio = [abs(get_axis(2))/axis_factor abs(get_axis(4))/axis_factor];
    axis([min(SCORE(:,1))-axis_factor_x max(SCORE(:,1))+axis_factor_x min(SCORE(:,2))-axis_factor_y max(SCORE(:,2))+axis_factor_y]);

    %Calculate explained variation
    pcvars_exp = pcvars./sum(pcvars);
    xlabel([PC1_label num2str(round2(10000*pcvars_exp(1),2)/100) '%']);
    ylabel([PC2_label num2str(round2(10000*pcvars_exp(2),2)/100) '%']);
    
    % remove the border lines surrounding an axes
    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');
    set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);
    
%     grid minor;
%     grid on;
%     axis square; 
%     axis equal;
    whitebg('w'); %affects the first plot
    legend off;

    %Fix positions
    if hAxis
%         disp('Fixing positions...')
        pos = get(gca, 'Position');
        if hAxis_num==6
%             disp('Fix positions of 6 subplots...');
            i = numel(hAxis);
            pos2 = 0.53;
            pos3 = 0.25;
            pos4 = 0.36;

            if i<=3
                pos(2) = pos2; 
                pos(3) = pos3;
                pos(4) = pos4;
                set( hAxis(i), 'Position', pos ) ;
            end;
            if i>3
                pos(3) = pos3;
                pos(4) = pos4;
                set( hAxis(i), 'Position', pos ) ;
            end;
        end;
        
        if hAxis_num==4
%             disp('Fix positions of 4 subplots...');
            i = numel(hAxis);

            if i<=2
                pos(2) = 0.55; 
                pos(3) = 0.3;
                pos(4) = 0.37;
                set( hAxis(i), 'Position', pos ) ;
            end;

            if i>2
                pos(2) = 0.12; 
                pos(3) = 0.3;
                pos(4) = 0.37;
                set( hAxis(i), 'Position', pos ) ;
            end;

            if (i==1 || i==3)
                pos(1) = 0.16;
                set( hAxis(i), 'Position', pos ) ;
            else
                pos(1) = 0.5;
                set( hAxis(i), 'Position', pos ) ;
            end
        end;
        
    end;
end

The main files are:

Main_PCA_Colors.m - executes all the analyses related to the color populations
Main_PCA_Pops.m - executes all the analyses related to real populations
LiteratureAnalysis.m - Plots figure 27

Please email me if files are missing to run this code:
eran.elhaik@biol.lu.se

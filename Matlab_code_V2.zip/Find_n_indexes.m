% Find_n_indexes

% random sampling of samples in a population with size n

function res = Find_n_indexes(Sample_indexes, n)

    %if the case of even sample sizes
    if numel(n)==1
        n = n.*ones(1,size(Sample_indexes,2));
    elseif numel(n)~=size(Sample_indexes,2)
        error_message(['Find_n_indexes Error: n size is different from the number of populations']);
        return;
    end;
        
    res = zeros(max(n), size(Sample_indexes,2));
    for i=1:size(Sample_indexes,2)
        
        temp = find(Sample_indexes(:,i));
        if numel(temp) < n(i)
            error_message([num2str(i) '. Find_n_indexes Error: n is larger the the number of populations in column #' num2str(i)]);
            return;
        end;
        res(1:n(i),i) = temp(randsample(1:numel(temp), n(i)));
    end;
end
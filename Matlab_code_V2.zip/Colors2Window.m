% Colors2Window

% either spread the signal from each components over win_size markers (non
% random option). Or if is_random is positive - generate junk in win_size -
% these are the non-AIMs markers

function X = Colors2Window(M1, win_size, is_random)
    
    if (nargin==2)
       is_random = 0;
    end
    
    X = [];
    SD1 = 0.25;
    random_markers = 0.05;

    %generating a distribution
    for i=1:size(M1,1)
        curr_M1 = M1(i,:);
        %generate data from a normal distribution around the mean value
%         X(i,:) = [curr_M1(1) + SD1.*randn(1,win_size) curr_M1(2) + SD1.*randn(1,win_size) curr_M1(3) + SD1.*randn(1,win_size)];

        %uniformly distribute the numbers over a large number of markers
        X(i,:) = [repmat(curr_M1(1)./win_size,1,win_size) repmat(curr_M1(2)./win_size,1,win_size) repmat(curr_M1(3)./win_size,1,win_size)];

        % introduce random numbers throughout the sequence
        if is_random
%             disp('Generating random data');
            temp = 0.1*rand(1,numel(X(i,:)));
            temp_pos = randsample(numel(X(i,:)), round(numel(X(i,:))*random_markers));
            X(i,temp_pos) = temp(temp_pos);
        end;

    end;
    
    
end
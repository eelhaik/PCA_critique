% sort_nicks
function [Labels_nick_unsorted, Labels_nick_unsorted_indexes, Pop_names] = sort_nicks(Labels_nick_unsorted, Labels_nick_unsorted_indexes, Labels)

    % sort the nicknames by the order of the region from where they are from

    [~, b]=ismember(Labels_nick_unsorted, Labels.Nick);
    [~, d]=sort(Labels.Region(b));
    
    %Return results
    Labels_nick_unsorted = Labels_nick_unsorted(d);
    Labels_nick_unsorted_indexes = Labels_nick_unsorted_indexes(d);

    [~, x]=ismember(Labels_nick_unsorted, Labels.Nick);
    Pop_names = Labels.Pop_name(x);

end
% Main_PCA_Colors
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                               Main PCA Color - for publicaiton
%                               --------------------------------
%
% Description : This scripts applies PCA to color populations. The test cases are numbered according to
% their appearance in the paper.
% 
% 1.	The near-perfect case of dimensionality reduction
% 2.	The case of uneven-sized populations 
% 3.	The case of one admixed population
% 4.	The case of two and three admixed population 
% 5.	The case of multiple admixed population 
% 6.	The case of multiple admixed population without “unmixed” populations
% 7.	The case of pairwise comparisons 
% 8.	The case of case-control matching and GWAS
% 9.	The case of unions and projections
% 10.	The case of ancient DNA
% 11.	The case of marker choice
% 
% Input : internal input, all data are simulated
% Output: plots and statistics
% 
% Main functions called:
%     Generate_nonrandom_colors - generate proportions that correspond to color
%     Plot_3d - plot a 3D graph
%     Calculate_distances - measure distances between populations
%     plot_PCA - plot the PCA plot
%     pca1 - Calling Matlab's pca.m function
%         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: Eran Elhaik
% Written date: 11/12/2021
% Version : 5.00
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ver 4.00 - Preparing script for publication.
% Ver 5.00 - Revisions, adding cases, removing unions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Start Program: Main_ColorPCA');
global Colors_names;
global draw_title; %1=draw figure titles; 0=hide figure title
draw_title = 0;

%% #0 A step by step calculation of PCA - manually (Figure 1)
% Calculating PCA for a simple dataset of four colors. The calculation is done both step-by-step and using Matlab's SVD
% built-in function. Both calculations yield the same results.

disp('Calculating PCA manually');

% Simple color dataset: 4 colors (samples), 3 SNPs (observations)
data_main = double([1 0 0; 0 1 0; 0 0 1; 0 0 0]);

A = data_main;
[n m] = size(A);

AMean = mean(A);
AStd = std(A);

% Center the data
B = (A - repmat(AMean,[n 1]));

disp('Subscribe the mean')
disp(B); %A demonstration of the centralization process (done inside pca)

disp('The mean of the matrix')
disp(mean(B)); %mean is 0 in centralized data

%Calculate the correlation\covariance matrix
%The correlation\covariance matrix (covariance because the data are centered)
C = (B'*B)./(size(B,1)-1); %same as cov(B)
disp(C); 

% Calculate the eigenvectors and eigenvalues
disp('Calculate the eigenvectors and eigenvalues');
[V_eigenvectors D_eigenvalues] = eig(C); %calculate eigenvalues
disp(round(V_eigenvectors,2))
disp(round(D_eigenvalues,2))

% Check the eigenvectors and eigenvalues
% Z*V = Z*D.
disp('C*V_eigenvectors')
disp(C*V_eigenvectors)
disp('V_eigenvectors*D_eigenvalues')
disp(V_eigenvectors*D_eigenvalues)

% This is the same as
% [V_eigenvectors D_eigenvalues] = eig(cov(B))
% But eig is sorting the components

% Sort the explained variance
disp('Sort the explained variance');
disp(cumsum(flipud(diag(D_eigenvalues))) / sum(diag(D_eigenvalues)));

[eigValues, idx] = sort(diag(D_eigenvalues), 'descend');

% Calculate the PCs
disp('The PCs');
PC = B * V_eigenvectors

% verify that the variance is in a decreased order
disp('The variance is in a decreased order')
var(PC)
% The first principal component appears in the last column when using MATLAB's eig function, 
% and columns to the left have less and less variance until the last principal component, stored in the first column.

% Retrieve the original matrix (approximetly)
disp('Retrieve the original matrix (approximetly)');
Z = ((PC * V_eigenvectors') ) + repmat(AMean,[n 1])

% All of this is the same as applying Matlab's pca function
% Here, eig is used to match the manual calculations above, otherwise, SVD
% is used.
disp('Calculating PCA using Matlab''s built-in SVD function:');
data_main = double([1 0 0; 0 1 0; 0 0 1; 0 0 0]);
[coeff1,SCORE1,V1] = pca(data_main, 'Algorithm', 'eig');
disp('coeff'); disp(coeff1);
disp('SCORE'); disp(SCORE1);
disp('V'); disp(V1);
disp(coeff1*coeff1');  %matrix I

% Retrieve the original matrix
Z = ((SCORE1 * coeff1') + repmat(AMean,[n 1]))

%% Response

% [coeff, score, latent, tsquared, explained, mu]
% data_main = double([1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 0]);
% [coeff1,SCORE1, V1, T1, E1, mu1] = pca(data_main, 'Algorithm', 'eig')

data_main = double([1 0 0; 0 1 0; 0 0 1; 0 0 0]);
[coeff1,SCORE1, V1, T1, E1, mu1] = pca(data_main, 'Algorithm', 'eig')


%% #1 Normal case - populations of even sizes 
% We calculate PCA for a sample of 4 colors (n=1) that evenly increment in
% size. We calculate the distances between the samples in the 2D space
% (usign the first 2 PCs).
% Using all PCs yeild colors that are the same as the original colors.
close all;
clc;

Colors_names = {'Red', 'Green', 'Blue', 'Black'};
% Colors_names = {'Red', 'Green', 'Blue', 'Green-Blue'};
N1=1; Me1=1; SD1=0; 

% Primary colors
[M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
[M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
[M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
[M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black

% Add all Mats
M = [M1' M2' M3' M4']';
S = [S1 S2 S3 S4]';

% Plot original colors on 3D and the PCs
subplot(2,2,1)
    disp('Case 1');
    Plot_3d(M)
    whitebg('w'); %affects the first plot
    axis square; axis equal;

    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');
%     print('-dtiff', 'd:\temp.tif', '-r600');

subplot(2,2,2)
    disp('Case 2');
    
    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos);
    
    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');
%     print('-dtiff', 'd:\temp2.tif', '-r600'); close;

subplot(2,2,3)

    disp('Case 3');
    %Plotting data of a new model but based on the same idea as before
    N1=100; Me1=1; SD1=0; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    %Calculate PCA
    [SCORE, ~, pcvars] = pca1(M);
    disp('Out of PCA')
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos);
    
    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');
%     print('-dtiff', 'd:\temp3.tif', '-r600'); close;

% This steps takes a few minutes
subplot(2,2,4)
    disp('Case 4');

    %Plotting data of a new model but based on the same idea as before
    N1=100; Me1=1; SD1=0; %N1 should be 10,000

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    %Calculate PCA
    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);

    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos);
    
    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');
    %print('-dtiff', 'd:\temp3.tif', '-r600'); close;

maximize
    
%% #2 Different-sized populations
close all;
Colors_names = {'Red', 'Green', 'Blue', 'Black'};

% Plot original colors on 3D and the PCs
figure
hAxis = [];
hAxis_num = 6;
hAxis(1) = subplot(2,3,1);
    disp('Case 1');
    N1=10; Me1=0.9; SD1=0.01; N2=200;  

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N2, 4); %Black

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);

    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
hAxis(2) = subplot(2,3,2);

    disp('Case 2');
    N1=10; Me1=0.9; SD1=.01; N2=200; N3=5;  

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N2, 4); %Black

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);

    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

hAxis(3) = subplot(2,3,3);

    disp('Case 3');
    N1=10; Me1=0.9; SD1=.01; N2=200; N3=50; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N2, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N2, 4); %Black

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);

    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

hAxis(4) = subplot(2,3,4);

    disp('Case 4');
    N1=10; Me1=0.9; SD1=.01; N2=200;  N3=50;  N4=25;  

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N4, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N3, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N2, 4); %Black

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);

    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);
 
    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

hAxis(5) = subplot(2,3,5);

    disp('Case 5');
    N1=10; Me1=0.9; SD1=.01; N2=200;  N3=50;  N4=300;  

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N4, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N3, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N4, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N4, 4); %Black

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);

    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

hAxis(6) = subplot(2,3,6);

    disp('Case 6');
    Me1=0.9; SD1=.01; N2=2000;  N4=300; N5=1000; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N5, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N2, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N4, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N2, 4); %Black

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);

    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
maximize

% print('-dtiff', 'd:\PCAColors_2.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\PCAColors_2.tif', 'output', 'd:\PCAColors_2_clear.tif');
%% #3 Admixed populations (1)
% The introduction of a single admixed group.
close all;
clc

Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan'};

% Plot original colors on 3D and the PCs
figure
hAxis = [];
hAxis_num = 4;
hAxis(1) = subplot(2,2,1);

    disp('Case 1');
    N1=100; Me1=0.9; SD1=.01; N2=200;  

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 5); %Cyan

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);

    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

hAxis(2) = subplot(2,2,2);
    disp('Case 2');
    N1=100; Me1=0.9; SD1=.01; N2=500;  

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N2, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N2, 5); %Cyan

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);

    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

hAxis(3) = subplot(2,2,3);
    disp('Case 3');
    N1=100; Me1=0.9; SD1=.01; N2=33; N3=400; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N2, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N3, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N2, 5); %Cyan

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);

    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

hAxis(4) = subplot(2,2,4);
    disp('Case 4');
    N1=100; Me1=0.9; SD1=.01; N2=33;  

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N2, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N2, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N2, 5); %Cyan

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);

    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

maximize;

% print('-dtiff', 'd:\PCAColors_3_1.tif', '-r600');
% close
% RemoveWhiteSpace([], 'file', 'd:\PCAColors_3_1.tif', 'output', 'd:\PCAColors_3_1_clear.tif');

%% #3 Admixed populations (2)
close all;
clc

Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan'};

% Black is admixed Black-Red
figure
hAxis = [];
hAxis_num = 4;
hAxis(1) = subplot(2,2,1);
    disp('Case 1');
    N1=100; Me1=0.9; SD1=.01; N2=33; N4=5;

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N4, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0  ], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N4, 5); %Cyan

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);
    
    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

% Black is green
hAxis(2) = subplot(2,2,2);
    disp('Case 2');
    N1=100; Me1=0.9; SD1=.01; N2=33; N3=400; N4=1600;

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N4, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N2, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N3, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N2, 5); %Cyan

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
% Black is blue
hAxis(3) = subplot(2,2,3);
    disp('Case 3');
    
    N1=10; Me1=0.9; SD1=.01; N2=20; N3=50; N4=1000;  

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N4, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N2, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N4, 5); %Cyan

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
% Black is cyan
hAxis(4) = subplot(2,2,4);
    disp('Case 4');
    N1=10; Me1=0.9; SD1=.01; N2=20; N3=50; N4=1000;  

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N4, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N3, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N4, 5); %Cyan

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
maximize;

% print('-dtiff', 'd:\PCAColors_3_2.tif', '-r600'); close
% RemoveWhiteSpace([], 'file', 'd:\PCAColors_3_2.tif', 'output', 'd:\PCAColors_3_2_clear.tif');

%% #4 - 2 Admixed populations
close all;
clc;

Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple'};

% Plot original colors on 3D and the PCs
figure
hAxis = [];
hAxis_num = 6;
hAxis(1) = subplot(2,3,1);
    disp('Case 1');
    N1=10; Me1=0.9; SD1=.01; N2=200;  

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 6); %Purple

    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6']';
    S = [S1 S2 S3 S4 S5 S6]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
hAxis(2) = subplot(2,3,2);
    disp('Case 2');
    Me1=0.9; SD1=.01; N2=33;  N3=100; N4=10;

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N3, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N4, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0],   SD1, N4, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N4, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N3, 6); %Purple

    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6']';
    S = [S1 S2 S3 S4 S5 S6]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

hAxis(3) = subplot(2,3,3);
    disp('Case 3');
    N1=50; Me1=0.9; SD1=.01; N2=5; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1-N2, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N2, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N2, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N2, 6); %Purple

    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6']';
    S = [S1 S2 S3 S4 S5 S6]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
hAxis(4) = subplot(2,3,4);
    disp('Case 4');
    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple', 'Yellow'};
    N1=50; Me1=0.9; SD1=.01; N2=5;  N3=100; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N2, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N3, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N3, 6); %Purple
    [M7, S7] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N1, 7); %Yellow

    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6' M7']';
    S = [S1 S2 S3 S4 S5 S6 S7]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
hAxis(5) = subplot(2,3,5);
    disp('Case 5');
    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple'};
    Me1=0.9; SD1=.01; N2=800;  N3=100; N4=5; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N4, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N3, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N2, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N3, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N4, 6); %Purple

    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6']';
    S = [S1 S2 S3 S4 S5 S6]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
hAxis(6) = subplot(2,3,6);
    disp('Case 6');
    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple', 'Yellow'};
    N1=50; Me1=0.9; SD1=.01; N2=5;  N3=100; N4=25;

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N4, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N3, 6); %Purple
    [M7, S7] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N3, 7); %Yellow

    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6' M7']';
    S = [S1 S2 S3 S4 S5 S6 S7]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

maximize;    

% print('-dtiff', 'd:\PCAColors_4.tif', '-r600'); close
% RemoveWhiteSpace([], 'file', 'd:\PCAColors_4.tif', 'output', 'd:\PCAColors_4clear.tif');

%% #5 - Many admixed populations
close all;
clc

figure
hAxis = [];
hAxis_num = 4;
hAxis(1) = subplot(2,2,1);
    disp('Case 1');
    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple', 'Yellow', 'Mx1', 'Mx2', 'Mx3', 'Mx4', 'Mx5'};
    N1=50; Me1=1; Me2=0.5; Me3=0.1; SD1=.01; N2=5;  N3=100; N4=25; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 6); %Purple
    [M7, S7] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N1, 7); %Yellow
    [M8, S8] = Generate_nonrandom_colors([Me1 Me2 Me1], SD1, N1, 8); %Mx1
    [M9, S9] = Generate_nonrandom_colors([0 Me3 Me2], SD1, N1, 9); %Mx2
    [M10, S10] = Generate_nonrandom_colors([Me2 0 Me1], SD1, N1, 10); %Mx3
    [M11, S11] = Generate_nonrandom_colors([0 Me2 Me1], SD1, N1, 11); %Mx4
    [M12, S12] = Generate_nonrandom_colors([Me3 Me2 0], SD1, N1, 12); %Mx5

    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6' M7' M8' M9' M10' M11' M12']';
    S = [S1 S2 S3 S4 S5 S6 S7 S8 S9 S10 S11 S12]';

    [SCORE, ~, pcvars] = pca1(M);
    [D_color, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S);

hAxis(2) = subplot(2,2,2);
    disp('Case 2');
    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple', 'Yellow', 'Mx1', 'Mx2', 'Mx3', 'Mx4', 'Mx5'};
    N1=50; Me1=1; Me2=0.5; Me3=0.1; SD1=.01; N2=10;  N3=100; N4=25; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N2, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N2, 6); %Purple
    [M7, S7] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N1, 7); %Yellow

    [M8, S8] = Generate_nonrandom_colors([Me3 Me2 Me1], SD1, N1, 8); %Mx1 - light blue
    [M9, S9] =   Generate_nonrandom_colors([0 Me3 Me2], SD1, N2, 9); %Mx2 - blue
    [M10, S10] = Generate_nonrandom_colors([Me2 0 Me1], SD1, N1, 10); %Mx3 dark purple
    [M11, S11] = Generate_nonrandom_colors([0 Me2 Me1], SD1, N1, 11); %Mx4 light blue
    [M12, S12] = Generate_nonrandom_colors([Me2 Me2 0], SD1, N1, 12); %Mx5 - brown-green

    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6' M7' M8' M9' M10' M11' M12']';
    S = [S1 S2 S3 S4 S5 S6 S7 S8 S9 S10 S11 S12]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S);
    
hAxis(3) = subplot(2,2,3);
    disp('Case 3');
    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple', 'Yellow', 'Mx1', 'Mx2', 'Mx3', 'Mx4', 'Mx5'};
    N1=50; Me1=1; Me2=0.5; Me3=0.1; SD1=.01; N2=5;  N3=100; N4=25; 

    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N2, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N3, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N2, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N4, 6); %Purple
    [M7, S7] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N1, 7); %Yellow
    [M8, S8] = Generate_nonrandom_colors([Me1 Me2 Me1], SD1, N1, 8); %Mx1
    [M9, S9] = Generate_nonrandom_colors([0 Me3 Me2], SD1, N2, 9); %Mx2
    [M10, S10] = Generate_nonrandom_colors([0 0 Me2], SD1, N1, 10); %Mx3
    [M11, S11] = Generate_nonrandom_colors([0 Me2 Me1], SD1, N4, 11); %Mx4
    [M12, S12] = Generate_nonrandom_colors([0 Me2 0], SD1, N1, 12); %Mx5

    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6' M7' M8' M9' M10' M11' M12']';
    S = [S1 S2 S3 S4 S5 S6 S7 S8 S9 S10 S11 S12]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S);
    
hAxis(4) = subplot(2,2,4);
    disp('Case 4');
    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple', 'Yellow', 'Mx1', 'Mx2', 'Mx3', 'Mx4', 'Mx5', 'Mx6', 'Mx7', 'Mx8', 'Mx9', 'Mx10'};
    N1=50; Me1=1; Me2=0.5; Me3=0.1; Me4=0.25; SD1=.01; N2=5;  N3=100; N4=25; 

    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N2, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N3, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N2, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N4, 6); %Purple
    [M7, S7] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N1, 7); %Yellow

    [M8, S8] = Generate_nonrandom_colors([Me1 Me2 Me1], SD1, N1, 8); %Mx1
    [M9, S9] = Generate_nonrandom_colors([0 Me3 Me2], SD1, N2, 9); %Mx2
    [M10, S10] = Generate_nonrandom_colors([0 0 Me2], SD1, N1, 10); %Mx3
    [M11, S11] = Generate_nonrandom_colors([0 Me2 Me1], SD1, N4, 11); %Mx4
    [M12, S12] = Generate_nonrandom_colors([0 Me2 0], SD1, N1, 12); %Mx5

    [M13, S13] = Generate_nonrandom_colors([Me4 Me2 Me1], SD1, N1, 13); %Mx6
    [M14, S14] = Generate_nonrandom_colors([Me4 Me3 Me2], SD1, N2, 14); %Mx7
    [M15, S15] = Generate_nonrandom_colors([0 0 Me4], SD1, N1, 15); %Mx8
    [M16, S16] = Generate_nonrandom_colors([Me4 Me2 Me1], SD1, N4, 16); %Mx9
    [M17, S17] = Generate_nonrandom_colors([0 Me2 Me4], SD1, N1, 17); %Mx10

    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6' M7' M8' M9' M10' M11' M12' M13' M14' M15' M16' M17']';
    S = [S1 S2 S3 S4 S5 S6 S7 S8 S9 S10 S11 S12 S13 S14 S15 S16 S17]';

    [SCORE, ~, pcvars] = pca1(M);
    [D_color, D_pos, mean_pos, mean_color] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S);

    %Compare the PC1+2 distances to the real distances
    CompareDist(mean_color, mean_pos);

maximize;

% print('-dtiff', 'd:\PCAColors_5.tif', '-r600'); close
% RemoveWhiteSpace([], 'file', 'd:\PCAColors_5.tif', 'output', 'd:\PCAColors_5clear.tif');

%% #6 - Using secondary colors instead of the primary colors led to completely random results
global Colors_names;
close all;
clc

Colors_names = {'Black', 'Yellow', 'Cyan', 'Purple', 'Orange'};
N1=50; Me1=0.9; Me2=0.5; Me3=0.1; SD1=.01; N2=0;  
    
figure
hAxis = [];
hAxis_num = 6;
hAxis(1) = subplot(2,3,1);
    disp('Case 1');
    [M1, S1] = Generate_nonrandom_colors([0 0 0], SD1, N1, 1); %Black
    [M2, S2] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N1, 2); %Yellow
    [M3, S3] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 3); %Cyan
    [M4, S4] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 4); %Purple

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
hAxis(2) = subplot(2,3,2);
    disp('Case 2');
    [M1, S1] = Generate_nonrandom_colors([0 0 0], SD1, N1, 1); %Black
    [M2, S2] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N1, 2); %Yellow
    [M3, S3] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 3); %Cyan
    [M4, S4] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 4); %Purple

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

hAxis(3) = subplot(2,3,3);
    disp('Case 3');
    [M1, S1] = Generate_nonrandom_colors([0 0 0], SD1, N1, 1); %Black
    [M2, S2] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N1, 2); %Yellow
    [M3, S3] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 3); %Cyan
    [M4, S4] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 4); %Purple

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)

hAxis(4) = subplot(2,3,4);
    disp('Case 4');
    [M1, S1] = Generate_nonrandom_colors([0 0 0], SD1, N1, 1); %Black
    [M2, S2] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N1, 2); %Yellow
    [M3, S3] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 3); %Cyan
    [M4, S4] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 4); %Purple
    [M5, S5] = Generate_nonrandom_colors([Me1 Me1 Me1], SD1, N1, 5); %White

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
hAxis(5) = subplot(2,3,5);
    disp('Case 5');
    [M1, S1] = Generate_nonrandom_colors([0 0 0], SD1, N1, 1); %Black
    [M2, S2] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N1, 2); %Yellow
    [M3, S3] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 3); %Cyan
    [M4, S4] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 4); %Purple
    [M5, S5] = Generate_nonrandom_colors([Me1 Me1 Me1], SD1, N1, 5); %White

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
    
hAxis(6) = subplot(2,3,6);
    disp('Case 6');
    [M1, S1] = Generate_nonrandom_colors([0 0 0], SD1, N1, 1); %Black
    [M2, S2] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N1, 2); %Yellow
    [M3, S3] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 3); %Cyan
    [M4, S4] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 4); %Purple
    [M5, S5] = Generate_nonrandom_colors([Me1 Me1 Me1], SD1, N1, 5); %White

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

    disp('Measuring the error for each color (count as 1)')
    Main_ColorStat(M, SCORE, 1, S)
maximize;

% print('-dtiff', 'd:\PCAColors_6.tif', '-r600'); close
% RemoveWhiteSpace([], 'file', 'd:\PCAColors_6.tif', 'output', 'd:\PCAColors_6clear.tif');

%% #7 - pairwise comparisons (1)
global Colors_names;
close all;
clc

figure
hAxis = [];
hAxis_num = 4;

% Two separate populations appear distinct
hAxis(1) = subplot(2,2,1);
    disp('Case 1');
    Colors_names = {'Blue1', 'Blue2'};

    N1=50; Me1=0.9; Me2=0.5; Me3=0.05/2; SD1=.01; N2=0;  N3=100; N4=25; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me3 0  Me1 ], SD1/2, N1, 1); %Blue1
    [M2, S2] = Generate_nonrandom_colors([0 Me3 Me1], SD1/2, N1, 2); %Blue2

    % Add all Mats
    M = [M1' M2']';
    S = [S1 S2 ]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 
    disp(pcvars./sum(pcvars))

% The two separate populations are merged via PCA
hAxis(2) = subplot(2,2,2);
    disp('Case 2');
    
    Colors_names = {'Blue1', 'Blue2', 'Yellow'};

    N1=50; Me1=0.9; Me2=0.5; Me3=0.05/2; SD1=.01; N2=0;  N2=1; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me3 0  Me1 ], SD1/2, N1, 1); %Blue1
    [M2, S2] = Generate_nonrandom_colors([0 Me3 Me1], SD1/2, N1, 2); %Blue2
    [M3, S3] = Generate_nonrandom_colors([0 0.5 0], SD1, N2, 3); % Green
    [M4, S4] = Generate_nonrandom_colors([1 1 1], SD1, N2, 4); % White

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 
    disp(pcvars./sum(pcvars))

    % Two populations overlap
hAxis(3) = subplot(2,2,3);

    disp('Case 3');
    Colors_names = {'L Green1', 'L Green2', 'Yellow', 'Green', 'Red'};
    N1=50; Me1=0.9; Me2=0.8; Me3=0.1; SD1=.01; N2=0;  SD3=0.015; N3=100; N4=25; 

    % Primary cohorts
    [M1, S1] = Generate_nonrandom_colors([0.5 1 0.5], SD3, N1, 1);%light green 1
    [M2, S2] = Generate_nonrandom_colors([0.6 1 0.5], SD3, N1, 2);%light green 2
    [M3, S3] = Generate_nonrandom_colors([Me1 Me1 Me3], SD1, 250, 3); %Yellow 
    [M4, S4] = Generate_nonrandom_colors([Me3 Me1 Me3], SD1, 250, 5); %Green
    [M5, S5] = Generate_nonrandom_colors([Me1 Me3 Me3], SD1, 250, 6); %Red

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 
    disp(pcvars./sum(pcvars))

% The two populations are split by PCA
hAxis(4) = subplot(2,2,4);
    disp('Case 4');
    
    Colors_names = {'L Green1', 'L Green2', 'White', 'Purple', 'Yellow'};
    Me3=0.1; SD1=.01; N2=5;  N3=500; N4=0; 

    [M3, S3] = Generate_nonrandom_colors([Me1 Me1 Me1], SD1, 250, 3); %White 
    [M4, S4] = Generate_nonrandom_colors([Me1 Me3 Me1], SD1, 250, 5); %Purple
    [M5, S5] = Generate_nonrandom_colors([Me1 Me1 Me3], SD1, 250, 6); %Yellow

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 
    disp(pcvars./sum(pcvars))
    
maximize

% print('-dtiff', 'd:\PCAColors_7.tif', '-r600'); close
% RemoveWhiteSpace([], 'file', 'd:\PCAColors_7.tif', 'output', 'd:\PCAColors_7clear.tif');

%% #7 - pairwise comparisons (2)
% Analyze PC2 and PC3 of the former populations

global Colors_names;
close all;
clc

figure
hAxis = [];
hAxis_num = 4;

% Two separate populations appear distinct
hAxis(1) = subplot(2,2,1);
    disp('Case 1');
    Colors_names = {'Blue1', 'Blue2'};

    N1=50; Me1=0.9; Me2=0.5; Me3=0.05/2; SD1=.01; N2=0;  N3=100; N4=25; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me3 0  Me1 ], SD1/2, N1, 1); %Blue1
    [M2, S2] = Generate_nonrandom_colors([0 Me3 Me1], SD1/2, N1, 2); %Blue2

    % Add all Mats
    M = [M1' M2']';
    S = [S1 S2 ]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE(:,2:3), pcvars, mean_pos, D_pos, hAxis, hAxis_num); 
    disp(pcvars./sum(pcvars))

% The two separate populations are merged via PCA
hAxis(2) = subplot(2,2,2);
    disp('Case 2');
    
    Colors_names = {'Blue1', 'Blue2', 'Yellow'};

    N1=50; Me1=0.9; Me2=0.5; Me3=0.05/2; SD1=.01; N2=0;  N2=1; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me3 0  Me1 ], SD1/2, N1, 1); %Blue1
    [M2, S2] = Generate_nonrandom_colors([0 Me3 Me1], SD1/2, N1, 2); %Blue2
    [M3, S3] = Generate_nonrandom_colors([0 0.5 0], SD1, N2, 3); % Green
    [M4, S4] = Generate_nonrandom_colors([1 1 1], SD1, N2, 4); % White

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE(:,2:3), pcvars, mean_pos, D_pos, hAxis, hAxis_num); 
    disp(pcvars./sum(pcvars))

    % Two populations overlap
hAxis(3) = subplot(2,2,3);

    disp('Case 3');
    Colors_names = {'L Green1', 'L Green2', 'Yellow', 'Green', 'Red'};
    N1=50; Me1=0.9; Me2=0.8; Me3=0.1; SD1=.01; N2=0;  SD3=0.015; N3=100; N4=25; 

    % Primary cohorts
    [M1, S1] = Generate_nonrandom_colors([0.5 1 0.5], SD3, N1, 1);%light green 1
    [M2, S2] = Generate_nonrandom_colors([0.6 1 0.5], SD3, N1, 2);%light green 2
    [M3, S3] = Generate_nonrandom_colors([Me1 Me1 Me3], SD1, 250, 3); %Yellow 
    [M4, S4] = Generate_nonrandom_colors([Me3 Me1 Me3], SD1, 250, 5); %Green
    [M5, S5] = Generate_nonrandom_colors([Me1 Me3 Me3], SD1, 250, 6); %Red

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE(:,2:3), pcvars, mean_pos, D_pos, hAxis, hAxis_num); 
    disp(pcvars./sum(pcvars))

% The two populations are split by PCA
hAxis(4) = subplot(2,2,4);
    disp('Case 4');
    
    Colors_names = {'L Green1', 'L Green2', 'White', 'Purple', 'Yellow'};
    Me3=0.1; SD1=.01; N2=5;  N3=500; N4=0; 

    [M3, S3] = Generate_nonrandom_colors([Me1 Me1 Me1], SD1, 250, 3); %White 
    [M4, S4] = Generate_nonrandom_colors([Me1 Me3 Me1], SD1, 250, 5); %Purple
    [M5, S5] = Generate_nonrandom_colors([Me1 Me1 Me3], SD1, 250, 6); %Yellow

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE(:,2:3), pcvars, mean_pos, D_pos, hAxis, hAxis_num); 
    disp(pcvars./sum(pcvars))
    
maximize

print('-dtiff', 'd:\PCAColors_7_2.tif', '-r600'); close
RemoveWhiteSpace([], 'file', 'd:\PCAColors_7_2.tif', 'output', 'd:\PCAColors_7_2clear.tif');

%% #7 - pairwise comparisons (3)
% Analyze PC1 and PC3 of the former populations

global Colors_names;
close all;
clc

figure
hAxis = [];
hAxis_num = 4;

% Two separate populations appear distinct
hAxis(1) = subplot(2,2,1);
    disp('Case 1');
    Colors_names = {'Blue1', 'Blue2'};

    N1=50; Me1=0.9; Me2=0.5; Me3=0.05/2; SD1=.01; N2=0;  N3=100; N4=25; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me3 0  Me1 ], SD1/2, N1, 1); %Blue1
    [M2, S2] = Generate_nonrandom_colors([0 Me3 Me1], SD1/2, N1, 2); %Blue2

    % Add all Mats
    M = [M1' M2']';
    S = [S1 S2 ]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, [SCORE(:,1) SCORE(:,3)], pcvars, mean_pos, D_pos, hAxis, hAxis_num); 
    disp(pcvars./sum(pcvars))

% The two separate populations are merged via PCA
hAxis(2) = subplot(2,2,2);
    disp('Case 2');
    
    Colors_names = {'Blue1', 'Blue2', 'Yellow'};

    N1=50; Me1=0.9; Me2=0.5; Me3=0.05/2; SD1=.01; N2=0;  N2=1; 

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me3 0  Me1 ], SD1/2, N1, 1); %Blue1
    [M2, S2] = Generate_nonrandom_colors([0 Me3 Me1], SD1/2, N1, 2); %Blue2
    [M3, S3] = Generate_nonrandom_colors([0 0.5 0], SD1, N2, 3); % Green
    [M4, S4] = Generate_nonrandom_colors([1 1 1], SD1, N2, 4); % White

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, [SCORE(:,1) SCORE(:,3)], pcvars, mean_pos, D_pos, hAxis, hAxis_num); 
    disp(pcvars./sum(pcvars))

    % Two populations overlap
hAxis(3) = subplot(2,2,3);

    disp('Case 3');
    Colors_names = {'L Green1', 'L Green2', 'Yellow', 'Green', 'Red'};
    N1=50; Me1=0.9; Me2=0.8; Me3=0.1; SD1=.01; N2=0;  SD3=0.015; N3=100; N4=25; 

    % Primary cohorts
    [M1, S1] = Generate_nonrandom_colors([0.5 1 0.5], SD3, N1, 1);%light green 1
    [M2, S2] = Generate_nonrandom_colors([0.6 1 0.5], SD3, N1, 2);%light green 2
    [M3, S3] = Generate_nonrandom_colors([Me1 Me1 Me3], SD1, 250, 3); %Yellow 
    [M4, S4] = Generate_nonrandom_colors([Me3 Me1 Me3], SD1, 250, 5); %Green
    [M5, S5] = Generate_nonrandom_colors([Me1 Me3 Me3], SD1, 250, 6); %Red

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, [SCORE(:,1) SCORE(:,3)], pcvars, mean_pos, D_pos, hAxis, hAxis_num); 
    disp(pcvars./sum(pcvars))

% The two populations are split by PCA
hAxis(4) = subplot(2,2,4);
    disp('Case 4');
    
    Colors_names = {'L Green1', 'L Green2', 'White', 'Purple', 'Yellow'};
    Me3=0.1; SD1=.01; N2=5;  N3=500; N4=0; 

    [M3, S3] = Generate_nonrandom_colors([Me1 Me1 Me1], SD1, 250, 3); %White 
    [M4, S4] = Generate_nonrandom_colors([Me1 Me3 Me1], SD1, 250, 5); %Purple
    [M5, S5] = Generate_nonrandom_colors([Me1 Me1 Me3], SD1, 250, 6); %Yellow

    % Add all Mats
    M = [M1' M2' M3' M4' M5']';
    S = [S1 S2 S3 S4 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, [SCORE(:,1) SCORE(:,3)], pcvars, mean_pos, D_pos, hAxis, hAxis_num); 
    disp(pcvars./sum(pcvars))

maximize

print('-dtiff', 'd:\PCAColors_7_3.tif', '-r600'); close
RemoveWhiteSpace([], 'file', 'd:\PCAColors_7_3.tif', 'output', 'd:\PCAColors_7_3clear.tif');

%% #8 - Case-control pre-analysis
global Colors_names;
clc

N1=1000; N2=250; Me1=0.9; Me3=0.1; Me5=0.5; SD2=0.05; SD4=0.17; 

%These are the results of public participants who self-reported as blue
figure
hAxis = [];
hAxis_num = 4;
hAxis(1) = subplot(2,2,1);
    disp('Case 1');
    [M1, S1] = Generate_nonrandom_colors([Me3 Me5 Me1], SD4, N1, 1); %Public samples

    %Plotting just the collected samples
    M = [M1']';
    S = [S1]';

    Plot_3d(M)
    whitebg('w'); %affects the first plot
    axis square; axis equal;
    
hAxis(2) = subplot(2,2,2);
    disp('Case 2');
    [M2, S2] = Generate_nonrandom_colors([Me1 Me1 0], SD2, N2, 2); %Yellow
    [M3, S3] = Generate_nonrandom_colors([Me1 0  Me1], SD2, N2, 3); %Purple
    [M4, S4] = Generate_nonrandom_colors([Me5 0  Me5], SD2, N2, 4); %dark Purple
    [M5, S5] = Generate_nonrandom_colors([0 0 Me1], SD2, N2, 5); %Blue
    [M6, S6] = Generate_nonrandom_colors([0 Me5 0], SD2, N2, 6); %Light green
    [M7, S7] = Generate_nonrandom_colors([Me3 Me3 Me3], SD2, N2, 7); %Black
    [M8, S8] = Generate_nonrandom_colors([0 Me1 0], SD2, N2, 8); %Green
    [M9, S9] = Generate_nonrandom_colors([Me1 0 Me5], SD2, N2, 9); %Light red
    
    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6' M7' M8' M9']';
    S = [S1 S2 S3 S4 S5 S6 S7 S8 S9]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

hAxis(3) = subplot(2,2,3);
    disp('Case 3');
    % Add all Mats
    M = [M1' M5']';
    S = [S1 S5]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

hAxis(4) = subplot(2,2,4);
    disp('Case 4');
    [M11, S11] = Generate_nonrandom_colors([0 Me5 Me1], SD2, N1, 11); %Light Blue

    % Add all Mats
    M = [M1' M2' M5' M7' M8' M11']';
    S = [S1  S2  S5  S7  S8  S11]';

    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num); 

maximize;

% print('-dtiff', 'd:\PCAColors_8.tif', '-r600'); close
% RemoveWhiteSpace([], 'file', 'd:\PCAColors_8.tif', 'output', 'd:\PCAColors_8clear.tif');

%% #9 Projection
% Notice the PCA function used here.
global Colors_names;
Colors_names = {}; 
clc

% Square - Original
% Circles - Projected

figure

subplot(2,2,1)
    rng(1);

    %How does projection behave when there are changes in the sample size of the original and projected dataset
    rng(1);

    N1=200; Me1=0.9; SD1=.02; Me2=0.1; N2=10; N3=300; N4=10; Me3=0.5;

    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 2); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N2, 3); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 4); %Blue
    [M4, S4] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N2, 5); %Purple

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    %It is improtant to call PCA like this
    [COEFF, SCORE, pcvars] = pca(M, 'VariableWeights', 'variance', 'Centered', true);  %The second element is the SCORE
    [D_color, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    
    %Plot the modern colors (original dataset - squares)
    for i=1:numel(SCORE(:,1))
        plot(SCORE(i,1), SCORE(i,2), 's', 'Color', M(i,:));
        hold on;
    end;

    disp('Generate the second set of colors')
    [M1, S1] = Generate_nonrandom_colors([Me1 Me2 Me2], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([Me2 Me1 Me2], SD1, N1, 1); %Green
    [M3, S3] = Generate_nonrandom_colors([Me2 Me2 Me1], SD1, N2, 1); %Blue
    [M4, S4] = Generate_nonrandom_colors([Me1 Me2  Me1], SD1, N2, 1); %Purple

    M_ = [M1' M2' M3' M4']';
    S_ = [S1 S2 S3 S4]';

    % Calculate the projection for M_ based on M
    [y, ~]= pca_projection(M_, M);

    % Add the projection of the M_ points (circle) onto the first two PC of the figure
    for i=1:size(M_,1)
        plot(y(i,1),y(i,2),'o','MarkerEdgeColor',M_(i,:));
    end;

    PCA_vals = round(pcvars/sum(pcvars)*100);
    x = sort(PCA_vals, 'descend');
    y=round(100*(x/sum(x)));
    xlabel(['PC1 (' num2str(y(1)) '%)'], 'FontName','Ariel','FontSize',12);
    ylabel(['PC2 (' num2str(y(2)) '%)'], 'FontName','Ariel','FontSize',12);
    box off;
    grid off;
    set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);
    
    %Correct the axis
    get_axis = axis; %[min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    axis_ratio = [abs(get_axis(2))/8 abs(get_axis(4))/8];
    axis([get_axis(1)-axis_ratio(1) get_axis(2)+axis_ratio(1) get_axis(3)-axis_ratio(2) get_axis(4)+axis_ratio(2)]);

    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');

subplot(2,2,2)
    rng(1);

    %How does projection behave when there is some overlap between the
    %original and projected colors
    rng(1);

    N1=200; Me1=0.9; SD1=.02; Me2=0.05; N2=10; N3=300; N4=10; Me3=0.5;

    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 2); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N2, 3); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 4); %Blue
    [M4, S4] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N2, 5); %Purple

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';
    
    %It is improtant to call PCA like this
    [COEFF, SCORE, pcvars] = pca(M, 'VariableWeights', 'variance', 'Centered', true);  %The second element is the SCORE
    [D_color, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    
    %Plot the modern colors (original dataset - squares)
    for i=1:numel(SCORE(:,1))
        plot(SCORE(i,1), SCORE(i,2), 's', 'Color', M(i,:));
        hold on;
    end;

    disp('Generate the second set of colors')
    [M1, S1] = Generate_nonrandom_colors([Me1 Me2 Me2], SD1, N2, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([Me2 Me1 Me2], SD1, N2, 1); %Green
    [M3, S3] = Generate_nonrandom_colors([Me2 Me2 Me1], SD1, N4, 1); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 Me2], SD1, N4, 1); %Black
    [M5, S5] = Generate_nonrandom_colors([Me3 Me1 Me3], SD1, 20, 1); %Light Green

    M_ = [M1' M2' M3' M4' M5']';
    S_ = [S1 S2 S3 S4 S5]';

    % Calculate the projection for M_ based on M
    [y, ~]= pca_projection(M_, M);

    % Add the projection of the M_ points (circle) onto the first two PC of the figure
    for i=1:size(M_,1)
        plot(y(i,1),y(i,2),'o','MarkerEdgeColor',M_(i,:));
    end;

    PCA_vals = round(pcvars/sum(pcvars)*100);
    x = sort(PCA_vals, 'descend');
    y=round(100*(x/sum(x)));
    xlabel(['PC1 (' num2str(y(1)) '%)'], 'FontName','Ariel','FontSize',12);
    ylabel(['PC2 (' num2str(y(2)) '%)'], 'FontName','Ariel','FontSize',12);
    box off;
    grid off;
    set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);
    
    %Correct the axis
    get_axis = axis; %[min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    axis_ratio = [abs(get_axis(2))/8 abs(get_axis(4))/8];
    axis([get_axis(1)-axis_ratio(1) get_axis(2)+axis_ratio(1) get_axis(3)-axis_ratio(2) get_axis(4)+axis_ratio(2)]);

    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');


% Projecting colors from one dataset onto another
subplot(2,2,3)
    %How does projection behave when there is some overlap between the
    %original and projected colors
    rng(1);

    N1=200; Me1=0.9; SD1=.02; Me2=0.05; N2=10; N3=300; N4=25; Me3=0.5;

    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 2); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N2, 3); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 4); %Blue
    [M4, S4] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N2, 5); %Purple

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';
    
    %It is improtant to call PCA like this
    [COEFF, SCORE, pcvars] = pca(M, 'VariableWeights', 'variance', 'Centered', true);  %The second element is the SCORE
    [D_color, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    
    %Plot the modern colors (original dataset - squares)
    for i=1:numel(SCORE(:,1))
        plot(SCORE(i,1), SCORE(i,2), 's', 'Color', M(i,:));
        hold on;
    end;

    disp('Generate the second set of colors')
    [M3, S3] = Generate_nonrandom_colors([Me1 Me1 Me1], SD1, N4, 1); %White
    [M4, S4] = Generate_nonrandom_colors([Me2 Me2 Me2], SD1, N4, 1); %Black
    [M5, S5] = Generate_nonrandom_colors([Me3 Me3 Me3], SD1, N4, 1); %Grey

    M_ = [M3' M4' M5']';
    S_ = [S3 S4 S5]';

    % Calculate the projection for M_ based on M
    [y, ~]= pca_projection(M_, M);

    % Add the projection of the M_ points (circle) onto the first two PC of the figure
    for i=1:size(M_,1)
        plot(y(i,1),y(i,2),'o','MarkerEdgeColor',M_(i,:));
    end;

    PCA_vals = round(pcvars/sum(pcvars)*100);
    x = sort(PCA_vals, 'descend');
    y=round(100*(x/sum(x)));
    xlabel(['PC1 (' num2str(y(1)) '%)'], 'FontName','Ariel','FontSize',12);
    ylabel(['PC2 (' num2str(y(2)) '%)'], 'FontName','Ariel','FontSize',12);
    box off;
    grid off;
    set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);
    
    %Correct the axis
    get_axis = axis; %[min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    axis_ratio = [abs(get_axis(2))/8 abs(get_axis(4))/8];
    axis([get_axis(1)-axis_ratio(1) get_axis(2)+axis_ratio(1) get_axis(3)-axis_ratio(2) get_axis(4)+axis_ratio(2)]);

    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');

subplot(2,2,4)
    %How does projection behave when there is no overlap between the
    %original and projected colors
    rng(1);
    
    N1=10; Me1=0.9; SD1=.02;

    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 3); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 4); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 5); %Cyan

    % Add all Mats
    M = [M2' M3' M4']';
    S = [S2 S3 S4]';
    
    %It is improtant to call PCA like this
    [COEFF, SCORE, pcvars] = pca(M, 'VariableWeights', 'variance', 'Centered', true);  %The second element is the SCORE
    [D_color, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
%     plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos);

    %Plot different colors (original dataset - squares)
    for i=1:numel(SCORE(:,1))
        plot(SCORE(i,1), SCORE(i,2), 's', 'Color', M(i,:));
        hold on;
    end;

    disp('Generate the second set of colors')
    [M3, S3] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 3); %Red
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([Me1 Me1 0 ], SD1, N1, 5); %Yellow

    M_ = [M3' M4' M5']';
    S_ = [S3 S4 S5]';

    % Calculate the projection for M_ based on M
    [y, ~]= pca_projection(M_, M);

    % Add the projection of the M_ points (circle) onto the first two principal components to the figure
    for i=1:size(M_,1)
        plot(y(i,1),y(i,2),'o','MarkerEdgeColor',M_(i,:));
    end;

    PCA_vals = round(pcvars/sum(pcvars)*100);
    x = sort(PCA_vals, 'descend');
    y=round(100*(x/sum(x)));
    xlabel(['PC1 (' num2str(y(1)) '%)'], 'FontName','Ariel','FontSize',12);
    ylabel(['PC2 (' num2str(y(2)) '%)'], 'FontName','Ariel','FontSize',12);
    box off;
    grid off;
    set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);    

    %Correct the axis
    get_axis = axis; %[min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    axis_ratio = [abs(get_axis(2))/8 abs(get_axis(4))/8];
    axis([get_axis(1)-axis_ratio(1) get_axis(2)+axis_ratio(1) get_axis(3)-axis_ratio(2) get_axis(4)+axis_ratio(2)]);

    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');
    
    maximize

% print('-dtiff', 'd:\PCAColors_9.tif', '-r600'); close
% RemoveWhiteSpace([], 'file', 'd:\PCAColors_9.tif', 'output', 'd:\PCAColors_9clear.tif');

%% #10 - Ancient DNA
% Assume that the range of 1-0.8 is reserved to aDNA. The rest is modern.
% Can we infer the relationships between old and modern from these data?
% Here, we are asking 2 quesitons? 
% 1) Are the relationships of "ancient" and "modern" can be properly reflected on the PCA plot? 
% 2) Are the relationships of "ancient" and "modern" can be properly reflected on the projected plot?

global Colors_names;
Colors_names = {};
clc

N1=10; N2=15; N3=25; N4=20; N5=75; 
Me1=0.95; SD1=.05; 
Me2=0.6; SD2=.02; 

%Plotting both ancient and modern together. We expect the ancient
%colors to be close to their most similar modern colors, as is the case.
figure
hAxis = [];
hAxis_num = 4;
hAxis(1) = subplot(2,2,1);
    rng(1)
    disp('Case 1');

    %Generate ancient colors (sample size is typical to aDNA pops) - circle
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0 ], SD1, N3, 1); %aRed
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N3, 1); %aGreen
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 1); %aBlue

    %Generate modern colors - squares -
    [M4, S4] = Generate_nonrandom_colors([Me2 0 0], SD2, N5, 4); %mRed
    [M5, S5] = Generate_nonrandom_colors([Me2 Me2 0], SD2, N5, 5); %mYellow
    [M6, S6] = Generate_nonrandom_colors([0 Me2 Me2], SD2, N5, 6); %mCyan
    [M7, S7] = Generate_nonrandom_colors([0 0 0], SD2, N5, 7); %mBlack
    [M8, S8] = Generate_nonrandom_colors([0 Me2 0], SD2, N5, 8); %mGreen
    [M9, S9] = Generate_nonrandom_colors([0 0 Me2], SD2, N5, 9); %mBlue
    [M10, S10] = Generate_nonrandom_colors([Me2 0 Me2], SD2, N5, 10); %mPurple
    
    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6' M7' M8' M9' M10']';
    S = [S1 S2 S3 S4 S5 S6 S7 S8 S9 S10]';
    [SCORE, ~, pcvars] = pca1(M);  %pc is the SCORE
    [D_color, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);
    
hAxis(2) = subplot(2,2,2);
    rng(1)
    disp('Case 2');

    %Generate ancient colors (sample size is typical to aDNA pops) - circle
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0 ], SD1, N1, 1); %aRed
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 1); %aGreen
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 1); %aBlue

    %Generate modern colors - squares
    [M4, S4] = Generate_nonrandom_colors([Me2 0 Me2], SD2, N2, 4); %mPurple
    [M5, S5] = Generate_nonrandom_colors([Me2 Me2 0], SD2, N4, 5); %mYellow
    [M6, S6] = Generate_nonrandom_colors([0 Me2 Me2], SD2, N2, 6); %mCyan
    [M7, S7] = Generate_nonrandom_colors([0 0 0], SD2, N5, 7); %mBlack
    [M8, S8] = Generate_nonrandom_colors([0 Me2 0], SD2, N4, 8); %mGreen
    [M9, S9] = Generate_nonrandom_colors([0 0 Me2], SD2, N1, 9); %mBlue
    
    % Add all Mats
    M = [M1' M2' M3' M4' M5' M6' M7' M8' M9']';
    S = [S1 S2 S3 S4 S5 S6 S7 S8 S9]';
    [SCORE, ~, pcvars] = pca1(M);  %pc is the SCORE
    [D_color, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

hAxis(3) = subplot(2,2,3);
    rng(1)
    disp('Case 3');

    %Generate modern colors - squares
    [M4, S4] = Generate_nonrandom_colors([Me2 0 Me2], SD2, N5, 4); %mPurple
    [M5, S5] = Generate_nonrandom_colors([Me2 Me2 0], SD2, N2, 5); %mYellow
    [M6, S6] = Generate_nonrandom_colors([0 Me2 Me2], SD2, N2, 6); %mCyan
    [M7, S7] = Generate_nonrandom_colors([0 0 0], SD2, N5, 7); %mBlack
    [M8, S8] = Generate_nonrandom_colors([0 Me2 0], SD2, N4, 8); %mGreen
    [M9, S9] = Generate_nonrandom_colors([0 0 Me2], SD2, N1, 9); %mBlue

    % Add all Mats
    M = [M4' M5' M6' M7' M8' M9']';
    S = [S4 S5 S6 S7 S8 S9]';

    %It is improtant to call PCA like this
    [COEFF, SCORE, pcvars] = pca(M, 'VariableWeights', 'variance', 'Centered', true); 
    [D_color, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);

    %Plot different colors
    for i=1:numel(SCORE(:,1))
        plot(SCORE(i,1), SCORE(i,2),'s', 'Color', M(i,:));
        hold on;
    end;

    disp('Project ancient colors into modern ones')
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0 ], SD1, N2, 1); %aRed
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N2, 2); %aGreen
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N2, 3); %aBlue

    M_ = [M1' M2' M3']';
    S_ = [S1 S2 S3]';

    % Calculate the projection for the new color
    [y Y]= pca_projection(M_, M);

    % And the projection of the point onto the first two principal components can be added to the figure in the same way:
    for i=1:size(M_,1)
        plot(y(i,1),y(i,2),'o','MarkerEdgeColor',M_(i,:));
    end;

    % Calculate the explained variance by each PC
    PCA_vals = round(pcvars/sum(pcvars)*100);
    x = sort(PCA_vals, 'descend');
    y=round(100*(x/sum(x)));
    xlabel(['PC1 (' num2str(y(1)) '%)'], 'FontName','Ariel','FontSize',12);
    ylabel(['PC2 (' num2str(y(2)) '%)'], 'FontName','Ariel','FontSize',12);
    box off;
    grid off;
    set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);
    whitebg('w'); %affects the first plot
    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');
    pos = [0.16 0.12 0.3 0.37];
    set(hAxis(3), 'Position', pos);
    
hAxis(4) = subplot(2,2,4);
    rng(1)
    disp('Case 4');

    %Generate modern colors - squares
    [M4, S4] = Generate_nonrandom_colors([Me2 0 Me2], SD2, N1, 4); %Purple
    [M5, S5] = Generate_nonrandom_colors([Me2 Me2 0], SD2, N5, 5); %mYellow
    [M6, S6] = Generate_nonrandom_colors([0 Me2 Me2], SD2, N2, 6); %mCyan
    [M7, S7] = Generate_nonrandom_colors([0 0 0], SD2, N5, 7); %mBlack
    [M8, S8] = Generate_nonrandom_colors([0 Me2 0], SD2, N2, 5); %mGreen
    [M9, S9] = Generate_nonrandom_colors([0 0 Me2], SD2, N5, 6); %mBlue

    % Add all Mats
    M = [M4' M5' M6' M7' M8' M9']';
    S = [S4 S5 S6 S7 S8 S9]';

    %It is improtant to call PCA like this
    [COEFF, SCORE, pcvars] = pca(M, 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE
    [D_color, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);

    %Plot different colors
    for i=1:numel(SCORE(:,1))
        plot(SCORE(i,1), SCORE(i,2),'s', 'Color', M(i,:));
        hold on;
    end;

    disp('Project ancient colors into modern ones')
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0 ], SD1, N3, 1); %aRed
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N3, 2); %aGreen
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 3); %aBlue

    M_ = [M1' M2' M3']';
    S_ = [S1 S2 S3]';

    % Calculate the projection for the new color
    [y Y]= pca_projection(M_, M);

    % And the projection of the point onto the first two principal components can be added to the figure in the same way:
    for i=1:size(M_,1)
        plot(y(i,1),y(i,2),'o','MarkerEdgeColor',M_(i,:));
    end;

    % Calculate the explained variance by each PC
    PCA_vals = round(pcvars/sum(pcvars)*100);
    x = sort(PCA_vals, 'descend');
    y=round(100*(x/sum(x)));
    xlabel(['PC1 (' num2str(y(1)) '%)'], 'FontName','Ariel','FontSize',12);
    ylabel(['PC2 (' num2str(y(2)) '%)'], 'FontName','Ariel','FontSize',12);
    box off;
    grid off;
    set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);
    whitebg('w'); %affects the first plot
    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');
    pos = [0.5 0.12 0.3 0.37];
    set(hAxis(4), 'Position', pos);
    
    maximize

% print('-dtiff', 'd:\PCAColors_10.tif', '-r600'); close
% RemoveWhiteSpace([], 'file', 'd:\PCAColors_10.tif', 'output', 'd:\PCAColors_10_clear.tif');

%% #11 - Choice of markers
global Colors_names;
close all
clc

figure
hAxis = [];
hAxis_num = 6;
hAxis(1) = subplot(2,3,1);
    rng(1)
    disp('Case 1');
    
    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple'};
    N1=50; Me1=0.9; SD1=.01; win_size=200;
    miss_level = 0.5;

    % Main colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 6); %Purple

    %Convert to windowed data. This is done by taking each of the 3 values for colors and divide it by the number of windows.
    %for example, if we had [1] and window size is 10, we'll have [0.1 0.1
    %0.1 0.1 ... 10 times]. This reduces the signal of the original color.
    M = [M1' M2' M3' M4' M5' M6']';
    M_ = Colors2Window(M, win_size); %spread the signal from each component over win_size markers

    % Missingness
    for i=1:size(M_,1)
        M_(i,randsample(numel(M_(i,:)), round(numel(M_(i,:))*miss_level) )) = NaN;
    end;

    %The sum of all numbers in each window, this will recover the original 3-color structure
    M_f = [nansum(M_(:,1:win_size),2) nansum(M_(:,win_size+1:win_size*2),2) nansum(M_(:,2*win_size+1:end),2) ];
    
    % Add all Mats
    S = [S1 S2 S3 S4 S5 S6 ]';
    [SCORE, ~, pcvars] = pca1(M_f);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

hAxis(2) = subplot(2,3,2);
    rng(1)
    disp('Case 2');

    %Increasing to 90% missingness - the original structure is maintained
    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple'};
    N1=50; Me1=0.9; SD1=.01; win_size=100;
    miss_level = 0.9;

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 6); %Purple

    %Convert to windowed data. 
    M = [M1' M2' M3' M4' M5' M6']';
    M_ = Colors2Window(M, win_size); %spread the signal from each component over win_size markers
    
    % Missingness at 90%
    for i=1:size(M_,1)
        M_(i,randsample(numel(M_(i,:)), round(numel(M_(i,:))*miss_level) )) = NaN;
    end;

    %The sum of all numbers in each window, this will recover the original 3-color structure
    M_f = [nansum(M_(:,1:win_size),2) nansum(M_(:,win_size+1:win_size*2),2) nansum(M_(:,2*win_size+1:end),2) ];

    % Add all Mats
    S = [S1 S2 S3 S4 S5 S6 ]';
    [SCORE, ~, pcvars] = pca1(M_f);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

hAxis(3) = subplot(2,3,3);
    rng(1)
    disp('Case 3');
    
    %Adding markers but with noise. These are equivalent to SNPs that show
    %no population structure, like exome SNPs
    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple'};
    N1=50; Me1=0.9; SD1=.01; win_size=100;
    miss_level = 0.9;

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 6); %Purple

    %Convert to windowed data. 
    % -- Adding random noise -- (unlike in the previous analysis)
    M = [M1' M2' M3' M4' M5' M6']';
    M_ = Colors2Window(M, win_size, 1); %Adding random noise (last parameter)
    
    % Missingness at 90%, as before
    for i=1:size(M_,1)
        M_(i,randsample(numel(M_(i,:)), round(numel(M_(i,:))*miss_level) )) = NaN;
    end;

    %The sum of all numbers in each window, this will recover the original 3-color structure
    M_f = [nansum(M_(:,1:win_size),2) nansum(M_(:,win_size+1:win_size*2),2) nansum(M_(:,2*win_size+1:end),2) ];

    % Add all Mats
    S = [S1 S2 S3 S4 S5 S6 ]';
    [SCORE, ~, pcvars] = pca1(M_f);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

hAxis(4) = subplot(2,3,4);
    rng(1)
    disp('Case 4');
    
    %Adding 30 random SNPs (10%) to the informative color numbers. The structure is visible
    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple', 'Yellow'};
    N1=50; Me1=0.9; SD1=.01; 
    random_SNPs=30;

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 6); %Purple

    %Convert to a matrix
    M = [M1' M2' M3' M4' M5' M6']';

    %Add random SNPs (M size is 300)
    M = [M rand(size(M,1), random_SNPs)];

    % Add all Mats
    S = [S1 S2 S3 S4 S5 S6]';
    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

hAxis(5) = subplot(2,3,5);
    rng(1)
    %Adding 300 (100%) random SNPs to the informative color numbers. The structure is still visible

    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple', 'Yellow'};
    N1=50; N2=50; Me1=0.9; SD1=.01; 
    random_SNPs=300;

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 6); %Purple

    %Covnert to windowed data
    M = [M1' M2' M3' M4' M5' M6']';

    %Add random SNPs
    M = [M rand(size(M,1),random_SNPs)];

    % Add all Mats
    S = [S1 S2 S3 S4 S5 S6]';
    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

hAxis(6) = subplot(2,3,6);
    rng(1)
    %Adding 3000 (1000%) random SNPs to the informative color numbers. The
    %structure has disappeared

    Colors_names = {'Red', 'Green', 'Blue', 'Black', 'Cyan', 'Purple', 'Yellow'};
    N1=50; N2=50; Me1=0.9; SD1=.01; random_SNPs=3000;

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N1, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N1, 4); %Black
    [M5, S5] = Generate_nonrandom_colors([0 Me1 Me1], SD1, N1, 5); %Cyan
    [M6, S6] = Generate_nonrandom_colors([Me1 0 Me1], SD1, N1, 6); %Purple

    %Covnert to windowed data
    M = [M1' M2' M3' M4' M5' M6']';

    %Add random SNPs
    M = [M rand(size(M,1),random_SNPs)];

    % Add all Mats
    S = [S1 S2 S3 S4 S5 S6]';
    [SCORE, ~, pcvars] = pca1(M);
    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num);

maximize    

% print('-dtiff', 'd:\PCAColors_11.tif', '-r600'); close
% RemoveWhiteSpace([], 'file', 'd:\PCAColors_11.tif', 'output', 'd:\PCAColors_11_clear.tif');


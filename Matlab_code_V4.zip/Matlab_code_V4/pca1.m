% pca1.m

function [SCORE,coeff, V] = pca1(data, n)

    if nargin==1
        n=10;
    end;

    if size(data,2)==3
        %If colors
        [coeff,SCORE,V] = pca(data);
    else
        %If real populations
        disp(['Calculating PCA for #' num2str(n) ' components']);
        [coeff,SCORE,V] = pca(data, 'NumComponents', n);
    end;
end
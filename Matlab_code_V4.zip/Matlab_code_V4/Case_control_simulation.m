% Case_control_simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                               Case control simulation
%                               -----------------------------------------------------
%
% Description : This scripts gets Pop_indexes generated using: Main_PCA_Pops: #8
% Case-control matching (2). It then generates 10 causal markers by
% modifying the first 10 markers using weighted genotyped. There are 6
% examples, 5 with a dominant model and 1 with a heterozygote model. 
% Each example has different weights.
% 
% After generating the .ped file (and assuming that there is a mathcing
% .map file), the script runs case-control association analyses, before and
% after PCA adjustment for 10 components. I calculated the 2 components
% manually.
% 
% Input : population indexes Pop_indexes (the script doesn't take them
% automatically. Need to run Main_PCA_Pops, example #8.2 first.
% 
% Output: .ped file of the selected samples (copy the .map file from the
% Lazaridis dataset). 

% Calling functions: 
%     System
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: Eran Elhaik
% Written date: 21/4/2021
% Version : 4.00
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('Start program Case_control_simulation');
warning('off', 'MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

    %Reload the .ped file, save the samples of interest, modify the family data, generate the casual markers, andsave the new .ped file.

    %Load .ped file
    input_dir = 'D:\My Documents\University\Elhaik Lab\Data\PCA\Lazaridis_1kg_AJ_full\'; 
    dat_input_file = 'Lazaridis2016_1kg_AJ_merged_n_LD_miss.ped';
    d = load_plink_ped(input_dir, dat_input_file); %Much faster

    [final Annot Annot_full] = Plink2Genotypes(d(Pop_indexes));
    final_backup = final; %save as backup;
    save([input_dir 'associations.mat']);
    %%
    final=final_backup; %load from backup

    final_revised = [];
    %Save .ped to file (.map file is unchanged)
    %Convert the family data to plink format
    family_vec = {};
    disp('Gathering family information...');
    num_of_alleles = 10; %num of alleles for association

    %Get the 3 gentoypes into temp
    final_alleles = final(:,1:num_of_alleles);

    temp = [];
    for j=1:num_of_alleles
        if j==18
            temp(j,:) = [11 13 33];
        else
            temp(j,:) = unique(final_alleles(:,j));
        end;
    end;

% Select one for loop (the rest of the loop is the same for both loops

%     for i=1:numel(Pop_indexes)
%         curr_pop = Labels.Pop_code(Pop_indexes(i));
% 
%         %Unmask 1 example at a time
%         if i<160
%             %Cases 
%             family_vec{i} = [num2str(i) ' ' num2str(curr_pop) ' 0 0 0 2'];
%             round_num = randsample(3,num_of_alleles,'true',[0.2 0.5 0.3]); %Example1
% %             round_num = randsample(3,num_of_alleles,'true',[0.5 0.4 0.1]); %Example2
% %             round_num = randsample(3,num_of_alleles,'true',[0.4 0.20 0.4]); %Example3
% %             round_num = randsample(3,num_of_alleles,'true',[0.3 0.2 0.5]); %Example4
% %             round_num = randsample(3,num_of_alleles,'true',[0.4 0.4 0.2]); %Example5
% %             round_num = randsample(3,num_of_alleles,'true',[0.25 0.5 0.25]); %Example6, het mode
% 
%         else
%             %Controls 
%             family_vec{i} = [num2str(i) ' ' num2str(curr_pop) ' 0 0 0 1'];
%             round_num = randsample(3,num_of_alleles,'true',[0.4 0.5 0.1]); %Example1
% %             round_num = randsample(3,num_of_alleles,'true',[0.45 0.25 0.3]); %Example2
% %             round_num = randsample(3,num_of_alleles,'true',[0.5 0.4 0.1]); %Example3   
% %             round_num = randsample(3,num_of_alleles,'true',[0.5 0.4 0.1]); %Example4   
% %             round_num = randsample(3,num_of_alleles,'true',[0.3 0.3 0.4]); %Example5   
% %             round_num = randsample(3,num_of_alleles,'true',[0.35 0.3 0.35]); %Example6, het mode  
%         end;


%     %Random assignment of samples to cases and controls
%     for i=1:numel(Pop_indexes)
%         curr_pop = Labels.Pop_code(Pop_indexes(i));
% 
%         if round(rand)==0
%             family_vec{i} = [num2str(i) ' ' num2str(curr_pop) ' 0 0 0 2'];
% %             round_num = randsample(3,num_of_alleles,'true',[0.2 0.5 0.3]); %Example1
% %             round_num = randsample(3,num_of_alleles,'true',[0.5 0.4 0.1]); %Example2
% %             round_num = randsample(3,num_of_alleles,'true',[0.4 0.20 0.4]); %Example3
% %             round_num = randsample(3,num_of_alleles,'true',[0.3 0.2 0.5]); %Example4
%             round_num = randsample(3,num_of_alleles,'true',[0.4 0.4 0.2]); %Example5
% %             round_num = randsample(3,num_of_alleles,'true',[0.25 0.5 0.25]); %Example6, het mode
%         else
%             family_vec{i} = [num2str(i) ' ' num2str(curr_pop) ' 0 0 0 1'];
% %             round_num = randsample(3,num_of_alleles,'true',[0.4 0.5 0.1]); %Example1
% %             round_num = randsample(3,num_of_alleles,'true',[0.45 0.25 0.3]); %Example2
% %             round_num = randsample(3,num_of_alleles,'true',[0.5 0.4 0.1]); %Example3   
% %             round_num = randsample(3,num_of_alleles,'true',[0.5 0.4 0.1]); %Example4   
%             round_num = randsample(3,num_of_alleles,'true',[0.3 0.3 0.4]); %Example5   
% %             round_num = randsample(3,num_of_alleles,'true',[0.35 0.3 0.35]); %Example6, het mode  
%         end;

        %Update genotypes
        for t=1:num_of_alleles
            final_revised(i, t) = temp(t,round_num(t));
        end;
    end;
    final(:, 1:num_of_alleles) = final_revised(:, 1:num_of_alleles);

    %QC - test if there are 3 genotypes per SNP
    for i=1:num_of_alleles
        if numel(unique(final(:,i)))~=3
             disp(unique(final(:,i)));
             error_message('3 genotypes were not found.');
        end;
    end;

    disp('Generating plink .ped file...');
    plink = Geno2Plink(final, family_vec');
    save_ped_plink('D:\Bioinfo\plink2_win64_20211125\', 'PR.ped', plink);
    disp('.ped file was written.');

    %Running plink
    cd 'D:\Bioinfo\plink2_win64_20211125\';    
    delete 'PR_assoc.PHENO1.glm.logistic.hybrid.adjusted_no_PCA'
    delete 'PR_assoc.PHENO1.glm.logistic.hybrid.adjusted_PCA'
    delete 'PR_assoc.PHENO1.glm.logistic.hybrid.adjusted_PCA_2_PCs'
    delete 'PR_assoc.PHENO1.glm.logistic.hybrid.adjusted_PCA_10_PCs'
        %ped->bed
    system('plink --file PR --make-bed --out PR');
        %Calculating PCA
    system('plink2 --bfile PR --pca --out PR_assoc');
        %Running association without correction
    system('plink2 --bfile PR --logistic allow-no-covars --adjust --out PR_assoc');
    system('rename PR_assoc.PHENO1.glm.logistic.hybrid.adjusted PR_assoc.PHENO1.glm.logistic.hybrid.adjusted_no_PCA');
        %Running association with PCA correction (10 PCs)
    system('plink2 --bfile PR --logistic --covar PR_assoc.eigenvec --adjust --out PR_assoc');
    system('rename PR_assoc.PHENO1.glm.logistic.hybrid.adjusted PR_assoc.PHENO1.glm.logistic.hybrid.adjusted_PCA_10_PCs');

    system('cut -f1-4 PR_assoc.eigenvec > PR_assoc.eigenvec_2_PCs.txt');
    system('plink2 --bfile PR --logistic --covar PR_assoc.eigenvec_2_PCs.txt --adjust --out PR_assoc');
    system('rename PR_assoc.PHENO1.glm.logistic.hybrid.adjusted PR_assoc.PHENO1.glm.logistic.hybrid.adjusted_PCA_2_PCs');

disp('End program Case_control_simulation');    
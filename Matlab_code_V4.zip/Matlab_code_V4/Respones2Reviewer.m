% Respones2Reviewer
close all; clear all;
clc

[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

% Get the records for Africans, Asians, and Europeans
Afr_codes = [1113 1205 ]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Eur_codes = [1202 1200 ]; Eur_indexes = (Labels.Pop_code==Eur_codes);
Asi_codes = [1085 1204 1194 1029 1197]; Asi_indexes = (Labels.Pop_code==Asi_codes);

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes))]));
Min_Sample_sizes = min(Sample_sizes);
disp([Sample_sizes]);

Sample_indexes = [sum(Afr_indexes,2) sum(Eur_indexes,2) sum(Asi_indexes,2)];

figure
hAxis = [];
hAxis_num = 6;
pops_for_legend = [];
    
hAxis(1) = subplot(2,3,1);
    disp('Case 1');    
    rng(1);

    %Plotting the data (n=50)
    n=[285 2 400]; %285   259   477
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    hold on; title(num2str(n))

hAxis(2) = subplot(2,3,2);
    disp('Case 2');    
    rng(1);

    %Plotting the data (n=50)
    n=[285 2 5]; %285   259   477
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    hold on; title(num2str(n))

    
hAxis(3) = subplot(2,3,3);
    disp('Case 3');    
    rng(1);

    %Plotting the data (n=50)
    n=[3 2 400]; %285   259   477
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    hold on; title(num2str(n))

hAxis(4) = subplot(2,3,4);
    disp('Case 2');    
    rng(1);

    %Plotting the data (n=50)
    n=[2 250 2]; %285   259   477
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    hold on; title(num2str(n))

    
hAxis(5) = subplot(2,3,5);
    disp('Case 5');    
    rng(1);

    %Plotting the data (n=50)
    n=[10 10 400]; %285   259   477
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    hold on; title(num2str(n))

hAxis(6) = subplot(2,3,6);
    disp('Case 6');    
    rng(1);

    %Plotting the data (n=50)
    n=[100 10 50]; %285   259   477
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    hold on; title(num2str(n))

% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_R_1.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_R_1.tif', 'output', 'd:\Pops_R_1_clear.tif');
        
%% Colors
close all;

global Colors_names;
global draw_title; %1=draw figure titles; 0=hide figure title
draw_title = 0;

Colors_names = {'Red', 'Green', 'Blue', 'Black'};

% Plot original colors on 3D and the PCs
figure

    N1=10; Me1=0.9; SD1=.01; N2=200; N3=5;  

    % Primary colors
    [M1, S1] = Generate_nonrandom_colors([Me1 0 0], SD1, N1, 1); %Red
    [M2, S2] = Generate_nonrandom_colors([0 Me1 0], SD1, N1, 2); %Green
    [M3, S3] = Generate_nonrandom_colors([0 0 Me1], SD1, N3, 3); %Blue
    [M4, S4] = Generate_nonrandom_colors([0 0 0], SD1, N2, 4); %Black

    % Add all Mats
    M = [M1' M2' M3' M4']';
    S = [S1 S2 S3 S4]';

    [SCORE, ~, pcvars] = pca1(M);

    [~, D_pos, mean_pos] = Calculate_distances(M, S, SCORE, Colors_names, 2);
%     plot_PCA(M, S, [SCORE(:,1) SCORE(:,3)], pcvars, mean_pos, D_pos);
    plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos);






















% Main_ColorStat

% This function calculates the sequare euclidean distance between all the
% sampels in 3D and 2D spaces. It then calculates the ratio of these
% distances and their deviation from 1.

% M_indexes_in - compare this to everything else
% M_indexes_out - everything else

function res=Main_ColorStat(M, SCORE, M_indexes_in, S)

    disp('Start Main_ColorStat...');
    
    if nargin == 2
        %if no M_indexes_in then compare everything to everything
        M_indexes_in = 1:size(M,1);
        M_indexes_out = M_indexes_in;
    elseif nargin==3
        M_indexes_out = setdiff(1:size(M,1), M_indexes_in);
    elseif nargin==4
        %If S is provided, use each color one. Compare the last color to
        %all other ones.
        [a,b]=unique(S);
        M = M(b,:);
        SCORE=SCORE(b,:);
        M_indexes_in=1:S(end);
        M_indexes_out = M_indexes_in;
    end;
    
    % Input variables
    M_3D = M;
    S_2D = SCORE;

    % M_3D - the data for the 3D model
    % S_2D - the data for the 2D model
    S_2D = S_2D(:,1:2);

    % Calculate the distance between each point to all the other points in the
    % 3D model

    %% Check all points
    disp(['Calculating Euclidean distances for points in indexes: ' num2str(min(M_indexes_in)) '-' num2str(max(M_indexes_in))]);
    res = [];
    for i = min(M_indexes_in):max(M_indexes_in)
        
        M_3D_curr_dist_M_ratio = [];
        M_3D_curr_dist_M = pdist2(M_3D(i,:), M_3D(M_indexes_out,:), 'squaredeuclidean');
        
        %Calculate the ratio between each distance and everything else
        parfor j=1:length(M_3D_curr_dist_M)
            M_3D_curr_dist_M_ratio(:,j) = M_3D_curr_dist_M(j)./M_3D_curr_dist_M;
        end;

        S_2D_curr_dist_S_ratio = [];
        S_2D_curr_dist_S = pdist2(S_2D(i,:), S_2D(M_indexes_out,:), 'squaredeuclidean');
        parfor j=1:length(S_2D_curr_dist_S)
            S_2D_curr_dist_S_ratio(:,j) = S_2D_curr_dist_S(j)./S_2D_curr_dist_S;
        end;

        %Erase the row with the data of i 
        M_3D_curr_dist_M_ratio(i,:) = [];
        S_2D_curr_dist_S_ratio(i,:) = [];
        M_3D_curr_dist_M_ratio(:,i) = [];
        S_2D_curr_dist_S_ratio(:,i) = [];
        
        
        S_over_M_ratio = S_2D_curr_dist_S_ratio./M_3D_curr_dist_M_ratio;

        S_over_M_ratio(isinf(S_over_M_ratio))=0;
        S_over_M_ratio(isnan(S_over_M_ratio))=0;
        S_over_M_ratio(:,1)=[];
        S_over_M_ratio(1,:)=[];
        
        %The deviation from 1
        res(i) = sum(sum(abs(S_over_M_ratio-1)))/(size(S_over_M_ratio,1)^2 - size(S_over_M_ratio,1));
    end
    
    %Clear the first cells
    if min(M_indexes_in)>1
        res(1:min(M_indexes_in)-1) = [];
    end;

%     %Plot the results
%     edges = 1:0.1:2;
%     [a, b] = hist(res,edges);
%     a=a./sum(a);
%     bar(b,a);
    disp(['Distance statistics (mean, std): ' num2str([mean(res) std(res)])]); %Stats
    
end





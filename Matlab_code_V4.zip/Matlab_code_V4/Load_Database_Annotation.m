% Load_Database_Annotation

% input_dir_excel = 'D:\My Documents\University\Elhaik Lab\Data\PCA\Lazaridis_1kg\';
% input_file_excel = 'Lazaridis_1kg_Labels.xlsx';

function Labels = Load_Database_Annotation(input_dir_excel, input_file_excel)

    % Load the population labels
    disp(['Load_Database_Annotation: Load the population labels from ' [input_dir_excel input_file_excel]]);
    [data,txt,~] = xlsread([input_dir_excel input_file_excel],'Annot'); 

    Labels = [];
    PopColors = [];
    Labels.index = data(:,1);
    Labels.User_id = txt(2:end,3);
    Labels.Pop_name = txt(2:end,4);
    Labels.Nick = txt(2:end,5);
    Labels.Region = txt(2:end,6);
    Labels.Pop_code = data(:,7);
    Labels.Country = txt(2:end,8);
    Labels.Color = data(:,9:11);
    Labels.marker = txt(2:end,12);

%     % note, there may be population codes without populations, this treats this case
%     PopColors((unique_no_sort(Labels.Pop_code)-1000),:) = GeneratePrettyColor(numel(unique_no_sort(Labels.Pop_code)),2);
%     Labels.colors = PopColors(Labels.Pop_code-1000,:);

end
% plot_PCA
%Ver 2.00 - Adjusting to string input
% If it returns error, "Index exceeds the number of array elements (0)."
% check that Generate_nonrandom_colors got the colors in the order of 1..N
%     color_vec = [9 28 87; 40 62 102; 60 92 126; 78 111 135; 123 156 169; 174 194 198; 8 96 168; 45 114 178; 80 133 188; 104 149 197; 166 189 219; 217 229 240; 242 242 248; 40 103 160; 99 141 187]./255;

function plot_PCA(M, S, SCORE, pcvars, mean_pos, D_pos, hAxis, hAxis_num)

    global Colors_names;
    global draw_title;
    
    if nargin==6
        hAxis = [];
        hAxis_num = [];
    end;

    %QC on S
    if numel(M(:,1))~=numel(S)
        error_message('plot_PCA error: S and M sizes do not match. Check S. Return');
    end;

    % Plot the lines between points and the distances
    index=1;
    unique_colors = unique(S); %number of pops
    text_pos = [SCORE(:,1) SCORE(:,2)]; %initialize with the results to avoid overlap of numbers and the squares
    text_index = size(text_pos,1)+1;
    for i=1:length(unique_colors)
        for j=i+1:length(unique_colors)
%             line([mean_pos(i,1) mean_pos(j,1)], [mean_pos(i,2) mean_pos(j,2)],'color', [217 229 240]./256); %color_vec(text_index,:)); %plot lines between colors
%             text_pos(text_index,:) = [mean([mean_pos(i,1) mean_pos(j,1)]), mean([mean_pos(i,2) mean_pos(j,2)])]; %
% 
%             %Make sure numbers do not overlap with the text
%             while min(pdist2(text_pos(end,:), text_pos(1:end-1,:)))<0.008
%                 disp('Inside while loop... fixing coordinates')
%                 text_pos(text_index,:) = text_pos(end,:)+0.005;
%             end;

%             %The distance between the lines
%             text(text_pos(text_index,1), text_pos(text_index,2), num2str(round2(D_pos(index),0.01)), 'FontName','Ariel');
            text_index = text_index+1;
            index=index+1;
        end;
        hold on;
    end;

    % Plot individual points
    for i=1:size(SCORE,1)
        if isnumeric(S) && i<=sum(S==1)
            %Plot circle
            plot(SCORE(i,1), SCORE(i,2), 'o', 'MarkerEdgeColor', M(i,1:3)); %Plot the original color
        else
            %Plot square
            plot(SCORE(i,1), SCORE(i,2), 's', 'MarkerEdgeColor', M(i,1:3)); %Plot the original color
        end;
        hold on;
    end;

    % Calculate the explained variance by each PC
    PCA_vals = round(pcvars/sum(pcvars)*100);
    x = sort(PCA_vals, 'descend');
    y=round(100*(x/sum(x)));
    xlabel(['PC1 (' num2str(y(1)) '%)'], 'FontName','Ariel','FontSize',12);
    ylabel(['PC2 (' num2str(y(2)) '%)'], 'FontName','Ariel','FontSize',12);
    box off;
    grid off;
    set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);

    %Figure title
    if isnumeric(S) && draw_title==1
        color_count = count_(S);
        disp(['S is numeric. Draw a title for: #' num2str(numel(color_count(:,1))) ' colors']);
        title_string = [];
        for i=1:numel(color_count(:,1))
            title_string = [title_string char(Colors_names(color_count(i,1))) ' ' num2str(color_count(i,2)) '; ' ];
        end;
        title(title_string);
    end;
    whitebg('w'); %affects the first plot

    %Correct the axis
    get_axis = axis; %[min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    axis_ratio = [abs(get_axis(2))/8 abs(get_axis(4))/8];
    axis([get_axis(1)-axis_ratio(1) get_axis(2)+axis_ratio(1) get_axis(3)-axis_ratio(2) get_axis(4)+axis_ratio(2)]);

    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');
    
    %Fix the axes
    if hAxis
        pos = get(gca, 'Position');
        if hAxis_num==6
            %Fix positions
            i = numel(hAxis);
            pos2 = 0.53;
            pos3 = 0.25;
            pos4 = 0.36;

            if i<=3
                pos(2) = pos2; 
                pos(3) = pos3;
                pos(4) = pos4;
                set( hAxis(i), 'Position', pos ) ;
            end;
            if i>3
                pos(3) = pos3;
                pos(4) = pos4;
                set( hAxis(i), 'Position', pos ) ;
            end;
        end;
 
        if hAxis_num==4
            %Fix positions
            i = numel(hAxis);

            if i<=2
                pos(2) = 0.55; 
                pos(3) = 0.3;
                pos(4) = 0.37;
                set( hAxis(i), 'Position', pos ) ;
            end;

            if i>2
                pos(2) = 0.12; 
                pos(3) = 0.3;
                pos(4) = 0.37;
                set( hAxis(i), 'Position', pos ) ;
            end;

            if (i==1 || i==3)
                pos(1) = 0.16;
                set( hAxis(i), 'Position', pos ) ;
            else
                pos(1) = 0.5;
                set( hAxis(i), 'Position', pos ) ;
            end
        end;
    
    end;
end

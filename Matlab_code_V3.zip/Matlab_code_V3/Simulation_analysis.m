% Simulation_analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                               Simulation analysis - for publicaiton
%                               -----------------------------------------------------
%
% Description : This scripts simulated popualtions and simple demographic proccess of admixture and then applies PCA to the dataset after each generation. 
% the results are plotted and convex hul is used to delinate the boundaries
% of the corners.
% 
% Input : Simulation parameters below
% 
% Output: PCA plot
% Note: don't set mix_prop=1
% 
% Calling functions: 
%     generate_offspring_func - generates the mixture in the next generaiton. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: Eran Elhaik
% Written date: 31/3/2022
% Version : 1.00
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
disp('Start Program: Simulation_analysis analysis');

%% Supplementary Text 1

%-------------------------------------------------
% Simulation parameters 
ancestral_num = 6; %# of ancestral population
sample_size = 20; %Sample sizes of each ancestor
num_parents = ancestral_num*sample_size; %Total size ancestral population
bp_size = 50; %sequence size
mix_prop = 0.2; % mix_prop% admixture with other groups, 1-mix_prop% admixture with same-group
SD1=0.01; %SD for generating cohorts
%-------------------------------------------------

% Generating allele frequencies for the samples around those of the
% ancestors
M = []; %Allele frequencies of the offspring
C = []; %Colors of the offspring
mixed = []; %an indication of whether the cohort is mixed or not

% Generating random mean allele frequencies for the ancestral populations - Genration 1
allele_freq = rand(ancestral_num,bp_size);
color_vec = [1 0 0; 0 1 0; 0 0 1; 1 0 1; 0 1 1; 1 1 0]; %will be assigned to the first generation unmixed pops

for i=1:ancestral_num
    M = [M' double(allele_freq(i,:)+SD1.*randn(sample_size,bp_size))']';
    C = [C' repmat(color_vec(i,:), sample_size, 1)']';
    mixed = [mixed' (i.*ones(1,sample_size))]';
end;
M(M>1)=1;
M(M<0)=0;

% % Plot the populations
% [SCORE, ~, pcvars] = pca1(M, 2);
% for i=1:size(SCORE,1)
%     plot(SCORE(i,1), SCORE(i,2), 'o', 'MarkerEdgeColor', C(i,:)); hold on; %Plot the original color
% end;

% Generation size
num_offspring = num_parents;

% Calculate results per generation
for g=1:20

    %Generate offsprings
    [M_plot, C_plot, mixed_plot, M_F1, C_F1, mixed_F1] = generate_offspring_func(num_offspring, M, C, mixed, mix_prop);
    
    %Calculate PCA
    [SCORE, ~, pcvars] = pca1(M_plot, 3);

    % indexes of generations in the data
    Generations_size = [1 num_parents num_parents+num_offspring];

    %Plot PCA
    for i=1:numel(mixed_plot)
        if mixed_plot(i)==0
            plot(SCORE(i,1), SCORE(i,2), 'x', 'MarkerEdgeColor', C_plot(i,:)); hold on; %Plot offsprings
        else
            plot(SCORE(i,1), SCORE(i,2), 'o', 'MarkerEdgeColor', C_plot(i,:)); hold on; %Plot parents
        end;
    end;

    % Plot convhull around the parents
    k = convhull(SCORE(:,1), SCORE(:,2) ); %computes the 2-D or 3-D convex hull of the points in matrix .
    plot(SCORE(k,1), SCORE(k,2), 'Color', [50 200 200]./256, 'LineWidth',1); hold on;
    plot(SCORE(k,1), SCORE(k,2), 'o', 'MarkerFaceColor', 'k', 'MarkerSize', 3);
    
    x = sort(pcvars, 'descend');
    y=round(100*(x/sum(x)));
    title(['Generation #' num2str(g)]);
    xlabel(['PC1 (' num2str(y(1)) '%)'], 'FontName','Ariel','FontSize',12);
    ylabel(['PC2 (' num2str(y(2)) '%)'], 'FontName','Ariel','FontSize',12);
    box off;
    grid off;
    set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
    set(gca, 'Box', 'off');    

    %Update parents
    num_parents = num_offspring;
    M = M_F1; %Keep only offspring
    C = C_F1; %Keep only offspring
    mixed = mixed_F1;
    maximize
    
    filename = ['sim_' num2str(g) '.tif'];
    filename2 = ['sim_' num2str(g) '_clear.tif'];
    
%     print('-dtiff', filename, '-r600'); close
%     RemoveWhiteSpace([], 'file', filename, 'output', filename2);

    pause
    close all
end;

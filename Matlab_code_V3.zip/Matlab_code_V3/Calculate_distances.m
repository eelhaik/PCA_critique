% Calculate_distances
% Ver 2.00 - adjusting to handle S as string

% Calculate the distances between the original data points (D_color) and the PCA score (D_pos)
function [D_color D_pos mean_pos mean_color] = Calculate_distances(M, S, SCORE, Colors_names, sig_dimentions)
    
    D_color = [];     D_pos = [];     mean_pos = [];
    
    % Calculate the mean position for each color group (not sample) for the lines
    mean_color = []; std_color = []; mean_pos = []; std_pos = [];
    unique_colors = unique(S); %number of pops
    for i=1:numel(unique_colors)
        curr_color = unique_colors(i); %for pop i
        
        %If S is numeric (first dataset)
        if ~iscell(S)
            %Calculate distances between the original data points (distance between colors)
            mean_color(i,:) = mean(M(S==curr_color,:),1); %gives me the average color of this group
%             std_color(i,:) = std(M(S==curr_color,:),1); %the std of the color shades

            %Calculate distances between PCA score for 1:2/ALL PCs
            mean_pos(i,:) = mean(SCORE(S==curr_color,1:sig_dimentions),1); %average over the first 2 components (one average per component)
%             std_pos(i,:) = std(SCORE(S==curr_color,1:sig_dimentions),1); %average over the first 2 components (one average per component)
    %         disp(['STD original: ' num2str(round2(mean(std_color(i,:)),0.01)) ', New std:' num2str(round2(mean(std_pos(i,:)),0.01))]);    
        else
            mean_color(i,:) = [0 0 0];
%             std_color(i,:) = [0 0 0];
            mean_pos(i,:) = mean(SCORE(ismember(S, curr_color),1:sig_dimentions),1); %average over the first 2 components (one average per component)
            std_pos(i,:) = std(SCORE(ismember(S, curr_color),1:sig_dimentions),1); %average over the first 2 components (one average per component)
        end;
    end;

    %Calculating distances
    D_color = pdist(mean_color); %This is the distance between the color values (not physical distance)
    D_pos = pdist(mean_pos); %This is the distance between the color positions


%     % Plot results to screen
%     index = 1;
% %     disp(['    Calculate_distances: Plotting distances between ' num2str(size(SCORE,1)) ' color posoitions and between colors and the difference...']);    index=1;
%     for i=1:length(unique_colors)
%         for j=i+1:length(unique_colors)
%             fprintf(1, '%-10s & %-10s\t %.2f\t %.2f\t %.2f\t\n', char(Colors_names(i)), char(Colors_names(j)), D_color(index), D_pos(index), abs(D_color(index)-D_pos(index)) );
%             index=index+1;
%         end;
%     end;

end
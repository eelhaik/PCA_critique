% CompareDistPops

function CompareDistPops(Labels, Data_, SCORE, Pop_indexes, filename1, filename2)

    disp('In CompareDistPops...');

    %Calculate distances between random individuals
    all_pairs_inds = nchoosek(1:size(Data_(Pop_indexes,:),1), 2); %all pairs of 566 inds
    random_pairs = randperm(size(all_pairs_inds,1),2000); %select random indexes

    disp('CompareDistPops: Calculating distances for inds...')
    inds_Gene_dist = diag(pdist2(Data_(Pop_indexes(all_pairs_inds(random_pairs,1)),:), Data_(Pop_indexes(all_pairs_inds(random_pairs,2)),:)));
    inds_PCA_dist = diag(pdist2(SCORE(all_pairs_inds(random_pairs,1),1:2),SCORE(all_pairs_inds(random_pairs,2),1:2))); %main diagonal has the distances that i want

    % Plot normalized distances for random individuals
    figure;
    plot(normalize_func(inds_Gene_dist), normalize_func(inds_PCA_dist),'.', 'Color', [0.8, 0.8, 0.8]); hold on;

    unique_pops = unique(Labels.Pop_code(Pop_indexes));

    %calculate mean genetic and color profile for each pop
    pops_Gene = [];
    pops_PCA = [];

    %Calculate average profile per population
    disp('CompareDistPops: Calculating distances for pops...')
    for i=1:numel(unique_pops)
        curr_pop = unique_pops(i);
        disp([num2str(i) '. For population code ' num2str(curr_pop) ' Found #' num2str(sum(Labels.Pop_code(Pop_indexes)==curr_pop)) ' inds']);
        pops_Gene(i,:) = mean(Data_(Pop_indexes(Labels.Pop_code(Pop_indexes)==curr_pop),:));
        pops_PCA(i,:) = mean(SCORE(Labels.Pop_code(Pop_indexes)==curr_pop,1:2));
    end;

    all_pairs_pops = nchoosek(1:numel(unique_pops),2);
    pops_Gene_dist = normalize_func(pdist(pops_Gene));
    pops_PCA_dist = normalize_func(pdist(pops_PCA));

    %Calculate distances for every pair of populations
    for i=1:size(all_pairs_pops,1)
        first_pop = unique_pops(all_pairs_pops(i,1));
        second_pop = unique_pops(all_pairs_pops(i,2));

        temp = find(Labels.Pop_code==first_pop);
        first_pop_color = Labels.Color(temp(1),:);
        first_pop_marker = Labels.marker(temp(1),:);

        temp = find(Labels.Pop_code==second_pop);
        second_pop_color = Labels.Color(temp(1),:);
        second_pop_marker = Labels.marker(temp(1),:);

        plot(pops_Gene_dist(i), pops_PCA_dist(i), 'Marker', first_pop_marker, 'Color', first_pop_color); hold on;
        plot(pops_Gene_dist(i)+0.012, pops_PCA_dist(i), 'Marker', second_pop_marker, 'Color', second_pop_color); hold on;
    end;
    plot([0,1],[0,1],'k--')
    xlim([0 1.02])
    ylim([0 1.02])
    
    xlabel('Genetic distance', 'FontName','Ariel','FontSize',12)
    ylabel('PCA (PC1+PC2) distances', 'FontName','Ariel','FontSize',12)
    set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);

    axis square
    box off;
    maximize   
   
    print('-dtiff', filename1, '-r600'); close
    RemoveWhiteSpace([], 'file', filename1, 'output', filename2);
end
%% CandidateDNA
close all; clear all; clc;
global Labels;

disp('An attempt to replicate ht observed patterns of Bustamante when analyzing the genome of a Candidate');
% The report is available here: https://www.documentcloud.org/documents/5002149-Bustamante-Report-2018

[input_file_excel input_dir_excel Data_ Labels]= Load_Database('Lazaridis_1kg_AJ_full');

%% Replicaiton of Figure 1 - Get the population records 
Pop1_codes = [1113]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); % Nigerian
Pop2_codes = [1101:1105]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); % Native Americans, Mexicans
Pop3_codes = [1200]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); % UK
Pop4_codes = [1210]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); % Puerto Ricans
Pop5_codes = [1198]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); % Colombia

% 1085 (Japan); 1073 (GIH); 1115 (Pakistani)
Pop6_codes = [1115]; Pop6_indexes = (Labels.Pop_code==Pop6_codes); % Candidate-like samples 
% Pop7_codes = [1085]; Pop7_indexes = (Labels.Pop_code==Pop7_codes); %

% Find the smallest population
Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes)) sum(sum(Pop5_indexes)) sum(sum(Pop6_indexes)) ]));
Min_Sample_sizes = min(Sample_sizes);
Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0 sum(Pop6_indexes,2)>0 ];
disp([sum(Sample_indexes)]); 

% Plot original colors on the PCs
pops_for_legend = [];
figure
hAxis = [];

hAxis(1) = subplot(2,2,1);
    disp('Case 1');    
    rng(1);

    n=[37 37 37 37 37 1]; 
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

hAxis(2) = subplot(2,2,2);
    disp('Case 2'); % Changing the numbers

    Pop1_codes = [1113]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); % Nigerian
    Pop2_codes = [1101:1105]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); % Native Americans, Maya
    Pop3_codes = [1200]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); % UK
    Pop4_codes = [1210]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); % Puerto Ricans
    Pop5_codes = [1198]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); % Colombia
    
    %Iranian (1074)
    Pop6_codes = [1074]; Pop6_indexes = (Labels.Pop_code==Pop6_codes); % Candidate-like samples 
    % Pop7_codes = [1085]; Pop7_indexes = (Labels.Pop_code==Pop7_codes); %
    
    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes)) sum(sum(Pop5_indexes)) sum(sum(Pop6_indexes)) ]));
    Min_Sample_sizes = min(Sample_sizes);
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0 sum(Pop6_indexes,2)>0 ];
    disp([sum(Sample_indexes)]); 

    n=[100 20 50 89 89 1]; 
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

hAxis(3) = subplot(2,2,3);
    disp('Case 3');  % Clustering within NA

    Pop1_codes = [1198 1042]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); % COlombia
    Pop2_codes = [1101:1105]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); % Native Americans, Maya
    Pop3_codes = [1208]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); % Peru
    Pop4_codes = [1210]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); % Puerto Ricans
    Pop5_codes = [1207]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); % MXL
    
    %Iranian (1074), Russian (1074, 1132), Japan (1085)
    Pop6_codes = [1132]; Pop6_indexes = (Labels.Pop_code==Pop6_codes); % Candidate-like samples 
    
    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes)) sum(sum(Pop5_indexes)) sum(sum(Pop6_indexes)) ]));
    Min_Sample_sizes = min(Sample_sizes);
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0 sum(Pop6_indexes,2)>0 ];
    disp([sum(Sample_indexes)]); 

    n=[93    53    75   102    64    1]; 
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

hAxis(4) = subplot(2,2,4);
disp('Case 4'); % Europeans to clsuter with NA

    Pop1_codes = [1113]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); % Nigerian
    Pop2_codes = [1101:1105]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); % Native Americans, Maya
    Pop3_codes = [1200]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); % UK
    Pop4_codes = [1210]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); % Puerto Ricans
    Pop5_codes = [1198]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); % Colombia
    
    %Russian (1142), 1138 Moscow
    Pop6_codes = [1138]; Pop6_indexes = (Labels.Pop_code==Pop6_codes); % Candidate-like samples 
    
    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes)) sum(sum(Pop5_indexes)) sum(sum(Pop6_indexes)) ]));
    
    Min_Sample_sizes = min(Sample_sizes);
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0 sum(Pop6_indexes,2)>0 ];
    disp([sum(Sample_indexes)]); 

    n=[100 53 20 30 89 1]; 
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

maximize
% plot_legend(pops_for_legend, Labels); %print the legend

% print('-dtiff', 'd:\Candidate.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Candidate.tif', 'output', 'd:\Candidate_clear.tif');
    


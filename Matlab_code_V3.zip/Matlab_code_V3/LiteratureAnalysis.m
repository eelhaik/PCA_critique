% LiteratureAnalysis

% Load Excel table
input_dir_excel = '..\Datasets\'
input_file_excel = 'Literature_Dataset.xlsx';

% Load the population labels
disp(['LiteratureAnalysis: Load the trends from ' [input_dir_excel input_file_excel]]);
[N_Data,txt,~] = xlsread([input_dir_excel input_file_excel],'Nature'); 
[P_Data,txt,~] = xlsread([input_dir_excel input_file_excel],'PNAS'); 

years = 1970:2:2020;
N_years = zeros(size(years));
P_years = zeros(size(years));
index = 1;

for i=1:numel(years)-1
    curr_year = years(i);
    next_year = years(i)+1;
    disp([curr_year next_year]);
    
    %Nature
    citations = [N_Data(N_Data(:,1)==curr_year,5)' N_Data(N_Data(:,1)==next_year,5)']';
    N_years(index) = sum((citations(~isnan(citations)))>0)/numel(citations);
    
    %PNAS
    citations = [P_Data(P_Data(:,1)==curr_year,5)' P_Data(P_Data(:,1)==next_year,5)']';
    P_years(index) = sum((citations(~isnan(citations)))>0)/numel(citations);
    index = index+1;
end;

N_years(end-1:end)=1;
P_years(end-1:end)=1;

n=2;
nn=8;
plot(years, N_years, 'ro', 'MarkerFaceColor', 'r', 'Linewidth', n, 'MarkerSize', nn); hold on;
plot(years, N_years, 'r--', 'Linewidth', n, 'MarkerSize', nn); hold on;
plot(years, P_years, 'b+', 'Linewidth', n, 'MarkerSize', nn); 
plot(years, P_years, 'b--', 'Linewidth', n, 'MarkerSize', nn); 
axis([1970, 2020, 0, 1])
box off;
grid off;
axis off;
whitebg('w');
maximize

save_file('d:\Trends', '-r600'); close;




% plot_legend

% This scirpt prints the legend for the popualtions of interest so that i
% can copy it to PPT of the main plot.
% pops_for_legend has the collection of all populations plotted in preivous
% subplots. Labels has the anntotation.

function plot_legend(pops_for_legend, Labels)

    %% prepare the legend
    Labels_nick = Labels.Nick(pops_for_legend,:);
    Labels_color = Labels.Color(pops_for_legend,:);
    Labels_marker = Labels.marker(pops_for_legend,:);
    Labels_Pop_names = Labels.Pop_name(pops_for_legend,:);

    [~, b , ~]=unique(Labels_nick);
    [Labels_nick_unsorted, Labels_nick_unsorted_indexes, Pop_names]= sort_nicks(Labels_nick(b), b, Labels);

    %If too many items, break legend into 2 figures
    if numel(Labels_nick_unsorted_indexes) > 50

        Labels_nick_unsorted_indexes_1 = Labels_nick_unsorted_indexes(1:50);
        Labels_nick_unsorted_indexes_2 = Labels_nick_unsorted_indexes(51:end);
        
        figure
        gscatter(1:size(Labels_nick_unsorted_indexes_1,1),1:size(Labels_nick_unsorted_indexes_1,1),Labels_nick(Labels_nick_unsorted_indexes_1), Labels_color(Labels_nick_unsorted_indexes_1,:), char(Labels_marker(Labels_nick_unsorted_indexes_1)));
        text(1:size(Labels_nick_unsorted_indexes_1,1),1:size(Labels_nick_unsorted_indexes_1,1), Labels_nick(Labels_nick_unsorted_indexes_1));
        legend(Labels_Pop_names(Labels_nick_unsorted_indexes_1));
        maximize
        
        figure
        gscatter(1:size(Labels_nick_unsorted_indexes_2,1),1:size(Labels_nick_unsorted_indexes_2,1),Labels_nick(Labels_nick_unsorted_indexes_2), Labels_color(Labels_nick_unsorted_indexes_2,:), char(Labels_marker(Labels_nick_unsorted_indexes_2)));
        text(1:size(Labels_nick_unsorted_indexes_2,1),1:size(Labels_nick_unsorted_indexes_2,1), Labels_nick(Labels_nick_unsorted_indexes_2));
        legend(Labels_Pop_names(Labels_nick_unsorted_indexes_2));
        maximize
    else
        figure
        gscatter(1:size(Labels_nick_unsorted_indexes,1),1:size(Labels_nick_unsorted_indexes,1),Labels_nick(Labels_nick_unsorted_indexes), Labels_color(Labels_nick_unsorted_indexes,:), char(Labels_marker(Labels_nick_unsorted_indexes)))
        text(1:size(Labels_nick_unsorted_indexes,1),1:size(Labels_nick_unsorted_indexes,1), Labels_nick(Labels_nick_unsorted_indexes));

        legend(Pop_names);
        maximize
    end;
    
end

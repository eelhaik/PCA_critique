% CompareDist

function CompareDist(mean_color, mean_pos)

    %  PCA distances are never closer than the true distances
        disp('Plotting the data');
        
        %get all color pairs
    %     x1_exp = []; %control, to confirm that x1_exp and x1 are the same so
    %     that color_pair perfectly match the distance calcualted by x1
        color_pair = [];
        counter = 1;
        for i=1:size(mean_color,1)
            for j=i+1:size(mean_color,1)
                color_pair(counter,:) = [mean_color(i,:) mean_color(j,:) ];
    %             x1_exp(counter) = pdist2(mean_color(i,:),mean_color(j,:));
                counter = counter+1;
            end;
        end;
    
        x1 = pdist(mean_color)'; %3D distances
        y = pdist(mean_pos)'; %PCA
        X = [ones(size(x1)) x1];
        [b,bint] = regress(y,X);
        max_x1 = max(x1) + 0.05;
        
        xval = [min(x1) max_x1];
        yhat = b(1)+b(2)*xval;
        ylow = bint(1,1)+bint(2,1)*xval;
        yupp = bint(1,2)+bint(2,2)*xval;
    
        for i=1:numel(x1)
            plot(x1(i),y(i),'s', 'MarkerFaceColor', color_pair(i,1:3),'MarkerEdgeColor', color_pair(i,1:3),'MarkerSize', 5); hold on;
            plot(x1(i)+0.015,y(i),'s', 'MarkerFaceColor', color_pair(i,4:6),'MarkerEdgeColor', color_pair(i,4:6),'MarkerSize', 5); hold on;
        end;
    
    %     plot(xval,ylow,'r-.');
    %     plot(xval,yupp,'r-.');
    %     plot(xval,yhat,'b','linewidth',1);
        plot([0,max_x1],[0,max_x1],'k--')
        xlim([0 max_x1])
        ylim([0 max_x1])
        set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);
    
        xlabel('True distance', 'FontName','Ariel','FontSize',12)
        ylabel('PCA (PC1+PC2) distances', 'FontName','Ariel','FontSize',12)

        axis square
        grid minor
        box off;
        maximize   
    
%     print('-dtiff', 'd:\PCA_dist.tif', '-r600'); close
%     RemoveWhiteSpace([], 'file', 'd:\PCA_dist.tif', 'output', 'd:\PCA_distclear.tif');
end
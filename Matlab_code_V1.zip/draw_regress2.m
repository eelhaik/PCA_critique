%This functions accepts 2 vectors and it calculates regression between
%them.

function [x_res y_res r_res p_value] = draw_regress2(M, X, rescale)

    if (nargin==2)
        rescale=0;
    end;
    X = double(X);
    M = double(M);

    %Remove NaNs
    NaNs = find(isnan(M) + isnan(X));
    X(NaNs,:) = [];
    M(NaNs,:) = [];
    
    %Calculate regression parameters
    x = [];
    if rescale
        x = [ones(length(M),1) M(:)./max(M)]; %rescaling x
        y = X(:)/max(X); %rescaling y
    else
        x = [ones(length(M),1) M(:)]; 
        y = X(:); 
    end;
    
    plot(x(:,2), y, 'bo'); hold on; 
    hold on;

    [b,bint,r,rint,stats] = regress(y,x);
    r_corr = corrcoef(y,x(:,2));
    p = polyfit(x(:,2),y,1);
    display(['The Linear fitting: ' num2str(p(1))  ' x + ' num2str(p(2)) ]);

    disp('The 95% confidence intervals');
    disp(bint)
    
    % return    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    %Add regression graph to the plot
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if rescale
        z = [1,0;1,1]*b;
        plot ([0,1],z,'--r');
        plot ([0,1],[0 1],'-.g'); %blue line with slope =1
    else
        z = [1,min(x(:,2));1, max(x(:,2))]*b;
        plot ([min(x(:,2)),max(x(:,2))],z,'--r');
%         plot ([min([x(:,2)' min(y)']), max([x(:,2)' min(y)'])],[min([x(:,2)' min(y)']), max([x(:,2)' min(y)'])],'-.g');%blue line with slope =1
    end;

%     column_name=[tested_element {'-200 kb:-100 kb', '-100 kb:0', '0:100 kb', '100 kb:200 kb'}];
    vs = sprintf('n=%d, r^2=%.2f, r=%.2f, p-val=%.5f, e=%.3f', numel(M(:)), stats(1), r_corr(1,2), stats(3), stats(4));%the 3 values in each box
    p_value = stats(3);
    disp(vs)

%     title(['n=' num2str(numel(M(:))) ', (r^2=' num2str(stats(1)) '); p-value (' num2str(stats(3)) '), and error (' num2str(stats(4)) ')     ']);
    title(vs);  
%     xlabel(['GCf ' column_name(column_num)]); 
%     ylabel(tested_element);

    box off;
    grid off
%     axis off;
    whitebg('w')
    axis([0,1,0,1]);  
    axis tight;
    x_res = x(:,2);
    y_res = y;
    r_res = r_corr(1,2);
end

    

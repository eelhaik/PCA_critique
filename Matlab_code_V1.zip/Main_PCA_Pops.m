% Main_PCA_Pops
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                               Calculate PCA for real populations - for publicaiton
%                               -----------------------------------------------------
%
% Description : This scripts applies PCA to real populations. The test cases are numbered according to
% their appearance in the paper.
% 
% 1.	The near-perfect case of dimensionality reduction
% 2.	The case of uneven-sized populations 
% 3.	The case of one admixed population
% 4.	The case of two and three admixed population 
% 5.	The case of multiple admixed population 
% 6.	The case of multiple admixed population without “unmixed” populations
% 7.	The case of pairwise comparisons 
% 8.	The case of case-control matching and GWAS
% 9.	The case of unions and projections
% 10.	The case of ancient DNA
% 11.	The case of marker choice
% 
% Input : The script calls Load_Database_final, which loads one of 3 datasest.
% Each dataset has genotype data and metadata.
% 
% Output: plots and statistics
% Calling functions: 
%     Generate_nonrandom_colors - generate proportions that correspond to color
%     Calculate_distances - measure distances between populations
%     plot_PCA - plot the PCA plot
%     Load_Database_final - Choose which dataset to load
%     draw_regress2 - A function to draw regression
%     pca1 - Calling Matlab's pca.m function
%     pca_projection_2 - projection function
%         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: Eran Elhaik
% Written date: 21/4/2021
% Version : 4.00
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Start program CalculatePCA_pops');
warning('off', 'MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

%% Comparison of Matlab's pca.m and Eigenstrat performances (1/2) - Figure S1 (Matlab)
% Plot Matlab's pca.m results
clear all; clc;
disp('Comparison of Matlab''s pca.m and Eigenstrat performances - Matlab''s PCA');

% Plot the PCA for the entire database of Lazaridis et al. 2016 using MATLAB's PCA
[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_full');
[SCORE, ~, pcvars] = pca1(Data_);

%Notice, axes were rescalled to fit those of Eigenstrat.
figure
gscatter(SCORE(:,1)./2500, SCORE(:,2)./2500, Labels.Nick);
legend off;

% Calculate the explained variance by each PC
PCA_vals = round(pcvars/sum(pcvars)*100);
x = sort(PCA_vals, 'descend');
y = round(100*(x/sum(x)));
xlabel(['PC 1 (' num2str(y(1)) '%)'], 'FontName','Ariel','FontSize',12);
ylabel(['PC 2 (' num2str(y(2)) '%)'], 'FontName','Ariel','FontSize',12);

axis square; axis equal;
box off;
grid off;
whitebg('w'); %affects the first plot
maximize

% print('-dtiff', 'd:\S1_Matlab_results.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\S1_Matlab_results.tif', 'output', 'd:\S1_Matlab_results_clear.tif');

%% Comparison of Matlab's pca.m and Eigenstrat performances (2/2) - Figure S1 (Eigenstrat)
disp('Comparison of Matlab''s pca.m and Eigenstrat performances - EIGENSTRAT''s PCA');
% Plot EIGENSTRAT's results

% EIGENSTRAT's PCA
[Eigenstrat,txt,raw] = xlsread('D:\My Documents\University\Elhaik Lab\Data\PCA\Lazaridis_full\Eigenstrat.xlsx', '7.2.1 no norm');
[Eigenvalues,txt,raw] = xlsread('D:\My Documents\University\Elhaik Lab\Data\PCA\Lazaridis_full\Eigenstrat.xlsx', '7.2.1 Eigenvalues no norm');

figure
gscatter(-Eigenstrat(:,1), -Eigenstrat(:,2), Labels.Nick);
legend off;

PCA_vals = round(Eigenvalues/sum(Eigenvalues)*100);
x = sort(PCA_vals, 'descend');
y = round(100*(x/sum(x)));
xlabel(['PC 1 (' num2str(y(1)) '%)'], 'FontName','Ariel','FontSize',12);
ylabel(['PC 2 (' num2str(y(2)) '%)'], 'FontName','Ariel','FontSize',12);

axis square; axis equal;
box off;
grid off;
whitebg('w'); %affects the first plot

maximize

% print('-dtiff', 'd:\S1_Eigenstrat_results.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\S1_Eigenstrat_results.tif', 'output', 'd:\S1_Eigenstrat_results_clear.tif');

%% Calculate correlations - Figure S2
% plot the correlations between Matlab'c pca.m and SmartPCA
% for the first 9 PCs

subplot(3,3,1)
[~, ~, ~, p_val]=draw_regress2(SCORE(:,1), Eigenstrat(:,1));
title('PC 1')
subplot(3,3,2)
[~, ~, ~, p_val]=draw_regress2(SCORE(:,2), Eigenstrat(:,2));
title('PC 2')
subplot(3,3,3)
[~, ~, ~, p_val]=draw_regress2(SCORE(:,3), Eigenstrat(:,3));
title('PC 3')

subplot(3,3,4)
[~, ~, ~, p_val]=draw_regress2(SCORE(:,4), Eigenstrat(:,4));
title('PC 4')
subplot(3,3,5)
[~, ~, ~, p_val]=draw_regress2(SCORE(:,5), Eigenstrat(:,5));
title('PC 5')
subplot(3,3,6)
[~, ~, ~, p_val]=draw_regress2(SCORE(:,6), Eigenstrat(:,6));
title('PC 6')

subplot(3,3,7)
[~, ~, ~, p_val]=draw_regress2(SCORE(:,7), Eigenstrat(:,7));
title('PC 7')
subplot(3,3,8)
[~, ~, ~, p_val]=draw_regress2(SCORE(:,8), Eigenstrat(:,8));
title('PC 8')
subplot(3,3,9)
[~, ~, ~, p_val]=draw_regress2(SCORE(:,9), Eigenstrat(:,9));
title('PC 9')

box off;
grid off;
whitebg('w'); %affects the first plot

maximize

% Calculate stats
[RHO,PVAL] = corr(SCORE(:,1:10), Eigenstrat(:,1:10));
disp([diag(RHO) diag(PVAL)]);

% print('-dtiff', 'd:\Eigenstrat_Matlab_corr.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Eigenstrat_Matlab_corr.tif', 'output', 'd:\Eigenstrat_Matlab_corr_clear.tif');

%% #1 Normal case - populations of even sizes (1)
% Keeping the population sizes even yields similar results, even when different populations are used. 
% In other words, the number of samples does not affect the results.
close all; clear all;
clc

disp('#1 Normal case - plotting populations of even sizes');
[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

% Get the records for Africans, Asians, and Europeans
Afr_codes = [1113 1205 ]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Asi_codes = [1085 1204 1194 1029 1197]; Asi_indexes = (Labels.Pop_code==Asi_codes);
Eur_codes = [1202 1200 ]; Eur_indexes = (Labels.Pop_code==Eur_codes);

%Using Ethiopeans and Somali as an admixed population
Mixed = [1198 1203]; Mixed_indexes = Labels.Pop_code==Mixed; 

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes))]));
Min_Sample_sizes = min(Sample_sizes);
disp([Sample_sizes]);

Sample_indexes = [sum(Afr_indexes,2) sum(Eur_indexes,2) sum(Asi_indexes,2) sum(Mixed_indexes,2)];

figure
hAxis = [];
hAxis_num = 4;
pops_for_legend = [];
    
hAxis(1) = subplot(2,2,1);
    disp('Case 1');
    rng(1);

    %Plotting the data (n=50)
    n=50;
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, hAxis_num);

hAxis(2) = subplot(2,2,2);
    disp('Case 2');
    rng(1);

    %Plotting the data (n=188)
    n=188;
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, hAxis_num);
    
% Get the records for Africans, Asians, and Europeans (different populations)
Afr_codes = [1206 1201]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Asi_codes = [1085 1204 1194 1029 1197]; Asi_indexes = (Labels.Pop_code==Asi_codes);
Eur_codes = [1059 1195]; Eur_indexes = (Labels.Pop_code==Eur_codes);

%Using Ethiopeans and Somali as an admixed population
Mixed = [1198 1203]; Mixed_indexes = Labels.Pop_code==Mixed; 

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes))]));
Min_Sample_sizes = min(Sample_sizes);
disp([Sample_sizes]);

Sample_indexes = [sum(Afr_indexes,2) sum(Eur_indexes,2) sum(Asi_indexes,2) sum(Mixed_indexes,2)];

hAxis(3) = subplot(2,2,3);
    disp('Case 3');
    rng(1);
    
    %Now using Papuans and Bougainville as admixed populations
    Mixed = [1073 1193]; Mixed_indexes = Labels.Pop_code==Mixed; 

    % Find the smallest population
    Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);
    disp([Sample_sizes]);
    Sample_indexes = [sum(Afr_indexes,2) sum(Eur_indexes,2) sum(Asi_indexes,2) sum(Mixed_indexes,2)];

    %Plotting the data (n=50)
    n=50;
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, hAxis_num);
    
hAxis(4) = subplot(2,2,4);
    disp('Case 4');
    rng(1);

    %Plotting the data (n=214)
    n=192;
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA
    SCORE(:,2) = SCORE(:,2).*-1;
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, hAxis_num);

maximize

% plot_legend(pops_for_legend, Labels); %print the legend

% print('-dtiff', 'd:\Pops_1.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_1.tif', 'output', 'd:\Pops_1_clear.tif');

%% #2 Different-sized populations
close all; clear all; clc

disp('#2 Populations of different sizes');
[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

% Get the records for Africans, Asians, Europeans, and AJs
Afr_codes = [1026 2014 1113 1087]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Eur_codes = [1202 1059 1062:1063, 1182:1184, 1155:1164]; Eur_indexes = (Labels.Pop_code==Eur_codes);
Asi_codes = [1027:1038 1040:1041, 1085]; Asi_indexes = (Labels.Pop_code==Asi_codes);
Mixed = [1207]; Mixed_indexes = Labels.Pop_code==Mixed; 

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes))]));
Min_Sample_sizes = min(Sample_sizes);
disp([Sample_sizes]); %    98   158   188    20

Sample_indexes = [sum(Afr_indexes,2) sum(Eur_indexes,2) sum(Asi_indexes,2) sum(Mixed_indexes,2)];

% Plot original colors on the PCs
pops_for_legend = [];
figure
hAxis = [];

hAxis(1) = subplot(2,3,1);
    disp('Case 1');    
    rng(1);
    
    n=[198 20 483 64]; %198    343 483    61
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    maximize

hAxis(2) = subplot(2,3,2);
    disp('Case 2'); 
    rng(1);

    n=[20 343 20 64]; 
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

Mixed = [1124 1020]; Mixed_indexes = Labels.Pop_code==Mixed; 

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes))]));
Min_Sample_sizes = min(Sample_sizes);
disp([Sample_sizes]); 

Sample_indexes = [sum(Afr_indexes,2) sum(Eur_indexes,2) sum(Asi_indexes,2) sum(Mixed_indexes,2)];

hAxis(3) = subplot(2,3,3);
    disp('Case 3'); 
    rng(1);
    
    %Plotting the data (n=5)
    n=[5 25 10 20];
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    
hAxis(4) = subplot(2,3,4);
    disp('Case 4'); 
    rng(1);

    %Plotting the data
    n=[5 10 15 20];
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
  
hAxis(5) = subplot(2,3,5);
    disp('Case 5'); 
    rng(1);
    
    %Plotting the data (n=5)
    n=[98 25 150 24];
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

hAxis(6) = subplot(2,3,6);
    disp('Case 6');    
    rng(1);
    
    n=[98 83 30 15];
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

maximize

% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_2.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_2.tif', 'output', 'd:\Pops_2_clear.tif');

%% #3 Admixed populations (1)
% Study the origin of Indians
close all; clear all; clc

disp('#3 Admixed populations of different sizes (1)');
[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

% Get the records for Asians, Europeans, and Indians
Afr_codes = [1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Eur_codes = [1195]; Eur_indexes = (Labels.Pop_code==Eur_codes);
Asi_codes = [1029]; Asi_indexes = (Labels.Pop_code==Asi_codes);
Mixed = [1009, 1072, 1073, 1203, 1211]; Mixed_indexes = Labels.Pop_code==Mixed; %Indians

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes))]));
Min_Sample_sizes = min(Sample_sizes);

Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0];
disp([sum(Sample_indexes)]);

pops_for_legend = [];
figure
    hAxis = [];
    
hAxis(1) = subplot(2,3,1);
    disp('Case 1'); %Replicating Reich's results
    n=[0 99   146   321]; 
    
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    

% Get the records for Africans, Europeans, and Indians
Afr_codes = [1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Eur_codes = [1195]; Eur_indexes = (Labels.Pop_code==Eur_codes);
Asi_codes = [1029]; Asi_indexes = (Labels.Pop_code==Asi_codes);

%Indians as an admixed population
Mixed = [1009, 1072, 1073, 1203, 1211]; Mixed_indexes = Labels.Pop_code==Mixed; 

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes))]));
Min_Sample_sizes = min(Sample_sizes);

Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0];
disp([sum(Sample_indexes)]);


hAxis(2) = subplot(2,3,2);

    disp('Case 2'); 
    n=[178 99 0 321];

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

    
% Get the records for Africans, Asians, Europeans, and Indians
Afr_codes = [1201 1205 1206 1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Eur_codes = [1059]; Eur_indexes = (Labels.Pop_code==Eur_codes);
Asi_codes = [1085 1029 1197 1194 1028:1036 1197 1037:1038, 1040:1041]; Asi_indexes = (Labels.Pop_code==Asi_codes);

%Indians
Mixed = [1009, 1072, 1073, 1203, 1211]; Mixed_indexes = Labels.Pop_code==Mixed; 

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes))]));
Min_Sample_sizes = min(Sample_sizes);

Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0];
disp([sum(Sample_indexes)]);


hAxis(3) = subplot(2,3,3);
    disp('Case 2'); %Indians cluster very close to Europeans
    n=[400 40 100 320]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

% Get the records for Africans, Asians, Europeans, and Indians
Afr_codes = [1201 1205 1206 1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Eur_codes = [1202 1195]; Eur_indexes = (Labels.Pop_code==Eur_codes);
Asi_codes = [1033 1039:1040]; Asi_indexes = (Labels.Pop_code==Asi_codes); %Chinese

%Indians 
Mixed = [1009, 1072, 1073, 1203, 1211]; Mixed_indexes = Labels.Pop_code==Mixed; 

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes))]));
Min_Sample_sizes = min(Sample_sizes);

Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0];
disp([sum(Sample_indexes)]);


hAxis(4) = subplot(2,3,4);
    disp('Case 4'); %Indians cluster cery close to Asians
    n=[sum(Sample_indexes)];

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0);% hAxis, 6);


% Get the records for Africans, Asians, Europeans, and Indians
Afr_codes = [1201 1205 1206 1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Eur_codes = [1200 1084]; Eur_indexes = (Labels.Pop_code==Eur_codes);
Asi_codes = [1085 1029 1197 1194 1028:1036 1197 1037:1038, 1040:1041]; Asi_indexes = (Labels.Pop_code==Asi_codes);

%Indians
Mixed = [1009, 1072, 1073, 1203, 1211]; Mixed_indexes = Labels.Pop_code==Mixed; 

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes))]));
Min_Sample_sizes = min(Sample_sizes);

Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0];
disp([sum(Sample_indexes)]);


hAxis(5) = subplot(2,3,5);
    disp('Case 5'); 
    n=[25 220 490 320]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

    
hAxis(6) = subplot(2,3,6);
    disp('Case 6'); 
    n=[30 200 50 320]; 
    
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

maximize

% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_3_1.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_3_1.tif', 'output', 'd:\Pops_3_1_clear.tif');

%% #3 Admixed populations (2)
% The origin of AJs in light of Need et al. (2009)
%They used 507 non-AJs and 55 AJs
close all; clear all; clc

global Label;

disp('#3 Admixed populations of different sizes (2)');
[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

pops_for_legend = [];

figure
    hAxis = [];
hAxis(1) = subplot(2,2,1);

    disp('Case 1'); %Replicate Need et al. (2009) results

    Afr_codes = [1201 1205 1206 1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
    Eur_codes = [1202 1059 1156:1164 1182:1183 1071 1195 1200 1084]; Eur_indexes = (Labels.Pop_code==Eur_codes);
    Asi_codes = [1085 1029 1197 1194 1028:1036 1037:1038, 1040:1041]; Asi_indexes = (Labels.Pop_code==Asi_codes);
    Mixed = [1174:1178 1180:1181]; Mixed_indexes = Labels.Pop_code==Mixed; %Turks+Caucasus
    Other = [1006]; Other_indexes = Labels.Pop_code==Other; 

    % Find the smallest population
    Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes)) sum(sum(Other_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0 sum(Other_indexes,2)>0];
    disp([sum(Sample_indexes)]);
    n_vec = sum(Sample_indexes);
    
    n=[0 507 0 0 55]; %replicate the original study

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
    maximize

hAxis(2) = subplot(2,2,2);
    disp('Case 2'); %Turks also don't cluster with Europeans

    Afr_codes = [1201 1205 1206 1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
    Eur_codes = [1059 1156:1164 1200 1182:1183 1071]; Eur_indexes = (Labels.Pop_code==Eur_codes);
    Asi_codes = [1085 1029 1197 1194 1028:1036 1037:1038, 1040:1041]; Asi_indexes = (Labels.Pop_code==Asi_codes);
    Mixed = [1174:1178 1180:1181]; Mixed_indexes = Labels.Pop_code==Mixed; %Turks
    Other = [1079:1084 1077:1078]; Other_indexes = Labels.Pop_code==Other; %Not counted

    % Find the smallest population
    Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes)) sum(sum(Other_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0 sum(Other_indexes,2)>0];
    disp([sum(Sample_indexes)]);
    n_vec = sum(Sample_indexes);
    
    n=[0 n_vec(2) 0 n_vec(4) 0]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

hAxis(3) = subplot(2,2,3);
    disp('Case 3'); 

    Afr_codes = [1201 1205 1206 1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
    Eur_codes = [1202 1059 1156:1164 1182:1183 1071 1195 1200 1084]; Eur_indexes = (Labels.Pop_code==Eur_codes);
    Asi_codes = [1085 1029 1197 1194 1028:1036 1037:1038, 1040:1041]; Asi_indexes = (Labels.Pop_code==Asi_codes);
    Mixed = [1174:1178 1180:1181]; Mixed_indexes = Labels.Pop_code==Mixed; %Turks+Caucasus
    Other = [1006]; Other_indexes = Labels.Pop_code==Other; 

    % Find the smallest population
    Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes)) sum(sum(Other_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0 sum(Other_indexes,2)>0];
    disp([sum(Sample_indexes)]);
    n_vec = sum(Sample_indexes);
    
    n=[0 400 0 n_vec(4) 55]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

hAxis(4) = subplot(2,2,4);
    disp('Case 4'); 
    
    Afr_codes = [1206 1201]; Afr_indexes = (Labels.Pop_code==Afr_codes);
    Eur_codes = [1202 1200]; Eur_indexes = (Labels.Pop_code==Eur_codes);
    Asi_codes = [1029]; Asi_indexes = (Labels.Pop_code==Asi_codes);
    Mixed = [1174:1178 1180:1181]; Mixed_indexes = Labels.Pop_code==Mixed; %Turks
    Other = [1006]; Other_indexes = Labels.Pop_code==Other; %Not counted

    % Find the smallest population
    Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes)) sum(sum(Other_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0 sum(Other_indexes,2)>0];
    disp([sum(Sample_indexes)]);
    n_vec = sum(Sample_indexes);
    
    n=[100 100 100 50 55]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
    
maximize    
% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_3_3.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_3_3.tif', 'output', 'd:\Pops_3_3_clear.tif'); close;

%% #4 - Two admixed populations
% The origins of South Asians and Oceanians
close all; clear all; clc

disp('#4 Two Admixed populations of different sizes');
[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

% Get the records for Africans, Asians, Europeans, and AJs
Afr_codes = [1201 1205 1206 1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Eur_codes = [1200 1084]; Eur_indexes = (Labels.Pop_code==Eur_codes);
Asi_codes = [1085 1029 1197 1194 1028:1036 1037:1038, 1040:1041]; Asi_indexes = (Labels.Pop_code==Asi_codes); %East Asians

Mixed1 = [1009, 1072, 1073, 1193, 1203, 1211 1115:1122, 1209, 1123]; Mixed1_indexes = Labels.Pop_code==Mixed1; %South Asians
Mixed2 = [1124 1020]; Mixed2_indexes = Labels.Pop_code==Mixed2; %Oceanian

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed1_indexes)) sum(sum(Mixed2_indexes))]));
Min_Sample_sizes = min(Sample_sizes);

Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed1_indexes,2)>0 sum(Mixed2_indexes,2)>0 ];
disp([sum(Sample_indexes)]);

pops_for_legend = [];
figure
    hAxis = [];
hAxis(1) = subplot(2,2,1);
    rng(1);
    disp('Case 1'); 
    n=[20 20 20 20 20]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

hAxis(2) = subplot(2,2,2);
    rng(1);
    disp('Case 2'); 
    n=[50 50 50 20 20]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

hAxis(3) = subplot(2,2,3);
    rng(1);
    disp('Case 3'); 
    n=[300 50 300 500 24]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
    
hAxis(4) = subplot(2,2,4);
    rng(1);
    disp('Case 4');
    n=[10 60 100 200 24]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
   
maximize    
% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_4.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_4.tif', 'output', 'd:\Pops_4_clear.tif');

%% #5 - Multiple admixed populations
close all; clear all; clc;
disp('#5 Multiple Admixed populations of different sizes');

[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

% Get the records for Europeans, and AJs
Afr_codes = [1201 1205 1206 1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Eur_codes = [1001:1002 1005 1007 1016 1044:1047 1050 1056 1155:1165]; Eur_indexes = (Labels.Pop_code==Eur_codes);
Asi_codes = [1085 1029 1197 1194 1028:1036 1037:1038, 1040:1041]; Asi_indexes = (Labels.Pop_code==Asi_codes);
Mixed = [1006]; Mixed_indexes = Labels.Pop_code==Mixed; %AJs
Other = [1077:1078]; Other_indexes = Labels.Pop_code==Other; %Levantines

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes)) sum(sum(Other_indexes))]));
Min_Sample_sizes = min(Sample_sizes);

Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0 sum(Other_indexes,2)>0];
disp([sum(Sample_indexes)]);
n_vec = sum(Sample_indexes);

pops_for_legend = [];
figure
    hAxis = [];
    hAxis_num = 6;
    
hAxis(1) = subplot(2,3,1);

    disp('Case 1'); 
    n=[0 n_vec(2) 0 60 n_vec(5)]; 
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, hAxis_num);

hAxis(2) = subplot(2,3,2);
    disp('Case 2'); 
    n=[30 n_vec(2) 50 60 50]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, hAxis_num);

hAxis(3) = subplot(2,3,3);
    disp('Case 3'); 
    
    % Get the records for Africans, Asians, Europeans, and AJs
    Afr_codes = [1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
    Eur_codes = [1059]; Eur_indexes = (Labels.Pop_code==Eur_codes);
    Asi_codes = [1085 1029 1197 1194 1028:1036 1037:1038, 1040:1041 1204]; Asi_indexes = (Labels.Pop_code==Asi_codes);
    Mixed = [1006]; Mixed_indexes = Labels.Pop_code==Mixed; %AJs
    Other = [1207 1210 1198]; Other_indexes = Labels.Pop_code==Other; %Mxl, PR, Yemen

    % Find the smallest population
    Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes)) sum(sum(Other_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0 sum(Other_indexes,2)>0];
    disp([sum(Sample_indexes)]);
    n_vec = sum(Sample_indexes);

    n=[30 0 n_vec(3) 60 n_vec(5)]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, hAxis_num);
    
hAxis(4) = subplot(2,3,4);

    disp('Case 4'); 

    % Get the records for Africans, Asians, Europeans, and AJs
    Afr_codes = [1201 1205 1206 1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
    Eur_codes = [1084]; Eur_indexes = (Labels.Pop_code==Eur_codes);
    Asi_codes = [1085 1029 1197 1194 1028:1036 1037:1038, 1040:1041]; Asi_indexes = (Labels.Pop_code==Asi_codes);
    Mixed = [1006]; Mixed_indexes = Labels.Pop_code==Mixed; %AJs
    Other = [1077:1078 1115:1123 1209]; Other_indexes = Labels.Pop_code==Other; %ME and Pakistani

    % Find the smallest population
    Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes)) sum(sum(Other_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0 sum(Other_indexes,2)>0];
    disp([sum(Sample_indexes)]);
    n_vec = sum(Sample_indexes);

    n=[200 n_vec(2) 200 60 n_vec(5)]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0)%, hAxis, hAxis_num);

hAxis(5) = subplot(2,3,5);
    disp('Case 5'); 
    % Get the records for Africans, Asians, Europeans, and AJs
    Afr_codes = [1201 1205 1206 1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
    Eur_codes = [1059]; Eur_indexes = (Labels.Pop_code==Eur_codes);
    Asi_codes = [1085 1029 1197 1194 1028:1036 1037:1038, 1040:1041]; Asi_indexes = (Labels.Pop_code==Asi_codes);
    Mixed = [1006]; Mixed_indexes = Labels.Pop_code==Mixed; %AJs
    Other = [1077 1095 1151]; Other_indexes = Labels.Pop_code==Other; %Levantines

    % Find the smallest population
    Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes)) sum(sum(Other_indexes)) ]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0 sum(Other_indexes,2)>0];
    disp([sum(Sample_indexes)]);
    n_vec = sum(Sample_indexes);

    n=[200 30 0 400 n_vec(5)]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, hAxis_num);

%     Levantines are used twice due to their small number
hAxis(6) = subplot(2,3,6);
    disp('Case 6'); 

    % Get the records for Africans, Asians, Europeans, and AJs
    Afr_codes = [1201 1205 1206 1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
    Eur_codes = [1059]; Eur_indexes = (Labels.Pop_code==Eur_codes);
    Asi_codes = [1085 1029 1197 1194 1028:1036 1037:1038, 1040:1041]; Asi_indexes = (Labels.Pop_code==Asi_codes);
    Mixed = [1006]; Mixed_indexes = Labels.Pop_code==Mixed; %AJs
    Other = [1077 1095 1151]; Other_indexes = Labels.Pop_code==Other; %Levantines
    Other2 = [1077 1095 1151]; Other2_indexes = Labels.Pop_code==Other2; %Levantines

    % Find the smallest population
    Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(Mixed_indexes)) sum(sum(Other_indexes)) sum(sum(Other2_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Afr_indexes,2)>0 sum(Eur_indexes,2)>0 sum(Asi_indexes,2)>0 sum(Mixed_indexes,2)>0 sum(Other_indexes,2)>0 sum(Other2_indexes,2)>0];
    disp([sum(Sample_indexes)]);
    n_vec = sum(Sample_indexes);

    n=[200 30 0 50 n_vec(5) n_vec(6)];

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, hAxis_num);

maximize
% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_5.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_5.tif', 'output', 'd:\Pops_5_clear.tif');

%% #6 - Excluding continental populations led to completely random results 
close all; clear all; clc;
disp('#6 Multiple Admixed populations of fixed sizes, but random individuals');
% Same populations, however 16 random samples in each time. Also one
% population would be omitted at random in each analysis.
% notice, that some popualtions were merged to their small sample sizes

[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

% Get the records for Africans, Asians, Europeans, AJs, North Africa, and AA 
A1_codes = 1205; A1_indexes = (Labels.Pop_code==A1_codes); 
A2_codes = 1192; A2_indexes = (Labels.Pop_code==A2_codes);
A3_codes = 1112; A3_indexes = (Labels.Pop_code==A3_codes);

S2_codes = 1204; S2_indexes = (Labels.Pop_code==S2_codes); %Vietnam

E2_codes = 1202; E2_indexes = (Labels.Pop_code==E2_codes); %Spanish
E3_codes = 1080; E3_indexes = (Labels.Pop_code==E3_codes); %Saridnians
E4_codes = [1124]; E4_indexes = (Labels.Pop_code==E4_codes); %Papua New Guinea
E5_codes = [1129]; E5_indexes = (Labels.Pop_code==E5_codes); %Russians

% Various populaitons
M7_codes =  [1073]; M7_indexes = Labels.Pop_code==M7_codes; %GIH
M10_codes = [1002]; M10_indexes = Labels.Pop_code==M10_codes; %Caucasus
M11_codes = [1050]; M11_indexes = Labels.Pop_code==M11_codes; %Druze
M12_codes = [1202]; M12_indexes = Labels.Pop_code==M12_codes; %Spanish
M13_codes = [1210]; M13_indexes = Labels.Pop_code==M13_codes; %Puerto Ricans
M16_codes = [1207]; M16_indexes = Labels.Pop_code==M16_codes; %Mexicans
M17_codes = 1204; M17_indexes = (Labels.Pop_code==M17_codes);  %Vietnam (Kinh, Ho Chi Minh City)
M18_codes = 1085; M18_indexes = (Labels.Pop_code==M18_codes);  %JPT

Sample_indexes = [sum(A1_indexes,2)>0 sum(A2_indexes,2)>0 sum(A3_indexes,2)>0 ...
                  sum(S2_indexes,2)>0 ...
                  sum(E2_indexes,2)>0 sum(E3_indexes,2)>0 sum(E4_indexes,2)>0 sum(E5_indexes,2)>0 ...
                  sum(M7_indexes,2)>0 sum(M10_indexes,2)>0 sum(M11_indexes,2)>0 sum(M12_indexes,2)>0 sum(M13_indexes,2)>0 sum(M16_indexes,2)>0 sum(M17_indexes,2)>0 sum(M18_indexes,2)>0];
disp([sum(Sample_indexes)]);

% Sample random 10 individuals of each populations
sample_size = 10;
n_all = ones(1,size(Sample_indexes,2))*sample_size; 

pops_for_legend = [];
figure
    hAxis = [];
hAxis(1) = subplot(2,2,1);
    disp('Case 1'); %
    n = n_all; n(randsample(numel(n_all),1)) = 0; rng(5);
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

hAxis(2) = subplot(2,2,2);
    disp('Case 2'); %
    n = n_all; n(randsample(numel(n_all),1)) = 0; rng(2);
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

hAxis(3) = subplot(2,2,3);
    disp('Case 3'); %
    n = n_all; n(randsample(numel(n_all),1)) = 0; rng(3);
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

hAxis(4) = subplot(2,2,4);
    disp('Case 4'); %
    n = n_all; n(randsample(numel(n_all),1)) = 0; rng(8);
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
maximize

% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_6.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_6.tif', 'output', 'd:\Pops_6_clear.tif');
%% #7 - pairwise comparisons 
close all; clear all; clc;
global Labels;

disp('#7 Pairwise comparisons');
%Can PCA be used to decide whether two populations overlap or not? In other
%words, does overlap mean shared genetic origins.

[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

% Get the records for Africans, Asians, Europeans, and AJs
Pop1_codes = [1200]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %GBR
Pop2_codes = [1208]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Lima Peruvians
Pop3_codes = [1207]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %MXL
Pop4_codes = [1027]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %JPT
Pop5_codes = [1113]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %YRI
Pop6_codes = [1197]; Pop6_indexes = (Labels.Pop_code==Pop6_codes); %Vietnam (Kinh, Ho Chi Minh City)
Pop7_codes = [1085]; Pop7_indexes = (Labels.Pop_code==Pop7_codes); %China (Southern Han)

% Find the smallest population
Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes)) sum(sum(Pop5_indexes)) sum(sum(Pop6_indexes)) sum(sum(Pop7_indexes))]));
Min_Sample_sizes = min(Sample_sizes);

Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0 sum(Pop6_indexes,2)>0 sum(Pop7_indexes,2)>0];
disp([sum(Sample_indexes)]); 

pops_for_legend = [];
figure
    hAxis = [];
hAxis(1) = subplot(2,2,1);
    disp('Case 1'); %
    n=[90 0 0 93 0 93 0 ]; 
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

%     Add the previous individuals to a third population
hAxis(2) = subplot(2,2,2);
    disp('Case 2'); %
    n=[0 0 0 0 0 0 93 ]; 

    Pop_indexes2 = Find_n_indexes(Sample_indexes, n);
    Pop_indexes2 = Pop_indexes2(:);
    Pop_indexes2(Pop_indexes2==0) = [];
    Pop_indexes = [Pop_indexes' Pop_indexes2']'; %Combine the first and second
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

% Two somewhat separate populations, merged with the aid of a third one
%     Run multiple times
hAxis(3) = subplot(2,2,3);
    disp('Case 3'); %
    n=[0 60 60 0 0 0 0]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

%     Add the previous individuals to a third population
hAxis(4) = subplot(2,2,4);
    disp('Case 4'); %

    n=[0 0 0 0 60 0 0]; 
    
    Pop_indexes2 = Find_n_indexes(Sample_indexes, n);
    Pop_indexes2 = Pop_indexes2(:);
    Pop_indexes2(Pop_indexes2==0) = [];
    Pop_indexes = [Pop_indexes' Pop_indexes2']'; %Combine the first and second
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
    
maximize

% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_7.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_7.tif', 'output', 'd:\Pops_7_clear.tif');

%% #8 Case-control matching (1) 
close all; clear all; clc;
global Labels;

disp('#8 Case-control matching (1)');

[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

% Chances of random clusters to form
vector = [ones(1,107) ones(1,107)*2 ones(1,107)*3];
vector_test = vector;
num_of_clusters = floor(sqrt(numel(vector)));
res = [];
for i=1:num_of_clusters
    [y, idx] = datasample(vector_test,num_of_clusters, 'Replace',false);
    vector_test(idx) = [];
    res(i) = numel(unique(y));
end;
disp(sum(res==1)/numel(res));


pops_for_legend = [];
figure
    hAxis = [];

hAxis(1) = subplot(2,2,1);
    % Analyzing only 4 European populations yilds low clustering
    disp('Case 1');
    rng(1)    

    Pop1_codes = [1195]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Europeans
    Pop2_codes = [1202]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans
    Pop3_codes = [1084]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Europeans
    Pop4_codes = [1200]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Europeans
 
    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes)) ]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 ];
    disp([sum(Sample_indexes)]); 
    
    n=[sum(Sample_indexes)]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

    %Calculate clusters for ALL Europeans
    pop_names_selection = Labels.Pop_name(Pop_indexes);
    [idx, C] = kmeans(SCORE(:,1:2), floor(sqrt(size(SCORE(:,1:2),1))), 'start', 'sample');

    pop_names_same = [];
    for i=1:max(idx)
        curr_clsuter_indexes = find(idx==i);
        pop_names_selection(curr_clsuter_indexes);
        pop_names_same(i) = numel(unique(pop_names_selection(curr_clsuter_indexes)));
    end;
    disp(['Homogneiety of the European cluster (%): ' num2str((sum(pop_names_same==1)/numel(pop_names_same)))]); % 0.4285
    
hAxis(2) = subplot(2,2,2);
    %GWAS on 3 continental populations, including 3 European populations.
    %High homogeneity for the European clusters.
    disp('Case 2');
    rng(1)
    
    %Sample 1KG populations
    Pop1_codes = [1084 1195 1200 1202]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Europeans
    Pop2_codes = [1113]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %YRI
    Pop3_codes = [1029 ]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Han
    
    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) ]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 ];
    disp([sum(Sample_indexes)]); 
    n=[sum(Sample_indexes)];

    %Calculate PCA
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

    %Calculate pair clusters (pair individuals and see if they share ancestry)
    EU_indexes = find(sum(Pop1_indexes,2));
    [~, IA, ~]=intersect(Pop_indexes, EU_indexes);
    pop_names_selection = Labels.Pop_name(Pop_indexes(IA));
    
    [idx, ~] = kmeans(SCORE(IA,1:2), floor(sqrt(size(SCORE(IA,1:2),1))));
    pop_names_same = [];
    for i=1:max(idx)
        curr_clsuter_indexes = find(idx==i);
        pop_names_selection(curr_clsuter_indexes);
        pop_names_same(i) = numel(unique(pop_names_selection(curr_clsuter_indexes)));
    end;
    disp(['Homogneiety of the European  cluster (%): ' num2str((sum(pop_names_same==1)/numel(pop_names_same)))]); %0.14286

hAxis(3) = subplot(2,2,3);
    %GWAS on the 3 European populations + more reference populations
    %Fins were included as reference population and are not considered in
    %the calculation of homogneiety
    %decreased the homogeneity of the European cluster.
    disp('Case 3');
    rng(1)    

    %Sample 1KG populations
    Pop1_codes = [1084 1195 1200 1202]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Europeans
    Pop2_codes = [1113 1205]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %YRI
    Pop3_codes = [1029 ]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Han
    Pop4_codes = [1073 1059]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %GIH
    
    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0];
    disp([sum(Sample_indexes)]); 
    n=[sum(Sample_indexes)]; 
    
    %Calculate PCA
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

    %Calculate clusters
    EU_indexes = find(sum(Pop1_indexes,2));
    [~, IA, ~]=intersect(Pop_indexes, EU_indexes);
    pop_names_selection = Labels.Pop_name(Pop_indexes(IA));
    
    [idx, ~] = kmeans(SCORE(IA,1:2), floor(sqrt(size(SCORE(IA,1:2),1))));
    pop_names_same = [];
    for i=1:max(idx)
        curr_clsuter_indexes = find(idx==i);
        pop_names_selection(curr_clsuter_indexes);
        pop_names_same(i) = numel(unique(pop_names_selection(curr_clsuter_indexes)));
    end;
    disp(['Homogneiety of the European  cluster (%): ' num2str((sum(pop_names_same==1)/numel(pop_names_same)))]); %0.095
   
hAxis(4) = subplot(2,2,4);
    %Adding non-European populations further decreases the clustering quality of the Europeans. 
    disp('Case 4');
    rng(1)    

    Pop1_codes = [1084 1195 1200 1202]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Europeans
    Pop2_codes = [1113 1205 1206 1192 1191 1201]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %YRI
    Pop3_codes = [1029 1204 1027 1197]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %East Asians
    Pop4_codes = [1059 1073 1209 1203 1207 1208 1210 1211 1193 1198]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); 

    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0];
    disp([sum(Sample_indexes)]); 
    n=[sum(Sample_indexes)]; 
    
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

    %Calculate clusters
    EU_indexes = find(sum(Pop1_indexes,2));
    [~, IA, IB]=intersect(Pop_indexes, EU_indexes);
    pop_names_selection = Labels.Pop_name(Pop_indexes(IA));
    disp(unique(pop_names_selection));
    
    [idx, C] = kmeans(SCORE(IA,1:2), floor(sqrt(size(SCORE(IA,1:2),1))));
    pop_names_same = [];
    for i=1:max(idx)
        curr_clsuter_indexes = find(idx==i);
        pop_names_selection(curr_clsuter_indexes);
        pop_names_same(i) = numel(unique(pop_names_selection(curr_clsuter_indexes)));
    end;
    disp(['Homogneiety of the European cluster (%): ' num2str((sum(pop_names_same==1)/numel(pop_names_same)))]); %0.14286
    
maximize
    
% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_8_1.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_8_1.tif', 'output', 'd:\Pops_8_1_clear.tif');

%% #8 Case-control matching (1_2) 
close all; clear all; clc;

disp('#8 Case-control matching (1-2)');
% Comparing the effect of popualtion number and #PCs on the homogneiety of clusters

[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

%Population IDs
pop_vec = {[1026 1043 1051 1201 1205 1092 1100 1107 1108 1110] ... %10 Africans
           [1026 1043 1051 1201 1205 1092 1100 1107 1108 1110 1112 1113 1206 1154 1172 1192 1088 1090 1096 1170] ... 20 Africans
           [1003 1195 1059 1046 1063 1061 1062 1071 1099 1155] ... %10 Europeans
           [1003 1195 1059 1046 1063 1061 1062 1071 1099 1155 1200 1202 1084 1016 1056 1098 1079 1080 1084 1114] ... %20 Europeans
           [1193 1025 1027 1209 1032 1036 1197 1037 1038 1039] ... %10 East Asians
           [1193 1025 1027 1209 1032 1036 1197 1037 1038 1039 1041 1073 1203 1085 1093 1111 1209 1211 1166 1171]}; %20 East Asians

homogeneity_accuracy = []; %keep results here

disp('Start calcualting cluster homogeneity for selected populations...');
pops_for_legend = [];
for pop_index = 1:size(pop_vec,2)

    Pop1_codes = pop_vec{pop_index};
    Pop1_indexes = (Labels.Pop_code==Pop1_codes); 

    % Find the smallest population
    Sample_sizes = [sum(sum(Pop1_indexes))];
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Pop1_indexes,2)>0];
    n=[sum(Sample_indexes)];

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    %Calculating PCA once for 10 components
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:), 40);
%         CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0);

    %Calculate clusters 
    pcs_vec = 2:1:40; %number of PCs
    for j=1:numel(pcs_vec)
        curr_pcs_vec = pcs_vec(j);
        pop_names_selection = Labels.Pop_name(Pop_indexes);
        [idx, C] = kmeans(SCORE(:,1:curr_pcs_vec), floor(sqrt(size(SCORE(:,1:curr_pcs_vec),1))), 'start', 'sample');

        pop_names_same = [];
        for i=1:max(idx)
            curr_clsuter_indexes = find(idx==i);
            pop_names_selection(curr_clsuter_indexes);
            pop_names_same(i) = numel(unique(pop_names_selection(curr_clsuter_indexes)));
        end;
        homogeneity_accuracy(pop_index, j) = sum(pop_names_same==1)/numel(pop_names_same);
        disp(['Homogeneous clusters (%): PCs ' num2str(curr_pcs_vec) '. ' num2str(homogeneity_accuracy(pop_index, j))]); 
    end;
end;
    
%  Plot the results  
% Plot all of them on the same X and Y.
% Add +1 and +2 to to differentiate the continental populations

plot(homogeneity_accuracy(1,:), 'Color', [1 0 0], 'Marker', 'o', 'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r'); hold on;
plot(homogeneity_accuracy(2,:), 'Color', [0.8 0 0], 'Marker', 's', 'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r'); hold on;

plot(1+homogeneity_accuracy(3,:), 'Color', [0 1 0], 'Marker', 'o', 'MarkerEdgeColor', 'g', 'MarkerFaceColor', 'g'); hold on;
plot(1+homogeneity_accuracy(4,:), 'Color', [0 0.8 0], 'Marker', 's', 'MarkerEdgeColor', 'g', 'MarkerFaceColor', 'g'); hold on;

plot(2+homogeneity_accuracy(5,:), 'Color', [0 0 1], 'Marker', 'o', 'MarkerEdgeColor', 'b', 'MarkerFaceColor', 'b'); hold on;
plot(2+homogeneity_accuracy(6,:), 'Color', [0 0 0.8], 'Marker', 's', 'MarkerEdgeColor', 'b', 'MarkerFaceColor', 'b'); hold on;

maximize 

set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
set(gca, 'Box', 'off');
% axis off;

% print('-dtiff', 'd:\Pops_8_1_1.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_8_1_1.tif', 'output', 'd:\Pops_8_1_1_clear.tif');

%% #8 Case-control matching (2)    
close all; clear all; clc;
global Labels;

disp('#8 Case-control matching (2)');
% Showing that PR are indistinguishable from Europeans in various PCs.

[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

pops_for_legend = [];

%Addressing a claim that PCA can be used to verify that individuals are
%Europeans. Here, PR cluster with Europeans
Pop1_codes = [1084 1195]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Europeans
Pop2_codes = [1200 1202]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans
Pop3_codes = [1210]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %PR

% Find the smallest population
Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes))]));
Min_Sample_sizes = min(Sample_sizes);

Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0];
disp([sum(Sample_indexes)]); 
n=[150 150 20]; 

Pop_indexes = Find_n_indexes(Sample_indexes, n);
Pop_indexes = Pop_indexes(:);
Pop_indexes(Pop_indexes==0) = [];
pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
[SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:), 20);
    
figure
    hAxis = [];
hAxis(1) = subplot(2,2,1);
    disp('Case 1'); 
    rng(1)

    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

hAxis(2) = subplot(2,2,2);
    disp('Case 2'); %
    CalculatePCA_pops_plot(SCORE(:,2:3), pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

hAxis(3) = subplot(2,2,3);
    disp('Case 3'); %
    CalculatePCA_pops_plot(SCORE(:,4:5), pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
   
hAxis(4) = subplot(2,2,4);
    disp('Case 4'); %
    CalculatePCA_pops_plot(SCORE(:,19:20), pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

    %Print the explained variation of the first 4 PCs
    disp('Printing the PCs:');
    temp = pcvars./sum(pcvars);
    disp([(1:20)' temp(1:20).*100]);

maximize

% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_8_2.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_8_2.tif', 'output', 'd:\Pops_8_2_clear.tif');

%% #8 Case-control matching (3)
close all; clear all; clc;
global Labels;

disp('#8 Case-control matching (3)');

[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

Pop1_codes = [1197 1085]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Chinese and Japanese
Pop2_codes = [1084]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %TSI
Pop3_codes = [1207]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Mexicans

figure
pops_for_legend = [];
sample_sizes = [5 25 50];
hAxis = [];

disp('PCs 1-2')
Save_SCORE = {};
Save_pcvars = {};
Save_Pop_indexes = {};

for i=1:3
    rng(1)
   
    hAxis(i) = subplot(2,3,i);
    disp(i);
    
    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0];
    disp([sum(Sample_indexes)]); 
    n=sum(Sample_indexes);
    n(end)=sample_sizes(i);
    
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

    %Save variables
    Save_SCORE{i} = SCORE(:,3:4);
    Save_pcvars{i} = pcvars;
    Save_Pop_indexes{i} = Pop_indexes;
    
    %Calculate clusters
    EU_indexes = find(sum(Pop1_indexes,2));
    [~, IA, IB]=intersect(Pop_indexes, EU_indexes);
    pop_names_selection = Labels.Pop_name(Pop_indexes(IA));
    
    [idx, C] = kmeans(SCORE(IA,1:2), floor(sqrt(size(SCORE(IA,1:2),1))), 'start', 'sample');
    pop_names_same = [];
    for i=1:max(idx)
        curr_clsuter_indexes = find(idx==i);
        pop_names_selection(curr_clsuter_indexes);
        pop_names_same(i) = numel(unique(pop_names_selection(curr_clsuter_indexes)));
    end;
    
    %Print the first 4 PCs 
    disp('Print the first 4 PCs...');
    temp = pcvars./sum(pcvars);
    disp(temp(1:4).*100);    
end;

disp('PCs 3-4');
for i=4:6
    rng(1)

    hAxis(i) = subplot(2,3,i);

    CalculatePCA_pops_plot(Save_SCORE{i-3}, Save_pcvars{i-3}, Labels, Save_Pop_indexes{i-3}, 0, hAxis, 6);
end;

maximize

% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_8_3.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_8_3.tif', 'output', 'd:\Pops_8_3_clear.tif');
%% #9a Union of datasets
% close all; clear all; clc;
% global Labels;

disp('#9a calculating PCA of two datasets and then plotting them together');

[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

figure
hAxis = [];
pops_for_legend = [];

hAxis(1) = subplot(2,2,1);
    disp('Case 1');
    rng(1);
    
    % Get the records for Africans, Asians, Europeans, and AJs
    Pop1_codes = [1113]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Africans
    Pop2_codes = [1200]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans 
    Pop3_codes = [1029]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Asians 
    Pop4_codes = [1204]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Vietnamese

    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0];
    disp([sum(Sample_indexes)]); 
    n=[50 50 50 50]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    %Original populations
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
    
    %Draw line under the first cohort
    pops = Labels.Pop_name(Pop_indexes);
    unique_pops = unique(pops);
    for j=1:size(unique_pops,1)
        curr_pop = unique_pops(j);
        curr_SCORE = SCORE(find(ismember(pops, curr_pop)),1:2);
        line_axis = [min(curr_SCORE) max(curr_SCORE)];
        line_axis(2) = line_axis(2)-5; %Reduce the Y 
        line([line_axis(1) line_axis(3)], [line_axis(2) line_axis(2)], 'Color', 'r');
    end;
    
    fix_axis = [min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    hold on;

        % Get the records for Indians (replace the third population)
        Pop1_codes = [1113]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Africans
        Pop2_codes = [1200]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans 
        Pop3_codes = [1029]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Asians 
        Pop4_codes = [1204]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Vietnamese

        % Find the smallest population
        Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes)) ]));
        Min_Sample_sizes = min(Sample_sizes);

        Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 ];
        disp([sum(Sample_indexes)]); %              10    10    10
        n=repmat(min([sum(Sample_indexes)]),1,4);

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:)); 
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
    
    %Draw line under the second cohort
    pops = Labels.Pop_name(Pop_indexes);
    unique_pops = unique(pops);
    for j=1:size(unique_pops,1)
        curr_pop = unique_pops(j);
        curr_SCORE = SCORE(find(ismember(pops, curr_pop)),1:2);
        line_axis = [min(curr_SCORE) max(curr_SCORE)];
        line_axis(2) = line_axis(2)-5; %Reduce the Y 
        line([line_axis(1) line_axis(3)], [line_axis(2) line_axis(2)], 'Color', 'k');
    end;
    
    fix_axis2 = [min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    legend off;
    axis([min(fix_axis(1), fix_axis2(1)), max(fix_axis(2), fix_axis2(2)), min(fix_axis(3), fix_axis2(3)), max(fix_axis(4), fix_axis2(4))]); %fix axis
   
hAxis(2) = subplot(2,2,2);    
    %note, need to do zoom-out for this panel before printing
    disp('Case 2'); 
    rng(1);
   
    % Get the records for Africans, Asians, Europeans, and AJs
    Pop1_codes = [1113]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Africans
    Pop2_codes = [1200]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans 
    Pop3_codes = [1029]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Asians 
    Pop4_codes = [1204]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Armeindian

    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0];
    disp([sum(Sample_indexes)]); 
    n=[50 50 50 50]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);

    %Draw line under the first cohort
    pops = Labels.Pop_name(Pop_indexes);
    unique_pops = unique(pops);
    for j=1:size(unique_pops,1)
        curr_pop = unique_pops(j);
        curr_SCORE = SCORE(find(ismember(pops, curr_pop)),1:2);
        line_axis = [min(curr_SCORE) max(curr_SCORE)];
        line_axis(2) = line_axis(2)-5; %Reduce the Y 
        line([line_axis(1) line_axis(3)], [line_axis(2) line_axis(2)], 'Color', 'r');
    end;
    
    fix_axis = [min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    hold on;

    % Get the records for the secodn cohort
    Pop1_codes = [1206]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Africans MSL
    Pop2_codes = [1085]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Japan
    Pop3_codes = [1006]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %AJs
    Pop4_codes = [1202]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Europeans IBS 
    Pop5_codes = [1197]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %China (Southern Han)
    
    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes)) sum(sum(Pop5_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0];
    disp([sum(Sample_indexes)]);
    n=[sum(Sample_indexes)];

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
    
    %Draw line under the second cohort
    pops = Labels.Pop_name(Pop_indexes);
    unique_pops = unique(pops);
    for j=1:size(unique_pops,1)
        curr_pop = unique_pops(j);
        curr_SCORE = SCORE(find(ismember(pops, curr_pop)),1:2);
        line_axis = [min(curr_SCORE) max(curr_SCORE)];
        line_axis(2) = line_axis(2)-5; %Reduce the Y 
        line([line_axis(1) line_axis(3)], [line_axis(2) line_axis(2)], 'Color', 'k');
    end;
    
    fix_axis2 = [min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    legend off;

    axis([min(fix_axis(1), fix_axis2(1)), max(fix_axis(2), fix_axis2(2)), min(fix_axis(3), fix_axis2(3)), max(fix_axis(4), fix_axis2(4))]); %fix axis
    
hAxis(3) = subplot(2,2,3);
    disp('Case 3');
    rng(1);
    
    % Get the records for Africans, Asians, Europeans, and AJs
    Pop1_codes = [1113]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Africans
    Pop2_codes = [1200]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans 
    Pop3_codes = [1029]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Asians 
    Pop4_codes = [1204]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Vietnamese

    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0];
    disp([sum(Sample_indexes)]); 
    n=[20 20 20 20]; %Fixed sizes

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
    
    %Draw line under the first cohort
    pops = Labels.Pop_name(Pop_indexes);
    unique_pops = unique(pops);
    for j=1:size(unique_pops,1)
        curr_pop = unique_pops(j);
        curr_SCORE = SCORE(find(ismember(pops, curr_pop)),1:2);
        line_axis = [min(curr_SCORE) max(curr_SCORE)];
        line_axis(2) = line_axis(2)-5; %Reduce the Y 
        line([line_axis(1) line_axis(3)], [line_axis(2) line_axis(2)], 'Color', 'r');
    end;
    
    fix_axis = [min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    hold on;

    % Get the records for Africans, Europeans, and Indians (replace the third population)
    Pop1_codes = [1113]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Africans
    Pop2_codes = [1200]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans 
    Pop3_codes = [1006]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %AJs
    Pop4_codes = [1204]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Vietnamese

    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    %Keep sample size fixed
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0];
    disp([sum(Sample_indexes)]); %              10    10    10

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
    
    %Draw line under the second cohort
    pops = Labels.Pop_name(Pop_indexes);
    unique_pops = unique(pops);
    for j=1:size(unique_pops,1)
        curr_pop = unique_pops(j);
        curr_SCORE = SCORE(find(ismember(pops, curr_pop)),1:2);
        line_axis = [min(curr_SCORE) max(curr_SCORE)];
        line_axis(2) = line_axis(2)-5; %Reduce the Y 
        line([line_axis(1) line_axis(3)], [line_axis(2) line_axis(2)], 'Color', 'k');
    end;
    
    fix_axis2 = [min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    legend off;
    
    axis([min(fix_axis(1), fix_axis2(1)), max(fix_axis(2), fix_axis2(2)), min(fix_axis(3), fix_axis2(3)), max(fix_axis(4), fix_axis2(4))]); %fix axis
   
hAxis(4) = subplot(2,2,4);
    disp('Case 4'); 
    rng(1);
    
    % Get the records for Africans, Asians, Europeans, and AJs
    Pop1_codes = [1113]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Africans
    Pop2_codes = [1200]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans 
    Pop3_codes = [1029]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Asians 
    Pop4_codes = [1204]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Vietnamese

    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0];
    disp([sum(Sample_indexes)]); 
    n=[50 50 50 50]; 

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
    
    %Draw line under the first cohort
    pops = Labels.Pop_name(Pop_indexes);
    unique_pops = unique(pops);
    for j=1:size(unique_pops,1)
        curr_pop = unique_pops(j);
        curr_SCORE = SCORE(find(ismember(pops, curr_pop)),1:2);
        line_axis = [min(curr_SCORE) max(curr_SCORE)];
        line_axis(2) = line_axis(2)-5; %Reduce the Y 
        line([line_axis(1) line_axis(3)], [line_axis(2) line_axis(2)], 'Color', 'r');
    end;
    
    fix_axis = [min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    hold on;

    % Get the records for Indians (replace the third population)
    Pop1_codes = [1113]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Africans
    Pop2_codes = [1206]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Sierra Leone (Mende)
    Pop3_codes = [1200]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Europeans
    Pop4_codes = [1207]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Mexicans

    % Find the smallest population
    Sample_sizes = (([sum(sum(Pop1_indexes)) sum(sum(Pop2_indexes)) sum(sum(Pop3_indexes)) sum(sum(Pop4_indexes))]));
    Min_Sample_sizes = min(Sample_sizes);

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0];
    disp([sum(Sample_indexes)]);
    n = repmat(min([sum(Sample_indexes)]),1,4);

    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 4);
    
    %Draw line under the second cohort
    pops = Labels.Pop_name(Pop_indexes);
    unique_pops = unique(pops);
    for j=1:size(unique_pops,1)
        curr_pop = unique_pops(j);
        curr_SCORE = SCORE(find(ismember(pops, curr_pop)),1:2);
        line_axis = [min(curr_SCORE) max(curr_SCORE)];
        line_axis(2) = line_axis(2)-5; %Reduce the Y 
        line([line_axis(1) line_axis(3)], [line_axis(2) line_axis(2)], 'Color', 'k');
    end;
    
    fix_axis2 = [min(SCORE(:,1)) max(SCORE(:,1)) min(SCORE(:,2)) max(SCORE(:,2))];
    legend off;    
    
    axis([min(fix_axis(1), fix_axis2(1)), max(fix_axis(2), fix_axis2(2)), min(fix_axis(3), fix_axis2(3)), max(fix_axis(4), fix_axis2(4))]); %fix axis
    
maximize

% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_9_1.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_9_1.tif', 'output', 'd:\Pops_9_1_clear.tif');

%% #9b Projections
close all; clear all; clc;
global Labels;

disp('#9b Two overlapping PCAs, and four projected PCAs');

[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');
Data_ = single(Data_);

figure
hAxis = [];
pops_for_legend = [];

%Slower computers may wish to analyze fewer SNPs, otherwise this is
%128Kx128K matrix, which is quite heavy. For example: you can analyze
%90k/128k random SNPs. Strong computers should set this to 128568
% num_of_pca_pops = 128568;
num_of_pca_pops = 90000;

hAxis(1) = subplot(2,3,1);
    %Projecting continental popualtions very simialr to the initial
    %continental popualtions
    disp('Case 1');
    rng(1);

    % Get the records for Africans and Asians
    Pop1_codes = [1205]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Africans LWK
    Pop2_codes = [1029]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Asians CHB
    Pop3_codes = [1084]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Europeans TSI

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0];
    disp([sum(Sample_indexes)]); %             105   178   146

    n=[50 50 50]; %Use even sample sizes
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    old_Pop_indexes = Pop_indexes;
    
    %Remove columns without variance
    Data_clean = Data_(Pop_indexes,:);
    [~,c1] = find(var(double(Data_clean),1)==0);
    Data_clean(:,c1)=[];

    %Plot PCA
    [COEFF, SCORE, pcvars] = pca(single(Data_clean), 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    hold on;

    %Save on memory
    clear Data_clean;
    
    %The projected populations
    % Get the records for different Europeans and Asians
    Pop1_codes = [1113]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Africns
    Pop2_codes = [1059]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans FIN
    Pop3_codes = [1085]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %JPT
    Pop4_codes = [1202]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Spaniards

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0];
    disp([sum(Sample_indexes)]); %  105   178   146   123
    
    n=[100 100 100 100]; %Change sample sizes
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' old_Pop_indexes(:)' Pop_indexes(:)']';

    % Calculate the projection for these 4 populations
    disp('Projecting the data...')
    
    Fewer_SNPs = randperm(size(Data_,2), num_of_pca_pops);
    [M1_Transformed, ~] = pca_projection(single(Data_(Pop_indexes(:), Fewer_SNPs)), single(Data_(old_Pop_indexes, Fewer_SNPs)));
    
    % Plot the projections onto the first two principal components
    disp('Adding projected data to the figure...')
    Labels_color = Labels.Color(Pop_indexes(:),:);
    Labels_pops = Labels.Pop_name(Pop_indexes(:));

    %Plot all projected points as dots
    [~, pop_index] = unique(Labels_pops, 'stable');
    gscatter(M1_Transformed(:,1), M1_Transformed(:,2), Labels_pops, repmat([0 0 0], size(Labels_color(pop_index, :),1),1), '****', 4); %black star
    gscatter(M1_Transformed(:,1), M1_Transformed(:,2), Labels_pops, Labels_color(pop_index, :), 'oooo', 4); %color circle
    legend off;

hAxis(2) = subplot(2,3,2);
    %Projecting Europeans onto other Europeans
    disp('Case 2'); 
    rng(1);
    
    % Get the records for Africans and Asians
    Pop1_codes = [1059]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Europeans FIN
    Pop2_codes = [1195]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans GBR
    Pop3_codes = [1084]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Europeans TSI

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0];
    disp([sum(Sample_indexes)]); %             105   178   146

    n=[50 50 50]; %Use even sample sizes
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    old_Pop_indexes = Pop_indexes;
    
    %Remove columns without variance
    Data_clean = Data_(Pop_indexes,:);
    [~,c1] = find(var(double(Data_clean),1)==0);
    Data_clean(:,c1)=[];

    %Plot PCA
    [COEFF, SCORE, pcvars] = pca(double(Data_clean), 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    hold on;

    %Save on memory
    clear Data_clean;
    
    % Get the records for different Europeans and Asians
    Pop1_codes = [1202]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %IBS
    Pop2_codes = [1006]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %AJs
    Pop3_codes = [1063]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %France
    Pop4_codes = [1200]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %CEU

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0];
    disp([sum(Sample_indexes)]); %154    20    54    99
    
    n=[sum(Sample_indexes)]; %Change sample sizes
    n = [50 50 50 50]
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' old_Pop_indexes(:)' Pop_indexes(:)']';

    % Calculate the projection for these 4 populations
    disp('Projecting the data...')
%     [M1_Transformed, ~] = pca_projection(double(Data_(Pop_indexes(:),:)), double(Data_(old_Pop_indexes,:)));
  
    Fewer_SNPs = randperm(size(Data_,2), num_of_pca_pops);
    [M1_Transformed, ~] = pca_projection(single(Data_(Pop_indexes(:), Fewer_SNPs)), single(Data_(old_Pop_indexes, Fewer_SNPs)));

    % Plot the projections onto the first two principal components
    disp('Adding projected data to the figure...')
    Labels_color = Labels.Color(Pop_indexes(:),:);
    Labels_pops = Labels.Pop_name(Pop_indexes(:));

    %Plot all projected points as dots
    [~, pop_index] = unique(Labels_pops, 'stable');
    gscatter(M1_Transformed(:,1), M1_Transformed(:,2), Labels_pops, repmat([0 0 0], size(Labels_color(pop_index, :),1),1), '****', 4); %black star
    gscatter(M1_Transformed(:,1), M1_Transformed(:,2), Labels_pops, Labels_color(pop_index, :), 'oooo', 4); %color circle
    legend off;

hAxis(3) = subplot(2,3,3);
    %Even for Europeans alone, the results are messed up. There is no
    %resemblance of Europe's map
    disp('Case 3'); %
    rng(1)

    % Get the records for Africans, Asians, Europeans, and AJs
    Pop1_codes = [1059]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %FIN
    Pop2_codes = [1063 1062]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %France
    Pop3_codes = [1200]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %GBR
    Pop4_codes = [1084]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %TSI
    Pop5_codes = [1202]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %IBS

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0];
    disp([sum(Sample_indexes)]); 

    n=[50 50 50 50 50]; 
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    old_Pop_indexes = Pop_indexes;
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    %Remove columns without variance
    Data_clean = Data_(Pop_indexes,:);
    [~,c1] = find(var(double(Data_clean),1)==0);
    Data_clean(:,c1)=[];
    
    [COEFF, SCORE, pcvars] = pca(double(Data_clean), 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    hold on;
  
    %Save on memory
    clear Data_clean;
  
    % Get the records for Africans, Asians, Europeans, and Indians
    Pop1_codes = [1138]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Russia (Moscow)
    Pop2_codes = [1067:1068]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Greece
    Pop3_codes = [1069:1070]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Hungary
    Pop4_codes = [1184 1183 1182 1071]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %UK (Orkney Islands)+UK (Cornwall) + Iceland
    Pop5_codes = [1080]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Sardinia

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0];
    disp([sum(Sample_indexes)]); 

    n=[20 20 20 20 20]; 
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' old_Pop_indexes(:)' Pop_indexes(:)']';

    % Calculate the projection for the new color
    disp('Projecting the data...')
%     [M1_Transformed, ~] = pca_projection(double(Data_(Pop_indexes(:),:)), double(Data_(old_Pop_indexes,:)));
    
    Fewer_SNPs = randperm(size(Data_,2), num_of_pca_pops);
    [M1_Transformed, ~] = pca_projection(single(Data_(Pop_indexes(:), Fewer_SNPs)), single(Data_(old_Pop_indexes, Fewer_SNPs)));

    % Plot the projections onto the first two principal components
    disp('Adding projected data to the figure...')
    Labels_color = Labels.Color(Pop_indexes(:),:);
    Labels_pops = Labels.Pop_name(Pop_indexes(:));
    Labels_marker = Labels.marker(Pop_indexes(:));

    %Plot all points
    [~, pop_index] = unique(Labels_pops, 'stable');
    gscatter(M1_Transformed(:,1), M1_Transformed(:,2), Labels_pops, repmat([0 0 0], size(Labels_color(pop_index, :),1),1), '****', 4); %black star
    gscatter(M1_Transformed(:,1), M1_Transformed(:,2), Labels_pops, Labels_color(pop_index, :), 'oooo', 4); %color circle
    legend off;
    
hAxis(4) = subplot(2,3,4);
    %Calculate PCA for: LWK, YRI, and TSI.
    %Project: UK, FIN, JPT, and Spaniards
    disp('Case 4'); 
    rng(1)

    % Get the records for Africans and Asians
    Pop1_codes = [1205]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Africans LWK
    Pop2_codes = [1113]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Africans YRI
    Pop3_codes = [1084]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Europeans TSI

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0];
    disp([sum(Sample_indexes)]); %             105   178   146

    n=[50 50 50]; %Use even sample sizes
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    old_Pop_indexes = Pop_indexes;
    
    %Remove columns without variance
    Data_clean = Data_(Pop_indexes,:);
    [~,c1] = find(var(double(Data_clean),1)==0);
    Data_clean(:,c1)=[];

    %Plot PCA
    [COEFF, SCORE, pcvars] = pca(double(Data_clean), 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    hold on;

    %Save on memory
    clear Data_clean;
    
    % Get the records for different Europeans and Asians
    Pop1_codes = [1200]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %UK
    Pop2_codes = [1059]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %FIN 
    Pop3_codes = [1085]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %JPT
    Pop4_codes = [1202]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Spaniards

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0];
    disp([sum(Sample_indexes)]); %  105   178   146   123
    
    n=[100 100 100 100]; %Change sample sizes
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' old_Pop_indexes(:)' Pop_indexes(:)']';

    % Calculate the projection for these 4 populations
    disp('Projecting the data...')
%     [M1_Transformed, ~] = pca_projection(double(Data_(Pop_indexes(:),:)), double(Data_(old_Pop_indexes,:)));

    Fewer_SNPs = randperm(size(Data_,2), num_of_pca_pops);
    [M1_Transformed, ~] = pca_projection(single(Data_(Pop_indexes(:), Fewer_SNPs)), single(Data_(old_Pop_indexes, Fewer_SNPs)));

    % Plot the projections onto the first two principal components
    disp('Adding projected data to the figure...')
    Labels_color = Labels.Color(Pop_indexes(:),:);
    Labels_pops = Labels.Pop_name(Pop_indexes(:));

    %Plot all projected points as dots
    [~, pop_index] = unique(Labels_pops, 'stable');
    gscatter(M1_Transformed(:,1), M1_Transformed(:,2), Labels_pops, repmat([0 0 0], size(Labels_color(pop_index, :),1),1), '****', 4); %black star
    gscatter(M1_Transformed(:,1), M1_Transformed(:,2), Labels_pops, Labels_color(pop_index, :), 'oooo', 4); %color circle
    legend off;

hAxis(5) = subplot(2,3,5);
    %Calculate PCA for: UK, TSI, and Levantines
    %Project: GIH, FIN, CHB, AJs 
    disp('Case 5'); 
    rng(1)

    % Get the records for Levantines, Europeans, and Indians
    Pop1_codes = [1078 1077]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Palestinians + Bedouins
    Pop2_codes = [1084]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans TSI
    Pop3_codes = [1200]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Europeans UK

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0];
    disp([sum(Sample_indexes)]); %             105   178   146

    n=[80 80 80]; 
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    old_Pop_indexes = Pop_indexes;
    
    %Remove columns without variance
    Data_clean = Data_(Pop_indexes,:);
    [~,c1] = find(var(double(Data_clean),1)==0);
    Data_clean(:,c1)=[];

    [COEFF, SCORE, pcvars] = pca(double(Data_clean), 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    hold on;

    %Save on memory
    clear Data_clean;
    
    % Get the records for Europans, Asians, and AJs
    Pop1_codes = [1073]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Europeans GIH
    Pop2_codes = [1059]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans FIN
    Pop3_codes = [1029]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Asians CHB
    Pop4_codes = [1006]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %AJ

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0];
    disp([sum(Sample_indexes)]); %  105   178   146   123
    
    n=[100 100 100 100]; 
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' old_Pop_indexes(:)' Pop_indexes(:)']';

    % Calculate the projection for the new color
    disp('Projecting the data...')
%     [M1_Transformed, ~] = pca_projection(double(Data_(Pop_indexes(:),:)), double(Data_(old_Pop_indexes,:)));

    Fewer_SNPs = randperm(size(Data_,2), num_of_pca_pops);
    [M1_Transformed, ~] = pca_projection(single(Data_(Pop_indexes(:), Fewer_SNPs)), single(Data_(old_Pop_indexes, Fewer_SNPs)));


    % Plot the projections onto the first two principal components
    disp('Adding projected data to the figure...')
    Labels_color = Labels.Color(Pop_indexes(:),:);
    Labels_pops = Labels.Pop_name(Pop_indexes(:));

    %Plot all points
    [~, pop_index] = unique(Labels_pops, 'stable');
    gscatter(M1_Transformed(:,1), M1_Transformed(:,2), Labels_pops, repmat([0 0 0], size(Labels_color(pop_index, :),1),1), '****', 4); %black star
    gscatter(M1_Transformed(:,1), M1_Transformed(:,2), Labels_pops, Labels_color(pop_index, :), 'oooo', 4); %color circle
    maximize
    legend off;

hAxis(6) = subplot(2,3,6);
    %Calculate PCA for: TSI, UK, and MSL.
    %Project: JPT, CHB, Iranians, AJs, and AAs. 
    disp('Case 6'); 
    rng(1)

    % Get the records for Africans, Europeans, and Indians
    Pop1_codes = [1113]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Africans YRI
    Pop2_codes = [1084]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Europeans TSI
    Pop3_codes = [1200]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Europeans UK

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0];
    disp([sum(Sample_indexes)]); %             105   178   146

    n=[80 100 100]; 
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    old_Pop_indexes = Pop_indexes;
    
    %Remove columns without variance
    Data_clean = Data_(Pop_indexes,:);
    [~,c1] = find(var(double(Data_clean),1)==0);
    Data_clean(:,c1)=[];

    [COEFF, SCORE, pcvars] = pca(double(Data_clean), 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    hold on;

    %Save on memory
    clear Data_clean;
    
    % Get the records for Europans, Asians, and AJs
    Pop1_codes = [1085]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Asians JPT
    Pop2_codes = [1029]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Asians CHB
    Pop3_codes = [1007 1074]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Iranians
    Pop4_codes = [1006]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %AJ
    Pop5_codes = [1049]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %African Americans

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0];
    disp([sum(Sample_indexes)]); %  105   178   146   123
    
    n=[sum(Sample_indexes)];
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    pops_for_legend = [pops_for_legend' old_Pop_indexes(:)' Pop_indexes(:)']';

    % Calculate the projection for the new color
    disp('Projecting the data...')
%     [M1_Transformed, ~] = pca_projection(double(Data_(Pop_indexes(:),:)), double(Data_(old_Pop_indexes,:)));

    Fewer_SNPs = randperm(size(Data_,2), num_of_pca_pops);
    [M1_Transformed, ~] = pca_projection(single(Data_(Pop_indexes(:), Fewer_SNPs)), single(Data_(old_Pop_indexes, Fewer_SNPs)));

    % Plot the projections onto the first two principal components
    disp('Adding projected data to the figure...')
    Labels_color = Labels.Color(Pop_indexes(:),:);
    Labels_pops = Labels.Pop_name(Pop_indexes(:));

    %Plot all points
    [~, pop_index] = unique(Labels_pops, 'stable');
    gscatter(M1_Transformed(:,1), M1_Transformed(:,2), Labels_pops, repmat([0 0 0], size(Labels_color(pop_index, :),1),1), '****', 4); %black star
    gscatter(M1_Transformed(:,1), M1_Transformed(:,2), Labels_pops, Labels_color(pop_index, :), 'oooo', 4); %color circle
    maximize
    legend off;

% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_9_2.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_9_2.tif', 'output', 'd:\Pops_9_2_clear.tif');
%% #10 - Ancient DNA simulations
close all; clear all; clc;
global Labels;

disp('#10 Ancient DNA');
% Note: Running time of 10 minutes, becasue the projection is done per sample
% We remain interested in the ancient Levantines. Here, we will apply PCA with projection as commonly done in aDNA papers. 
% We will focus on aDNA from the Epipalaeolithic and Neolithic found in
% Israel.
% aDNA samples in eahc analysis are fixed.

%Load datasets
[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('LazaridisAncient');

%Replace Labels with grey color and round symbols
% This will be used when plotting the aDNA samples
Labels_grey = Labels;
Labels_grey.Color = ones(size(Labels_grey.Color)).*[0.74 0.74 0.74];
for i=1:size(Labels_grey.marker,1)
    Labels_grey.marker(i) = {'.'};
end;

figure
pops_for_legend = [];
hAxis = [];

num_of_pca_pops = 90000;

tic
hAxis(1) = subplot(2,3,1);
    disp('Case 1');
    rng(1);

    % Replicating Lazaridis et al. (2016).
    % The ancient Levantines cluster with modern-day Levantines
    
    %Load modern day populations
    Pop1_codes = [1050 1045 1077 1078 1086 1165 1151]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Middle Eastersn
    Pop2_codes = [1024 1070 1125 1079 1083 1068 1098 1185:1186 ]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Italy and Balkan, lithenia, Ukraine
    Pop3_codes = [1065 1001:1002 1005 1007 1174:1178 1180:1181]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Caucasus and Turkey
    Pop4_codes = [1074]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Iran, Iraq
    Pop5_codes = [1071 1155:1164 1138 1141 1128 1137 1061:1063]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Iceland, spain, Fin, Russians
    Pop6_codes = [1066 1075 1076 1097 1106 1173 1179 1190]; Pop6_indexes = (Labels.Pop_code==Pop6_codes); %Jews (not AJ)
    
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0 sum(Pop6_indexes,2)>0];
    disp([sum(Sample_indexes)]); %            
    
    n=[sum(Sample_indexes)];
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    old_Pop_indexes = Pop_indexes;
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    %Remove columns without variance
    Data_clean = Data_(Pop_indexes,:);
    [~,c1] = find(var(double(Data_clean),1)==0);
    Data_clean(:,c1)=[]; 
    
    [COEFF, SCORE, pcvars] = pca(double(Data_clean), 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE

    %Calculate PCA for modern-day people - this will plot modern
    %populations in color. mask the rest of the code and enable these
    %sections to get the figure in color
    
    % -- Load ancient populations --
    %This is alwyas the same
    Pop1_codes = [9067 9069 9071]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Iran
    Pop2_codes = [9072:9074]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Israel
    Pop3_codes = [9049 9042 9155 9151:9152 9122 9124]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Germany, Sweden, Switzerland, romania
    Pop4_codes = [9002 9041:9042]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Caucasus
    Pop5_codes = [9029:9030]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Austria
    
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0];
    disp([sum(Sample_indexes)]); %            
    
    n=[sum(Sample_indexes)];
    PopA_indexes = Find_n_indexes(Sample_indexes, n);
    PopA_indexes = PopA_indexes(:);
    PopA_indexes(PopA_indexes==0) = [];
    pops_for_legend = [pops_for_legend' PopA_indexes(:)']';

    % Calculate the projection for the ancient populations
    disp('Projecting the data...')
    
    %There is an internal function that won't take NaNs for M, so i am
    %sending Data_clea? and not Data_clea?, which has NaNs.
    %arrays must be the same size
    Data_clear = Data_(:,setdiff(1:size(Data_,2), c1));
    Data_clear(Data_clear==5)=NaN;

    %Reducing the number of SNPs due to memory concerns
    Fewer_SNPs = randperm(size(Data_clean,2), num_of_pca_pops);
    %Data_clean sends only modern
    %Data_clear with PopA_indexes has only ancient ones
    %they are the same size
    
    %The aDNA data has missing values, which would mess up the projection. 
    %pca_projection_2 keeps only the SNPs>threshold for EACH aDNA and
    %project it from the modern samples. This way, the aDNA samples don't
    %interfere with each other.
    [M1_Transformed, ~] = pca_projection_2(single(Data_clear(PopA_indexes(:), Fewer_SNPs)), single(Data_clean(:, Fewer_SNPs)));
    positive_indexes = sum(M1_Transformed(:,1:2),2)~=0; %Keep only data that had sufficient SNPs
    disp(['Plotting ' num2str(sum(positive_indexes)) ' points']);
    
    % Plot the projections onto the first two principal components
    disp('Adding projected data to the figure...')
    Labels_nick = Labels.Nick(PopA_indexes(positive_indexes));
    Labels_color = Labels.Color(PopA_indexes(positive_indexes),:);
    Labels_marker = Labels.marker(PopA_indexes(positive_indexes));
    Labels_pops = Labels.Pop_name(PopA_indexes(positive_indexes));
    
    %Plot all points - do figure within a figure to show that it's aDNA
    [~, pop_index] = unique(Labels_pops, 'stable');
    
    %Plot all points - do figure within a figure to show that it's aDNA
    %Calculate PCA for modern-day people
    CalculatePCA_pops_plot(SCORE, pcvars, Labels_grey, Pop_indexes(:), 0, hAxis, 6);
    hold on;    
    gscatter(M1_Transformed(positive_indexes,1), M1_Transformed(positive_indexes,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)), 4);
    gscatter(M1_Transformed(positive_indexes,1), M1_Transformed(positive_indexes,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)), 7);
    axis tight
    legend off;
    toc
   
hAxis(2) = subplot(2,3,2);
    disp('Case 2');
    rng(1);

    %Load modern day populations
    Pop1_codes = [1050 1045 1077 1078 1086 1165 1151]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Middle Eastersn
    Pop2_codes = [1024 1070 1125 1079 1083 1068 1098 1185:1186 ]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Italy and Balkan, lithenia, Ukraine
    Pop3_codes = [1065 1001:1002 1005 1007 1174:1178 1180:1181]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Caucasus and Turkey
    Pop4_codes = [1074]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Iran, Iraq
    Pop5_codes = [1071 1155:1164 1138 1141 1128 1137 1061:1063]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Iceland, spain, Fin, Russians
    Pop6_codes = [1066 1075 1076 1097 1106 1173 1179 1190]; Pop6_indexes = (Labels.Pop_code==Pop6_codes); %Jews no AJs
    Pop7_codes = [1029]; Pop7_indexes = (Labels.Pop_code==Pop7_codes); %CHB
    
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0 sum(Pop6_indexes,2)>0 sum(Pop7_indexes,2)>0];
    disp([sum(Sample_indexes)]); %            
    
    n=[sum(Sample_indexes)];
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    old_Pop_indexes = Pop_indexes;
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    %Remove columns without variance
    Data_clean = Data_(Pop_indexes,:);
    [~,c1] = find(var(double(Data_clean),1)==0);
    Data_clean(:,c1)=[]; 
    
    [COEFF, SCORE, pcvars] = pca(double(Data_clean), 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE

    %Calculate PCA for modern-day people - this will plot modern
    %populations in color. mask the rest of the code and enable these
    %sections to get the figure in color
%     CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

    % -- Load ancient populations --
    Pop1_codes = [9067 9069 9071]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Iran
    Pop2_codes = [9072:9074]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Israel
    Pop3_codes = [9049 9042 9155 9151:9152 9122 9124]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Germany, Sweden, Switzerland, romania
    Pop4_codes = [9002 9041:9042]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Caucasus
    Pop5_codes = [9029:9030]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Austria
    
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0];
    disp([sum(Sample_indexes)]); %            
    
    n=[sum(Sample_indexes)];
    PopA_indexes = Find_n_indexes(Sample_indexes, n);
    PopA_indexes = PopA_indexes(:);
    PopA_indexes(PopA_indexes==0) = [];
    pops_for_legend = [pops_for_legend' PopA_indexes(:)']';

    % Calculate the projection for the ancient populations
    disp('Projecting the data...')
    
    %There is an internal function that won't take NaNs for M, so i am
    %sending Data_clea? and not Data_clea?, which has NaNs.
    %arrays must be the same size
    Data_clear = Data_(:,setdiff(1:size(Data_,2), c1));
    Data_clear(Data_clear==5)=NaN;

    %Reducing the number of SNPs due to memory concerns
    Fewer_SNPs = randperm(size(Data_clean,2), num_of_pca_pops);
    %Data_clean sends only modern
    %Data_clear with PopA_indexes has only ancient ones
    %they are the same size
    
    %The aDNA data has missing values, which would mess up the projection. 
    %pca_projection_2 keeps only the SNPs>threshold for EACH aDNA and
    %project it from the modern samples. This way, the aDNA samples don't
    %interfere with each other.
    [M1_Transformed, ~] = pca_projection_2(single(Data_clear(PopA_indexes(:), Fewer_SNPs)), single(Data_clean(:, Fewer_SNPs)));
    positive_indexes = sum(M1_Transformed(:,1:2),2)~=0; %Keep only data that had sufficient SNPs
    disp(['Plotting ' num2str(sum(positive_indexes)) ' points']);
    
    % Plot the projections onto the first two principal components
    disp('Adding projected data to the figure...')
    Labels_nick = Labels.Nick(PopA_indexes(positive_indexes));
    Labels_color = Labels.Color(PopA_indexes(positive_indexes),:);
    Labels_marker = Labels.marker(PopA_indexes(positive_indexes));
    Labels_pops = Labels.Pop_name(PopA_indexes(positive_indexes));
    
    %Plot all points - do figure within a figure to show that it's aDNA
    [~, pop_index] = unique(Labels_pops, 'stable');
    
    CalculatePCA_pops_plot(SCORE, pcvars, Labels_grey, Pop_indexes(:), 0, hAxis, 6);
    hold on;    
    gscatter(M1_Transformed(positive_indexes,1), M1_Transformed(positive_indexes,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)), 4);
    gscatter(M1_Transformed(positive_indexes,1), M1_Transformed(positive_indexes,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)), 7);
    axis tight
    legend off;
    toc
    
hAxis(3) = subplot(2,3,3);
    disp('Case 3');
    rng(1);
    
    %Load modern day populations
    Pop1_codes = [1050 1045 1077 1078 1086 1165 1151]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Middle Eastersn
    Pop2_codes = [1024 1070 1125 1079 1083 1068 1098 1185:1186 ]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Italy and Balkan, lithenia, Ukraine
    Pop3_codes = [1065 1001:1002 1005 1007 1174:1178 1180:1181]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Caucasus and Turkey
    Pop4_codes = [1074]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Iran, Iraq
    Pop5_codes = [1071 1155:1164 1138 1141 1128 1137 1061:1063]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Iceland, spain, Fin, Russians
    Pop6_codes = [1066 1075 1076 1097 1106 1173 1179 1190]; Pop6_indexes = (Labels.Pop_code==Pop6_codes); %Jews no AJs
    Pop7_codes = [1209]; Pop7_indexes = (Labels.Pop_code==Pop7_codes); %Pakistani
    
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0 sum(Pop6_indexes,2)>0 sum(Pop7_indexes,2)>0];
    disp([sum(Sample_indexes)]); %            
    
    n=[sum(Sample_indexes)];
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    old_Pop_indexes = Pop_indexes;
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    %Remove columns without variance
    Data_clean = Data_(Pop_indexes,:);
    [~,c1] = find(var(double(Data_clean),1)==0);
    Data_clean(:,c1)=[]; 
    
    [COEFF, SCORE, pcvars] = pca(double(Data_clean), 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE
    
    %Calculate PCA for modern-day people - this will plot modern
    %populations in color. mask the rest of the code and enable these
    %sections to get the figure in color
%     CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

    % -- Load ancient populations --
    Pop1_codes = [9067 9069 9071]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Iran
    Pop2_codes = [9072:9074]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Israel
    Pop3_codes = [9049 9042 9155 9151:9152 9122 9124]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Germany, Sweden, Switzerland, romania
    Pop4_codes = [9002 9041:9042]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Caucasus
    Pop5_codes = [9029:9030]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Austria
    
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0];
    disp([sum(Sample_indexes)]); %            
    
    n=[sum(Sample_indexes)];
    PopA_indexes = Find_n_indexes(Sample_indexes, n);
    PopA_indexes = PopA_indexes(:);
    PopA_indexes(PopA_indexes==0) = [];
    pops_for_legend = [pops_for_legend' PopA_indexes(:)']';

    % Calculate the projection for the ancient populations
    disp('Projecting the data...')
    
    %There is an internal function that won't take NaNs for M, so i am
    %sending Data_clea? and not Data_clea?, which has NaNs.
    %arrays must be the same size
    Data_clear = Data_(:,setdiff(1:size(Data_,2), c1));
    Data_clear(Data_clear==5)=NaN;

    %Reducing the number of SNPs due to memory concerns
    Fewer_SNPs = randperm(size(Data_clean,2), num_of_pca_pops);
    %Data_clean sends only modern
    %Data_clear with PopA_indexes has only ancient ones
    %they are the same size
    
    %The aDNA data has missing values, which would mess up the projection. 
    %pca_projection_2 keeps only the SNPs>threshold for EACH aDNA and
    %project it from the modern samples. This way, the aDNA samples don't
    %interfere with each other.
    [M1_Transformed, ~] = pca_projection_2(single(Data_clear(PopA_indexes(:), Fewer_SNPs)), single(Data_clean(:, Fewer_SNPs)));
    positive_indexes = sum(M1_Transformed(:,1:2),2)~=0; %Keep only data that had sufficient SNPs
    disp(['Plotting ' num2str(sum(positive_indexes)) ' points']);
    
    % Plot the projections onto the first two principal components
    disp('Adding projected data to the figure...')
    Labels_nick = Labels.Nick(PopA_indexes(positive_indexes));
    Labels_color = Labels.Color(PopA_indexes(positive_indexes),:);
    Labels_marker = Labels.marker(PopA_indexes(positive_indexes));
    Labels_pops = Labels.Pop_name(PopA_indexes(positive_indexes));
    
    %Plot all points - do figure within a figure to show that it's aDNA
    [~, pop_index] = unique(Labels_pops, 'stable');
    
    CalculatePCA_pops_plot(SCORE, pcvars, Labels_grey, Pop_indexes(:), 0, hAxis, 6);
    hold on;    
    gscatter(M1_Transformed(positive_indexes,1), M1_Transformed(positive_indexes,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)), 4);
    gscatter(M1_Transformed(positive_indexes,1), M1_Transformed(positive_indexes,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)), 7);
    axis tight
    legend off;
    toc

hAxis(4) = subplot(2,3,4);
    disp('Case 4');
    rng(1);
    
    %Load modern day populations
    Pop1_codes = [1050 1045 1077 1078 1086 1165 1151]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Middle Eastersn
    Pop2_codes = [1024 1070 1125 1079 1083 1068 1098 1185:1186 ]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Italy and Balkan, lithenia, Ukraine
    Pop3_codes = [1065 1001:1002 1005 1007 1174:1178 1180:1181]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Caucasus and Turkey
    Pop4_codes = [1074]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Iran, Iraq
    Pop5_codes = [1071 1155:1164 1138 1141 1128 1137 1061:1063]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Iceland, spain, Fin, Russians
    Pop6_codes = [1066 1075 1076 1097 1106 1173 1179 1190]; Pop6_indexes = (Labels.Pop_code==Pop6_codes); %Jews no AJs
    Pop7_codes = [1126:1150]; Pop7_indexes = (Labels.Pop_code==Pop7_codes); %Russians
    
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0 sum(Pop6_indexes,2)>0 sum(Pop7_indexes,2)>0];
    disp([sum(Sample_indexes)]); %            
    
    n=[sum(Sample_indexes)];
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    old_Pop_indexes = Pop_indexes;
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    %Remove columns without variance
    Data_clean = Data_(Pop_indexes,:);
    [~,c1] = find(var(double(Data_clean),1)==0);
    Data_clean(:,c1)=[]; 
    
    [COEFF, SCORE, pcvars] = pca(double(Data_clean), 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE

    %Calculate PCA for modern-day people - this will plot modern
    %populations in color. mask the rest of the code and enable these
    %sections to get the figure in color
%     CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    
    % -- Load ancient populations --
    Pop1_codes = [9067 9069 9071]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Iran
    Pop2_codes = [9072:9074]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Israel
    Pop3_codes = [9049 9042 9155 9151:9152 9122 9124]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Germany, Sweden, Switzerland, romania
    Pop4_codes = [9002 9041:9042]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Caucasus
    Pop5_codes = [9029:9030]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Austria
    
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0];
    disp([sum(Sample_indexes)]); %            
    
    n=[sum(Sample_indexes)];
    PopA_indexes = Find_n_indexes(Sample_indexes, n);
    PopA_indexes = PopA_indexes(:);
    PopA_indexes(PopA_indexes==0) = [];
    pops_for_legend = [pops_for_legend' PopA_indexes(:)']';

    % Calculate the projection for the ancient populations
    disp('Projecting the data...')
    
    %There is an internal function that won't take NaNs for M, so i am
    %sending Data_clea? and not Data_clea?, which has NaNs.
    %arrays must be the same size
    Data_clear = Data_(:,setdiff(1:size(Data_,2), c1));
    Data_clear(Data_clear==5)=NaN;

    %Reducing the number of SNPs due to memory concerns
    Fewer_SNPs = randperm(size(Data_clean,2), num_of_pca_pops);
    %Data_clean sends only modern
    %Data_clear with PopA_indexes has only ancient ones
    %they are the same size
    
    %The aDNA data has missing values, which would mess up the projection. 
    %pca_projection_2 keeps only the SNPs>threshold for EACH aDNA and
    %project it from the modern samples. This way, the aDNA samples don't
    %interfere with each other.
    [M1_Transformed, ~] = pca_projection_2(single(Data_clear(PopA_indexes(:), Fewer_SNPs)), single(Data_clean(:, Fewer_SNPs)));
    positive_indexes = sum(M1_Transformed(:,1:2),2)~=0; %Keep only data that had sufficient SNPs
    disp(['Plotting ' num2str(sum(positive_indexes)) ' points']);
    
    % Plot the projections onto the first two principal components
    disp('Adding projected data to the figure...')
    Labels_nick = Labels.Nick(PopA_indexes(positive_indexes));
    Labels_color = Labels.Color(PopA_indexes(positive_indexes),:);
    Labels_marker = Labels.marker(PopA_indexes(positive_indexes));
    Labels_pops = Labels.Pop_name(PopA_indexes(positive_indexes));
    
    %Plot all points - do figure within a figure to show that it's aDNA
    [~, pop_index] = unique(Labels_pops, 'stable');
    
    CalculatePCA_pops_plot(SCORE, pcvars, Labels_grey, Pop_indexes(:), 0, hAxis, 6);
    hold on;    
    gscatter(M1_Transformed(positive_indexes,1), M1_Transformed(positive_indexes,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)), 4);
    gscatter(M1_Transformed(positive_indexes,1), M1_Transformed(positive_indexes,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)), 7);
    axis tight
    legend off;
    toc

hAxis(5) = subplot(2,3,5);
    disp('Case 5');
    rng(1);

    %Load modern day populations
    Pop1_codes = [1050 1045 1077 1078 1086 1165 1151]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Middle Eastersn
    Pop2_codes = [1024 1070 1125 1079 1083 1068 1098 1185:1186 ]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Italy and Balkan, lithenia, Ukraine
    Pop3_codes = [1065 1001:1002 1005 1007 1174:1178 1180:1181]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Caucasus and Turkey
    Pop4_codes = [1074]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Iran, Iraq
    Pop5_codes = [1071 1155:1164 1138 1141 1128 1137 1061:1063]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Iceland, spain, Fin, Russians
    Pop6_codes = [1066 1075 1076 1097 1106 1173 1179 1190]; Pop6_indexes = (Labels.Pop_code==Pop6_codes); %Jews no AJs
    Pop7_codes = [1126:1150 1209]; Pop7_indexes = (Labels.Pop_code==Pop7_codes); %Russians and Pakistani

    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0 sum(Pop6_indexes,2)>0 sum(Pop7_indexes,2)>0];
    disp([sum(Sample_indexes)]); %            
    
    n=[sum(Sample_indexes)];
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    old_Pop_indexes = Pop_indexes;
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    %Remove columns without variance
    Data_clean = Data_(Pop_indexes,:);
    [~,c1] = find(var(double(Data_clean),1)==0);
    Data_clean(:,c1)=[]; 
    
    [COEFF, SCORE, pcvars] = pca(double(Data_clean), 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE
    
    %Calculate PCA for modern-day people - this will plot modern
    %populations in color. mask the rest of the code and enable these
    %sections to get the figure in color
%     CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

    % -- Load ancient populations --
    Pop1_codes = [9067 9069 9071]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Iran
    Pop2_codes = [9072:9074]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Israel
    Pop3_codes = [9049 9042 9155 9151:9152 9122 9124]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Germany, Sweden, Switzerland, romania
    Pop4_codes = [9002 9041:9042]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Caucasus
    Pop5_codes = [9029:9030]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Austria
    
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0];
    disp([sum(Sample_indexes)]); %            
    
    n=[sum(Sample_indexes)];
    PopA_indexes = Find_n_indexes(Sample_indexes, n);
    PopA_indexes = PopA_indexes(:);
    PopA_indexes(PopA_indexes==0) = [];
    pops_for_legend = [pops_for_legend' PopA_indexes(:)']';

    % Calculate the projection for the ancient populations
    disp('Projecting the data...')
    
    %There is an internal function that won't take NaNs for M, so i am
    %sending Data_clea? and not Data_clea?, which has NaNs.
    %arrays must be the same size
    Data_clear = Data_(:,setdiff(1:size(Data_,2), c1));
    Data_clear(Data_clear==5)=NaN;

    %Reducing the number of SNPs due to memory concerns
    Fewer_SNPs = randperm(size(Data_clean,2), num_of_pca_pops);
    %Data_clean sends only modern
    %Data_clear with PopA_indexes has only ancient ones
    %they are the same size
    
    %The aDNA data has missing values, which would mess up the projection. 
    %pca_projection_2 keeps only the SNPs>threshold for EACH aDNA and
    %project it from the modern samples. This way, the aDNA samples don't
    %interfere with each other.
    [M1_Transformed, ~] = pca_projection_2(single(Data_clear(PopA_indexes(:), Fewer_SNPs)), single(Data_clean(:, Fewer_SNPs)));
    positive_indexes = sum(M1_Transformed(:,1:2),2)~=0; %Keep only data that had sufficient SNPs
    disp(['Plotting ' num2str(sum(positive_indexes)) ' points']);
    
    % Plot the projections onto the first two principal components
    disp('Adding projected data to the figure...')
    Labels_nick = Labels.Nick(PopA_indexes(positive_indexes));
    Labels_color = Labels.Color(PopA_indexes(positive_indexes),:);
    Labels_marker = Labels.marker(PopA_indexes(positive_indexes));
    Labels_pops = Labels.Pop_name(PopA_indexes(positive_indexes));
    
    %Plot all points - do figure within a figure to show that it's aDNA
    [~, pop_index] = unique(Labels_pops, 'stable');
    
    CalculatePCA_pops_plot(SCORE, pcvars, Labels_grey, Pop_indexes(:), 0, hAxis, 6);
    hold on;    
    gscatter(M1_Transformed(positive_indexes,1), M1_Transformed(positive_indexes,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)), 4);
    gscatter(M1_Transformed(positive_indexes,1), M1_Transformed(positive_indexes,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)), 7);
    axis tight
    legend off;
    toc

hAxis(6) = subplot(2,3,6);
    disp('Case 6');
    rng(1);

    %Load modern day populations
    Pop1_codes = [1050 1045 1077 1078 1086 1165 1151]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Middle Eastersn
    Pop2_codes = [1024 1070 1125 1079 1083 1068 1098 1185:1186 ]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Italy and Balkan, lithenia, Ukraine
    Pop3_codes = [1065 1001:1002 1005 1007 1174:1178 1180:1181]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Caucasus and Turkey
    Pop4_codes = [1074]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Iran, Iraq
    Pop5_codes = [1071 1155:1164 1138 1141 1128 1137 1061:1063]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Iceland, spain, Fin, Russians
    Pop6_codes = [1066 1075 1076 1097 1106 1173 1179 1190]; Pop6_indexes = (Labels.Pop_code==Pop6_codes); %Jews no AJs
    Pop7_codes = [1126:1150 1209 1029 1101:1105]; Pop7_indexes = (Labels.Pop_code==Pop7_codes); %
    
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0 sum(Pop6_indexes,2)>0 sum(Pop7_indexes,2)>0];
    disp([sum(Sample_indexes)]); %            
    
    n=[sum(Sample_indexes)];
    Pop_indexes = Find_n_indexes(Sample_indexes, n);
    Pop_indexes = Pop_indexes(:);
    Pop_indexes(Pop_indexes==0) = [];
    old_Pop_indexes = Pop_indexes;
    pops_for_legend = [pops_for_legend' Pop_indexes(:)']';
    
    %Remove columns without variance
    Data_clean = Data_(Pop_indexes,:);
    [~,c1] = find(var(double(Data_clean),1)==0);
    Data_clean(:,c1)=[]; 
    
    [COEFF, SCORE, pcvars] = pca(double(Data_clean), 'VariableWeights', 'variance', 'Centered', true);  %pc is the SCORE

    %Replace Labels with grey color and round symbols
    Labels_grey = Labels;
    Labels_grey.Color = ones(size(Labels_grey.Color)).*[0.74 0.74 0.74];
    for i=1:size(Labels_grey.marker,1)
        Labels_grey.marker(i) = {'.'};
    end;
    
    %Calculate PCA for modern-day people - this will plot modern
    %populations in color. mask the rest of the code and enable these
    %sections to get the figure in color
%     CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

    % -- Load ancient populations --
    Pop1_codes = [9067 9069 9071]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Iran
    Pop2_codes = [9072:9074]; Pop2_indexes = (Labels.Pop_code==Pop2_codes); %Israel
    Pop3_codes = [9049 9042 9155 9151:9152 9122 9124]; Pop3_indexes = (Labels.Pop_code==Pop3_codes); %Germany, Sweden, Switzerland, romania
    Pop4_codes = [9002 9041:9042]; Pop4_indexes = (Labels.Pop_code==Pop4_codes); %Caucasus
    Pop5_codes = [9029:9030]; Pop5_indexes = (Labels.Pop_code==Pop5_codes); %Austria
    
    Sample_indexes = [sum(Pop1_indexes,2)>0 sum(Pop2_indexes,2)>0 sum(Pop3_indexes,2)>0 sum(Pop4_indexes,2)>0 sum(Pop5_indexes,2)>0];
    disp([sum(Sample_indexes)]); %            
    
    n=[sum(Sample_indexes)];
    PopA_indexes = Find_n_indexes(Sample_indexes, n);
    PopA_indexes = PopA_indexes(:);
    PopA_indexes(PopA_indexes==0) = [];
    pops_for_legend = [pops_for_legend' PopA_indexes(:)']';

    % Calculate the projection for the ancient populations
    disp('Projecting the data...')
    
    %There is an internal function that won't take NaNs for M, so i am
    %sending Data_clea? and not Data_clea?, which has NaNs.
    %arrays must be the same size
    Data_clear = Data_(:,setdiff(1:size(Data_,2), c1));
    Data_clear(Data_clear==5)=NaN;

    %Reducing the number of SNPs due to memory concerns
    Fewer_SNPs = randperm(size(Data_clean,2), num_of_pca_pops);
    %Data_clean sends only modern
    %Data_clear with PopA_indexes has only ancient ones
    %they are the same size
    
    %The aDNA data has missing values, which would mess up the projection. 
    %pca_projection_2 keeps only the SNPs>threshold for EACH aDNA and
    %project it from the modern samples. This way, the aDNA samples don't
    %interfere with each other.
    [M1_Transformed, ~] = pca_projection_2(single(Data_clear(PopA_indexes(:), Fewer_SNPs)), single(Data_clean(:, Fewer_SNPs)));
    positive_indexes = sum(M1_Transformed(:,1:2),2)~=0; %Keep only data that had sufficient SNPs
    disp(['Plotting ' num2str(sum(positive_indexes)) ' points']);
    
    % Plot the projections onto the first two principal components
    disp('Adding projected data to the figure...')
    Labels_nick = Labels.Nick(PopA_indexes(positive_indexes));
    Labels_color = Labels.Color(PopA_indexes(positive_indexes),:);
    Labels_marker = Labels.marker(PopA_indexes(positive_indexes));
    Labels_pops = Labels.Pop_name(PopA_indexes(positive_indexes));
    
    %Plot all points - do figure within a figure to show that it's aDNA
    [~, pop_index] = unique(Labels_pops, 'stable');
    
    CalculatePCA_pops_plot(SCORE, pcvars, Labels_grey, Pop_indexes(:), 0, hAxis, 6);
    hold on;    
    gscatter(M1_Transformed(positive_indexes,1), M1_Transformed(positive_indexes,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)), 4);
    gscatter(M1_Transformed(positive_indexes,1), M1_Transformed(positive_indexes,2), Labels_pops, Labels_color(pop_index, :), char(Labels_marker(pop_index)), 7);
    axis tight
    legend off;
    toc
    
maximize    
% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_10.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_10.tif', 'output', 'd:\Pops_10_clear.tif');
%% #11 Choice of markers
close all; clear all; clc;
global Labels;

disp('#11 Testing different functional SNP cateogires');

% Load the entire dataset
[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');
Data_ = single(Data_);

% Load VEP annotation
fid = fopen ('D:\My Documents\University\Elhaik Lab\Data\PCA\Lazaridis_1kg_AJ_full\VEP results.txt');
% #Uploaded_variation	Location	Allele	Consequence	IMPACT	SYMBOL	Gene	Feature_type	Feature	BIOTYPE	EXON	INTRON	HGVSc	HGVSp	cDNA_position	CDS_position	Protein_position	Amino_acids	Codons	Existing_variation	DISTANCE	STRAND	FLAGS	SYMBOL_SOURCE	HGNC_ID	MANE	TSL	APPRIS	SIFT	PolyPhen	AF	CLIN_SIG	SOMATIC	PHENO	PUBMED	MOTIF_NAME	MOTIF_POS	HIGH_INF_POS	MOTIF_SCORE_CHANGE
% rs3094315	1:817186-817186	A	upstream_gene_variant	MODIFIER	FAM87B	ENSG00000177757	Transcript	ENST00000326734.2	lncRNA	-	-	-	-	-	-	-	-	-	rs3094315	185	1	-	HGNC	HGNC:32236	-	2	-	-	-	-	-	-	-	21159730,21492446,23664118,19096721	-	-	-	-
% rs3094315	1:817186-817186	T	upstream_gene_variant	MODIFIER	FAM87B	ENSG00000177757	Transcript	ENST00000326734.2	lncRNA	-	-	-	-	-	-	-	-	-	rs3094315	185	1	-	HGNC	HGNC:32236	-	2	-	-	-	-	-	-	-	21159730,21492446,23664118,19096721	-	-	-	-
% rs3094315	1:817186-817186	A	intron_variant,non_coding_transcript_variant	MODIFIER	AL669831.4	ENSG00000230092	Transcript	ENST00000447500.4	processed_transcript	-	1/4	-	-	-	-	-	-	-	rs3094315	-	-1	-	Clone_based_ensembl_gene	-	-	5	-	-	-	-	-	-	-	21159730,21492446,23664118,19096721	-	-	-	-

d=textscan(fid,'%s%*s%*s%s%*s%*s%*s%*s%*s%s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s%*s','delimiter','\t');
fclose(fid);
% count_string(d{2}); %Use this to count the cateogries and group them as follows

disp('Printing the number of SNPs in the major VEP cateogires')
coding_SNPs = unique(d{1}(find(ismember(d{2}, {'stop_lost'; ...
                    'start_lost,NMD_transcript_variant'; ...
                    'stop_gained,splice_region_variant'; ...
                    'coding_sequence_variant'; ...
                    'splice_region_variant,3_prime_UTR_variant'; ...
                    'stop_gained,splice_region_variant,NMD_transcript_variant'; ...
                    'splice_donor_variant,non_coding_transcript_variant'; ...
                    'splice_acceptor_variant,non_coding_transcript_variant'; ...
                    'splice_acceptor_variant'; ...
                    'stop_gained,NMD_transcript_variant'; ...
                    'stop_lost,NMD_transcript_variant'; ...
                    'splice_region_variant,synonymous_variant,NMD_transcript_variant'; ...
                    'missense_variant,splice_region_variant,NMD_transcript_variant'; ...
                    'splice_region_variant,5_prime_UTR_variant'; ...
                    'splice_region_variant,synonymous_variant'; ...
                    'splice_donor_variant'; ...
                    'missense_variant,splice_region_variant'; ...
                    'stop_gained'; ...
                    'start_lost'; ...
                    'missense_variant,NMD_transcript_variant'; ...
                    'synonymous_variant,NMD_transcript_variant'; ...
                    'synonymous_variant'; ...
                    'missense_variant'}))));

disp(['Coding SNPs: #' num2str_comma(numel(coding_SNPs))]);

TFB_SNPs = unique(d{1}(find(ismember(d{2}, 'TF_binding_site_variant'))));
disp(['TF binding factors SNPs: #' num2str_comma(numel(TFB_SNPs))]);

Regulatory_SNPs = unique(d{1}(find(ismember(d{2}, 'regulatory_region_variant'))));
disp(['Regulatory SNPs: #' num2str_comma(numel(Regulatory_SNPs))]);

Intronic_SNPs1 = unique(d{1}(find(ismember(d{2}, 'intron_variant,NMD_transcript_variant'))));
disp(['Intronic SNPs 1: #' num2str_comma(numel(Intronic_SNPs1))]);
                
Intronic_SNPs2 = unique(d{1}(find(ismember(d{2}, 'intron_variant,non_coding_transcript_variant'))));
disp(['Intronic SNPs 2: #' num2str_comma(numel(Intronic_SNPs2))]);

Intronic_SNPs3 = unique(d{1}(find(ismember(d{2}, 'non_coding_transcript_exon_variant'))));
disp(['Intronic SNPs 3: #' num2str_comma(numel(Intronic_SNPs3))]);

Intronic_SNPs4 = unique(d{1}(find(ismember(d{2}, 'intron_variant'))));
disp(['Intronic SNPs 4: #' num2str_comma(numel(Intronic_SNPs4))]);

Intronic_SNPs5 = unique(d{1}(find(ismember(d{2}, 'intergenic_variant'))));
disp(['Intronic SNPs 5: #' num2str_comma(numel(Intronic_SNPs5))]);

Up_down_stream_SNPs = unique(d{1}(find(ismember(d{2}, {'upstream_gene_variant'; 'downstream_gene_variant'}))));
disp(['Up/down stream  SNPs: #' num2str_comma(numel(Up_down_stream_SNPs))]);

RNA_molecules = unique(d{1}(find(ismember(d{3}, {'lncRNA'; 'miRNA'; 'misc_RNA'; 'snRNA'; 'snoRNA'; 'scaRNA'}))));
disp(['RNA molecules SNPs: #' num2str_comma(numel(RNA_molecules))]);

protein_coding = unique(d{1}(find(ismember(d{3}, {'protein_coding'}))));
disp(['protein_coding SNPs: #' num2str_comma(numel(protein_coding))]);

%Set 5 major categories, so that each group has 30K SNPs:
% Coding SNPs + Regulatory SNPs
% Intronic SNPs 2
% Intronic SNPs 4
% Intronic SNPs 5
% Up/down stream  SNPs
max_SNPs = 30000;

disp('Final number of SNPs per category');
coding_SNPs = [coding_SNPs(:)' Regulatory_SNPs(1:(max_SNPs-numel(coding_SNPs)))']'; disp(numel(coding_SNPs))
Intronic_SNPs2 = Intronic_SNPs2(1:max_SNPs); disp(numel(Intronic_SNPs2));
Intronic_SNPs4 = Intronic_SNPs4(1:max_SNPs); disp(numel(Intronic_SNPs4));
Intronic_SNPs5 = Intronic_SNPs5(1:max_SNPs); disp(numel(Intronic_SNPs5));
Up_down_stream_SNPs = Up_down_stream_SNPs(1:max_SNPs); disp(numel(Up_down_stream_SNPs));
RNA_molecules = RNA_molecules(1:max_SNPs); disp(numel(RNA_molecules));
protein_coding = protein_coding(1:max_SNPs); disp(numel(protein_coding));

% molecule = RNA_molecules;
% disp(['coding_SNPs #'  num2str(numel(intersect(coding_SNPs, molecule)))]);
% disp(['Intronic_SNPs2 #'  num2str(numel(intersect(Intronic_SNPs2, molecule)))]);
% disp(['Intronic_SNPs4 #' num2str(numel(intersect(Intronic_SNPs4, molecule)))]);
% disp(['Intronic_SNPs5 #' num2str(numel(intersect(Intronic_SNPs5, molecule)))]);
% disp(['Up_down_stream_SNPs #' num2str(numel(intersect(Up_down_stream_SNPs, molecule)))]);
% disp(['RNA_molecules #' num2str(numel(intersect(RNA_molecules, molecule)))]);
% disp(['protein_coding #' num2str(numel(intersect(protein_coding, molecule)))]);

%Load a list of all SNPs
All_SNPs = load_list('D:\My Documents\University\Elhaik Lab\Data\PCA\Lazaridis_1kg_AJ_full\SNP_list.txt'); All_SNPs=All_SNPs{1}; disp(numel(All_SNPs));

% Select populations (1)
rng(1)
Pop1_codes = [1200 1202 1084]; Pop1_indexes = (Labels.Pop_code==Pop1_codes); %Europeans

% Find the smallest population
Sample_sizes = (([sum(sum(Pop1_indexes))]));
Sample_indexes = [sum(Pop1_indexes,2)>0];

disp(['Analyzing #' num2str(min(Sample_sizes)) ' samples per population' ]);

n=[sum(Sample_indexes)];
Pop_indexes = Find_n_indexes(Sample_indexes, n);
Pop_indexes = Pop_indexes(:);
Pop_indexes(Pop_indexes==0) = [];

% Plot PCA for different choice of markers
figure
hAxis = [];
pops_for_legend = [];
pops_for_legend = Pop_indexes(:);

hAxis(1) = subplot(2,3,1);
    disp('Case 1 - All markers'); %All markers
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes,:));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    
hAxis(2) = subplot(2,3,2);
    disp('Case 2 - Coding SNPs');  

    %Use only coding SNPs
    [~, indexA, ~] = intersect(All_SNPs, coding_SNPs);
    disp(numel(indexA))

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes, indexA));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

hAxis(3) = subplot(2,3,3);
    disp('Case 3 - Intronic_SNPs5 SNPs');  

    %Use only coding SNPs
    [~, indexA, ~] = intersect(All_SNPs, Intronic_SNPs5);
    disp(numel(indexA))

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes, indexA));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

hAxis(4) = subplot(2,3,4);
    disp('Case 4 - protein_coding SNPs');  

    %Use only coding SNPs
    [~, indexA, ~] = intersect(All_SNPs, protein_coding);
    disp(numel(indexA))

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes, indexA));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);
    
hAxis(5) = subplot(2,3,5);
    disp('Case 5 - RNA_molecules');  

    %Use only coding SNPs
    [~, indexA, ~] = intersect(All_SNPs, RNA_molecules);
    disp(numel(indexA))

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes, indexA));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

hAxis(6) = subplot(2,3,6);
    disp('Case 6 - Up_down_stream_SNPs SNPs'); 
    %Use only coding SNPs
    [~, indexA, ~] = intersect(All_SNPs, Up_down_stream_SNPs);
    disp(numel(indexA))

    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes, indexA));
    CalculatePCA_pops_plot(SCORE, pcvars, Labels, Pop_indexes(:), 0, hAxis, 6);

maximize

% plot_legend(pops_for_legend, Labels);

% print('-dtiff', 'd:\Pops_11.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Pops_11.tif', 'output', 'd:\Pops_11_clear.tif');

%% Supp materials: Testing the %explained variance VS number of samples & %exaplined variance per PC (3 plots)
% How the %of explained variance changes per number of samples and PCs
close all; clear all;
clc

disp('How does the explained variance (%) changes per number of samples?');
[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

% Get the records for Africans, Asians, and Europeans
Afr_codes = [1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Asi_codes = [1029]; Asi_indexes = (Labels.Pop_code==Asi_codes);
Eur_codes = [1202]; Eur_indexes = (Labels.Pop_code==Eur_codes);
AJ_codes = [1006]; AJ_indexes = (Labels.Pop_code==AJ_codes);
Mixed_codes = [1001:1211]; Mixed_indexes = (Labels.Pop_code==Mixed_codes);

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(AJ_indexes)) sum(sum(Mixed_indexes))]));
Min_Sample_sizes = min(Sample_sizes);
disp([Sample_sizes]);

% Plot %explained variance VS number of samples (1/3)
Sample_indexes = [sum(Afr_indexes,2)]; disp(sum(Sample_indexes));

disp('Calculating PCA for Africans...')
n = 10:10:170;
PC12 = [];
for i=1:numel(n)
    Pop_indexes = Find_n_indexes(Sample_indexes, n(i));
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA

    %Calculate explained variation
    pcvars_exp = pcvars./sum(pcvars);
    PC1 = round2(10000*pcvars_exp(1),2)/100;
    PC2 = round2(10000*pcvars_exp(2),2)/100;
    PC12(i) = PC1 + PC2;
end;
PC12 = PC12./100;
plot(n,PC12, 'r.--'); hold on;

disp('Calculating PCA for Europeans...')
Sample_indexes = [sum(Eur_indexes,2)]; disp(sum(Sample_indexes));
n = 10:10:150;
PC12 = [];
for i=1:numel(n)
    Pop_indexes = Find_n_indexes(Sample_indexes, n(i));
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA

    %Calculate explained variation
    pcvars_exp = pcvars./sum(pcvars);
    PC1 = round2(10000*pcvars_exp(1),2)/100;
    PC2 = round2(10000*pcvars_exp(2),2)/100;
    PC12(i) = PC1 + PC2;
end;
PC12 = PC12./100;
plot(n,PC12, 'g.--'); hold on;

disp('Calculating PCA for Asians...')
Sample_indexes = [sum(Asi_indexes,2)]; disp(sum(Sample_indexes));

n = 10:10:140;
PC12 = [];
for i=1:numel(n)
    Pop_indexes = Find_n_indexes(Sample_indexes, n(i));
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA

    %Calculate explained variation
    pcvars_exp = pcvars./sum(pcvars);
    PC1 = round2(10000*pcvars_exp(1),2)/100;
    PC2 = round2(10000*pcvars_exp(2),2)/100;
    PC12(i) = PC1 + PC2;
end;
PC12 = PC12./100;
plot(n,PC12, 'b.--'); hold on;

disp('Calculating PCA for AJs...')
Sample_indexes = [sum(AJ_indexes,2)]; disp(sum(Sample_indexes));

n = 10:10:200;
PC12 = [];
for i=1:numel(n)
    Pop_indexes = Find_n_indexes(Sample_indexes, n(i));
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA

    %Calculate explained variation
    pcvars_exp = pcvars./sum(pcvars);
    PC1 = round2(10000*pcvars_exp(1),2)/100;
    PC2 = round2(10000*pcvars_exp(2),2)/100;
    PC12(i) = PC1 + PC2;
end;
PC12 = PC12./100;
plot(n,PC12, 'k.--'); hold on;


ylabel(['Variance explained by PC1 + PC2 (%)']);
xlabel(['Number of individuals']);
disp('Finished all calculations');

set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
set(gca, 'Box', 'off');
set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);

whitebg('w'); %affects the first plot
legend off;

% print('-dtiff', 'd:\Var_4_Pops.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Var_4_Pops.tif', 'output', 'd:\Var_4_Pops_clear.tif');

%% Plot %explained variance VS number of samples (2/3)

disp('Calculating PCA for All pops...')
%  Sample_indexes = [sum(Afr_indexes,2) sum(Eur_indexes,2) sum(Asi_indexes,2) sum(AJ_indexes,2)]; disp(sum(Sample_indexes));
Sample_indexes = [sum(Mixed_indexes,2) ]; disp(sum(Sample_indexes));

n = [10 100:100:2000];
PC12 = [];
for i=1:numel(n)
    Pop_indexes = Find_n_indexes(Sample_indexes, n(i));
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA

    %Calculate explained variation
    pcvars_exp = pcvars./sum(pcvars);
    PC1 = round2(10000*pcvars_exp(1),2)/100;
    PC2 = round2(10000*pcvars_exp(2),2)/100;
    PC12(i) = PC1 + PC2;
end;
PC12 = PC12./100;

plot(n,PC12, 'm.--'); hold on;

ylabel(['Proportion of variance explained by PC1 + PC2']);
xlabel(['Number of individuals']);
disp('Finished all calculations');

set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
set(gca, 'Box', 'off');
set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);

whitebg('w'); %affects the first plot
legend off;

% print('-dtiff', 'd:\Var_All_Pops.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Var_All_Pops.tif', 'output', 'd:\Var_All_Pops_clear.tif');

%% Plot %explained variance per component (3/3)

disp('Calculating PCA for All pops...')
%  Sample_indexes = [sum(Afr_indexes,2) sum(Eur_indexes,2) sum(Asi_indexes,2) sum(AJ_indexes,2)]; disp(sum(Sample_indexes));
Sample_indexes = [sum(Mixed_indexes,2) ]; disp(sum(Sample_indexes));

n = [11 100 500 1000 1500 2000];
color_vec = {'r', 'g', 'b', 'm', 'c', 'y'};
PC12 = [];
for i=1:numel(n)
    Pop_indexes = Find_n_indexes(Sample_indexes, n(i));
    
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA

    %Calculate explained variation
    pcvars_exp = pcvars./sum(pcvars);

    plot(pcvars_exp(1:10), char(color_vec(i)), 'Marker', '.', 'LineStyle', '--'); hold on;
%     pause
end;


ylabel(['Proporiton of variance explained']);
xlabel(['Principal components']);

set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
set(gca, 'Box', 'off');
set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);

whitebg('w'); %affects the first plot
legend off;

% print('-dtiff', 'd:\Var_PC.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Var_PC.tif', 'output', 'd:\Var_PC_clear.tif');

%% Supp materials: Variance explained versus noise 

close all; clear all;
clc

disp('How does the explained variance (%) compared with random noise?');
[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

% Get the records for Mixed populations
%CEU, Indian (Telugu), Vietnam, ASW, Peruvian (Lima)
Mix_codes = [1195 1203 1192 1201 1208]; Mix_indexes = (Labels.Pop_code==Mix_codes); %1000KG populations

% Find the smallest population
n = 200;
m = size(Data_,2);

Sample_indexes = [sum(Mix_indexes,2)]; disp(sum(Sample_indexes));

disp('Calculating for randomly sampled individuals...');
pcvars_exp_vec = [];
for i=1:50
    Pop_indexes = Find_n_indexes(Sample_indexes, n);

    % analyzte population data
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),:)); %Calculate PCA
    pcvars_exp = pcvars./sum(pcvars);
    pcvars_exp_vec(:,i) = pcvars_exp;
end;

% Generate a random matrix by reshuffling the values in Data, 
% this way we reduce the bias of creating a new matrix
disp('Calculating PCA for the random matrices...');
pcvars_x_exp_vec = [];
for i=1:50
    x = reshape(randperm(n*m), n, m);

    [SCORE, ~, pcvars_x] = pca1(Data_(x)); %Calculate PCA
    pcvars_x_exp = pcvars_x./sum(pcvars_x);
    pcvars_x_exp_vec(:,i) = pcvars_x_exp;
end;

disp('Plotting the results');
% Plot the proporiton of variance explained by the PCs
% and taht explained for the reshuffled data

% bar(pcvars_exp(1:20)); hold on;
boxplot(pcvars_exp_vec(1:20,:)'); hold on;
% boxplot(pcvars_x_exp_vec(1:20,:)'); 
plot(median(pcvars_x_exp_vec(1:20,:)'), 'g.-');

ylabel(['Proporiton of variance explained by the PCs']);
xlabel(['PCs']);

set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
set(gca, 'Box', 'off');
set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);

whitebg('w'); %affects the first plot
legend off;

% print('-dtiff', 'd:\S9.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\S9.tif', 'output', 'd:\S9_clear.tif');

%% Supp materials: Test the distance between samples as a function of dimensions 
% The average distance between samples across dimensions

close all; clear all;
clc

disp('How does the explained variance (%) changes per number of samples?');
[input_file_excel input_dir_excel Data_ Labels]= Load_Database_final('Lazaridis_1kg_AJ_full');

% Get the records for Africans, Asians, and Europeans
Afr_codes = [1113]; Afr_indexes = (Labels.Pop_code==Afr_codes);
Asi_codes = [1029]; Asi_indexes = (Labels.Pop_code==Asi_codes);
Eur_codes = [1202]; Eur_indexes = (Labels.Pop_code==Eur_codes);
AJ_codes = [1006]; AJ_indexes = (Labels.Pop_code==AJ_codes);
Mixed_codes = [1001:1211]; Mixed_indexes = (Labels.Pop_code==Mixed_codes);

% Find the smallest population
Sample_sizes = (([sum(sum(Afr_indexes)) sum(sum(Eur_indexes)) sum(sum(Asi_indexes)) sum(sum(AJ_indexes)) sum(sum(Mixed_indexes))]));
Min_Sample_sizes = min(Sample_sizes);
disp([Sample_sizes]);

% Calcualte the distance between samples (per the first 2 components)
dist_vec = [];
dist_group = [];
dist_nei = [];
dist_fur = [];
n_SNPs = [10 100 1000 10000 100000];
Sample_indexes = [sum(Afr_indexes,2)]; disp(sum(Sample_indexes));
Pop_indexes = Find_n_indexes(Sample_indexes, 100);
for i=1:numel(n_SNPs)
    [SCORE, ~, pcvars] = pca1(Data_(Pop_indexes(:),1:n_SNPs(i))); %Calculate PCA
    dist_group = [dist_group ones(1,numel(pdist(SCORE(:,1:2)))).*n_SNPs(i)];
    dist_vec = [dist_vec pdist(SCORE(:,1:2))];
    
    %find the nearest neighbor
    for j=1:100
        x = sort(pdist2(SCORE(j,1:2),SCORE(:,1:2)));
        dist_nei(j,i) = x(2); %get the seocnd smllest, the first one is the same number
        dist_fur(j,i) = x(50); %get the seocnd smllest, the first one is the same number
    end;
    dist_nei(:,i) = sort(dist_nei(:,i));
    dist_fur(:,i) = sort(dist_fur(:,i));
end;

% -----------
% Figure A
% -----------
% Plot the results (boxplot, X represents #SNPs)
boxplot(dist_vec(:), dist_group(:))

ylabel(['The distance between samples']);
xlabel(['Number of SNPs']);

set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
set(gca, 'Box', 'off');
set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);

whitebg('w'); %affects the first plot
legend off;

% print('-dtiff', 'd:\Dist_samples1.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Dist_samples1.tif', 'output', 'd:\Dist_samples1_clear.tif');


% -----------
% Figure B
% -----------
% Plot the results (distribution of distances, X is samples, color is #SNPs)
color_vec = {'r', 'g', 'b', 'm', 'c', 'y'};
for i=1:numel(n_SNPs)
    temp = (dist_nei(:,i));
    temp(isinf(temp)) = [];
    plot(cumsum(temp), char(color_vec(i)), 'Marker', 'o'); hold on;
end;

ylabel(['Cumulative distance to the nearest sample']);
xlabel(['Samples']);

set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
set(gca, 'Box', 'off');
set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);

whitebg('w'); %affects the first plot
legend off;

% print('-dtiff', 'd:\Dist_samples2.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Dist_samples2.tif', 'output', 'd:\Dist_samples2_clear.tif');

% -----------
% Figure C
% -----------
for i=1:numel(n_SNPs)
    temp = (dist_fur(:,i));
    temp(isinf(temp)) = [];
    plot(cumsum(temp), char(color_vec(i)), 'Marker', 'x'); hold on;
end;

ylabel(['Cumulative distance to the median sample']);
xlabel(['Samples']);

set(gca,'FontName', 'TimeNewRoman', 'FontSize', 9, 'LabelFontSizeMultiplier', 1.5);
set(gca, 'Box', 'off');
set(gca, 'LineWidth', 1.5, 'TickLength', [0.005,0.005]);

whitebg('w'); %affects the first plot
legend off;

% print('-dtiff', 'd:\Dist_samples3.tif', '-r600'); close;
% RemoveWhiteSpace([], 'file', 'd:\Dist_samples3.tif', 'output', 'd:\Dist_samples3_clear.tif');






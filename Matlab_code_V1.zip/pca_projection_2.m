% pca_projection_2

% Projecting new color
% In order to represent a new point in the principal component space created by the original data, there are two steps:
% 1.  Subtract the mean of the original data from the new point.
% 2.  Multiply the result by the coefficients of the principle components.

% This is a test copy of pca_projection.
% I am trying to implement Nick's comments.

% M_ is the new dataset to be projected on M.
% M is the original dataset

% M_ = single(Data_clear(PopA_indexes(:), Fewer_SNPs));
% M = single(Data_clean(:, Fewer_SNPs));

function [y, Y]= pca_projection_2(M_, M)

    %Analyze only samples with more SNPs than the threshold, otherwise,
    %put 0 in the result matrix (y)
    SNP_threshold = 10000;

    %pca_projection doesn't like data without a variation
    [~,c1] = find(var(M_,1)==0);
    [~,c2] = find(var(M,1)==0);
    
    disp(['pca_projection: Removing ' num2str(numel([c1 c2])) ' out of ' num2str(numel(M(:))./min(size(M)))]);
    M_(:,[c1 c2])=[];
    M(:,[c1 c2])=[];

    %Here, M is being centered and standardized.
    %PCA returns the principal components based on the correlation matrix.
    %Note, this function cannot take nan
    [W, Y] = pca(M, 'VariableWeights', 'variance', 'Centered', true);
%     plot(Y(:,1), Y(:,2),'.'); %plot the PCA

    % Calculate the orthonormal coefficient matrix (check that W*W' = I)
    W = diag(std(M))\W; %time consuming

    y = [];
    for i=1:size(M_,1)
        %Get current datapoint
        x = M_(i,:);
        informative_indexes = find(~isnan(x));
        disp([num2str(i) '. ' num2str(numel(informative_indexes))])
        
        if numel(informative_indexes)>SNP_threshold
            %Getting mean and weights of data, in non-NaN SNPs 
            [~, mu, sigma] = zscore(M(:,informative_indexes));
            sigma(sigma==0) = 1;

            x = bsxfun(@minus,x(informative_indexes), mu);
            x = bsxfun(@rdivide, x, sigma);

            y(i,:) = (x*W(informative_indexes,:)); % our result
        end
    end
    
    if isempty(y)
        error_message('pca_projection: y is empty');
    end;
end
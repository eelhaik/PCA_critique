% Load_Database_final
function [input_file_excel input_dir_excel Data_ Labels]= Load_Database_final(database_name)

    if strcmp(database_name, 'Lazaridis_full')
        disp('Openning the Lazaridis_full database...');
        % Load .ped, .map, and Label files to do PCA
        input_dir = '..\Datasets\'; 
        input_dir_excel = input_dir;
        input_file_excel = 'AncientLazaridis2016_LD_pruned_miss.xlsx';

        disp('Loading Lazaridis_full genetic database...');
        load([input_dir 'AncientLazaridis2016_LD_pruned.mat']);
        
    elseif strcmp(database_name, 'LazaridisAncient')
        disp('Openning the LazaridisAncient database...');
        % Load .ped, .map, and Label files to do PCA
        input_dir = '..\Datasets\'; 
        input_dir_excel = input_dir;
        input_file_excel = 'aDNA_Database_All_selected.xlsm';

        disp('Loading LazaridisAncient genetic database...');
        load([input_dir 'aDNA_Database_All_selected.mat']);
        
    elseif strcmp(database_name, 'Lazaridis_1kg_AJ_full')
        disp('Openning the Lazaridis_1kg_AJ_full database...');
        % Load .ped, .map, and Label files to do PCA
        input_dir = '..\Datasets\'; 
        input_dir_excel = input_dir;
        input_file_excel = 'Lazaridis2016_1kg_AJ_merged_n_LD_miss.xlsm';

        disp('Loading Lazaridis2016_1kg_AJ_merged_n_LD_miss genetic database...');
        load([input_dir 'Lazaridis2016_1kg_AJ_merged_n_LD_miss.mat']);
    end;
    
    %Load labels
    disp('Loading labels...')
    Labels = Load_Database_Annotation(input_dir_excel, input_file_excel);
    
    % QC - Compare database size to that of the lables file
    if numel(Labels.index)~=size(Data_,1)
        error_message('Load_Database: mismatching Data_ and labels');
        disp(['There are #' num2str(numel(Labels.index)) ' individuals. and #' num2str(size(Data_,1)) 'In the plink file']);    
        return;
    end;        
    disp([database_name ' database match: there are #' num2str(numel(Labels.index)) ' individuals and #' num2str(size(Data_,1)) ' PCs']);
    
    Data_ = double(Data_);
end

% Plot_3d

% Plot the 3d plot
function Plot_3d(M)
    for i=1:size(M,1)
        plot3(M(i,1), M(i,2), M(i,3), 'o', 'MarkerFaceColor', M(i,:), 'MarkerEdgeColor', M(i,:), 'MarkerSize',5);
        hold on;
    end;
    grid on
    axis([0 1 0 1 0 1]);

    cm=[1 0 0; 0 1 0; 0 0 1]; %Set the colors of the axis
    ax=reshape(axis,2,3);
    whitebg('w');
    plot3(ax(:,1),ax(1,2)*[1;1],ax(1,3)*[1;1],'-','LineWidth',2,'Color',cm(1,:));
    plot3(ax(2,1)*[1;1],ax(:,2),ax(1,3)*[1;1],'-','LineWidth',2,'Color',cm(2,:));
    plot3(ax(2,1)*[1;1],ax(1,2)*[1;1],ax(:,3),'-','LineWidth',2,'Color',cm(3,:));
    set(gca,'XColor',cm(1,:),'YColor',cm(2,:),'ZColor',cm(3,:),'LineWidth',1.5,'FontWeight','bold');
    view(10.5,30);
end
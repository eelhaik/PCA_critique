% PCAAxesRotation

% Flip axis
function PCa = PCAAxesRotation(SCORE, S, Colors_names)

    PCa = SCORE;
    %Goal: Green is on top, Red to the left, Blue to the right     
    green_pos = find(S==find(ismember(Colors_names,'Green')));
    red_pos = find(S==find(ismember(Colors_names,'Red')));
    blue_pos = find(S==find(ismember(Colors_names,'Blue')));
    
    %If Africans are below Europeans, on the y-axis, flip y-axis
    %If green below blue on the y-axis, flip y-axis
    if mean(PCa(green_pos,2)) < mean(PCa(blue_pos,2)) 
        disp('    Flipping y-axis'); PCa(:,2) = -PCa(:,2); 
    end;

    %If Eu are larger than Af , on the x-axis, flip x-axis
    %If red>blue on the x-axis, flip x-axis
    if mean(PCa(red_pos,1)) > mean(PCa(blue_pos,1)) 
        disp('    Flipping x-axis'); PCa(:,1) = -PCa(:,1); 
    end;

end
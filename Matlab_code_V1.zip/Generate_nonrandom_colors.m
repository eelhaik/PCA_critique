% Generate_nonrandom_colors

% return the color matrix (M) and color ID (S) vector
function [M S]=Generate_nonrandom_colors(color_vec, SD, N, S_)

    M = abs([color_vec(1)+SD.*randn(N,1) color_vec(2)+SD.*randn(N,1) color_vec(3)+SD.*randn(N,1) ]);
    M(M(:,1)>1,1)=1; M(M(:,2)>1,2)=1; M(M(:,3)>1,3)=1; %Rounding colors>1
    S = ones(1,size(M,1)).*S_;
end








